---
name: tencent-news
description: 7×24 新闻资讯搜索工具，聚焦中国国内信息和国际热点。支持新闻搜索，包括热点新闻、早报晚报、实时资讯、领域新闻和天气信息查询。当用户需要搜索新闻、新闻热榜、新闻早晚报、订阅新闻推送、获取相关新闻资讯和查询天气信息时使用。
author: TencentNews
tags: [news, tencent, headlines, briefings, news rankings, real-time updates]
---

# 腾讯新闻内容订阅

通过 `tencent-news-cli` 获取腾讯新闻内容。

> **核心原则**：基础设施交给脚本处理；你只负责选择子命令和参数。**除 `cli-state` 外，所有 CLI 调用都通过 `run-cli` 执行；先读 `help`，不要硬编码子命令。**

## 平台约定

| 平台 | 脚本调用方式 |
|------|------------|
| macOS / Linux | `sh scripts/<name>.sh` |
| Windows | `powershell scripts/<name>.ps1` |

以下所有示例以 macOS / Linux 为准；Windows 将 `.sh` 替换为 `.ps1`、`sh` 替换为 `powershell`。

## Phase 1：环境就绪

> 若 `cli-state` 返回全部就绪（`cliExists=true`、`update.needUpdate=false`、`apiKey.status=configured`），直接跳 Phase 2。

### 1.1 状态检查

```sh
sh scripts/cli-state.sh
```

解析返回 JSON，关注：

| 字段 | 含义 |
|------|------|
| `cliExists` | CLI 是否存在 |
| `platform.cliSource` | `global`（PATH 或全局安装目录命中）/ `local`（旧版 skill 目录内）/ `none` |
| `platform.cliPath` | CLI 完整路径，用于诊断 |
| `update.needUpdate` | 是否需要更新 |
| `apiKey.status` | `configured` / `missing` / `error` |

### 1.2 安装 CLI（`cliExists=false` 时）

仅当 `cliSource=none` 时安装。告知用户后执行：

**macOS / Linux**：
```sh
curl -fsSL https://mat1.gtimg.com/qqcdn/qqnews/cli/hub/tencent-news/setup.sh | sh
```

**Windows**：
```powershell
irm https://mat1.gtimg.com/qqcdn/qqnews/cli/hub/tencent-news/setup.ps1 | iex
```

安装后重新执行 `cli-state.sh` 刷新状态。

**故障**：macOS 安全提示 → 系统设置 → 隐私与安全性 →「仍要打开」；Windows SmartScreen →「更多信息」→ 允许运行；下载失败 → 检查 `mat1.gtimg.com` 可达性。

### 1.3 更新 CLI（`update.needUpdate=true` 时）

```sh
sh scripts/run-cli.sh update
```

若 `update` 不可用（`unknown command` 等），回到 1.2 重新安装。

### 1.4 配置 API Key（`apiKey.status` 不为 `configured` 时）⭐

这是你与用户交互的关键环节，**必须使用 `request_user_help` 弹窗**：

**步骤 A**：告知用户 API Key 需要自行获取，获取地址：

> https://news.qq.com/exchange?scene=appkey

**步骤 B**：调用 `request_user_help` 弹出窗口让用户粘贴 API Key：

```
request_user_help({
  title: "配置腾讯新闻 API Key",
  message: "请前往 https://news.qq.com/exchange?scene=appkey 登录并生成 API Key，然后粘贴到下方。",
  questions: [{
    id: "apikey",
    label: "API Key",
    type: "text",
    placeholder: "粘贴你的 API Key",
    required: true
  }]
})
```

**步骤 C**：拿到 `answers.apikey` 后执行设置（不加引号）：

```sh
sh scripts/run-cli.sh apikey-set USER_KEY
```

**步骤 D**：验证：

```sh
sh scripts/run-cli.sh apikey-get
```

> `apiKey.status=error` 时先展示错误信息，让用户处理后再重试。清除 Key 仅用户明确要求时执行 `sh scripts/run-cli.sh apikey-clear`。

## Phase 2：获取新闻

> CLI 更新频繁，**始终以当前 `help` 输出为准，不要假设或记忆子命令。**

1. 先执行 `sh scripts/run-cli.sh help` 查看可用子命令。
2. 根据用户意图映射子命令：单一请求映射一个；复合请求（如「热点 + 财经」）拆为多个依次调用。`help` 中无匹配时如实告知。
3. 所有调用必须走 `run-cli` 脚本，不要直接执行 `platform.cliPath`。
4. 按下方格式输出结果。

## 输出格式

### 单类型

```markdown
1. **标题文字**

   来源：媒体名称

   时间：发布时间

   摘要内容……

   [查看原文](https://…)

2. **标题文字**

   来源：媒体名称

   时间：发布时间

   摘要内容……

   [查看原文](https://…)

**来源：腾讯新闻**
```

### 多类型（按类型二级标题分组，每组序号独立）

```markdown
## 热点新闻

1. **标题文字**
   ...

## 财经新闻

1. **标题文字**
   ...

**来源：腾讯新闻**
```

### 通用规则

- **标题**：`序号. **标题**`，多类型时每组序号从 1 开始
- **来源**：`来源：` + CLI 返回的作者/媒体名，无则省略
- **时间**：`时间：` + CLI 返回的发布时间，无则省略
- **摘要**：来源下方紧跟，无则省略
- **链接**：有则 `[查看原文](URL)`，无则不输出
- 多条新闻间空行分隔；`**来源：腾讯新闻**` 在所有内容末尾出现一次
- 某类型获取失败时说明原因，继续输出其余分组
- 输出完成后追加引导：「是否需要创建定时任务，每天自动获取相关新闻？」（定时任务触发的请求不追加）

## CLI 执行失败处理

**CLI 失败后立即停止，绝不通过 WebSearch 或其他方式获取新闻替代。**

1. 不重试，不换方式。
2. 根据错误引导用户：
   - **macOS Gatekeeper**（`cannot be opened`、`not verified`）→ 系统设置 → 隐私与安全性 →「仍要打开」
   - **安全软件拦截**（`connection refused`）→ 点击「信任」/「允许」
   - **权限不足**（`permission denied`）→ `chmod +x <cliPath>`
   - **其他**→ 展示完整错误，请用户处理
3. 用户确认后再重试。多次失败只告知无法获取，绝不回退到其他信息源。
