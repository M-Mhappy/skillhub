"""
中国法律服务网案例库 (alk.12348.gov.cn) Python API 封装
=====================================================
直连HTTP请求，无需浏览器。所有方法均返回结构化JSON。

使用方式：
    from case_12348_api import Case12348API
    api = Case12348API()
    result = api.search('民间借贷', page=1, page_size=5)
    print(f"共{result['total']}条，当前{result['count']}条")
    for case in result['results']:
        print(case['title'], case['publishDate'])
"""

import requests
from bs4 import BeautifulSoup
import json
import re
import urllib.parse


class Case12348API:
    """中国法律服务网案例库 API 封装"""

    BASE_URL = 'https://alk.12348.gov.cn'

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': '*/*',
            'Accept-Language': 'zh-CN,zh;q=0.9',
        })

    def search(self, keywords, search_field='案例全文', page=1, page_size=5):
        """
        核心搜索方法 — POST 请求 Search API

        参数:
            keywords (str):   搜索关键词（如 '民间借贷'）
            search_field (str): 搜索字段，可选值：
                '案例全文', '案例标题', '检索主题词', '报送单位', '摘要', '案例编号'
            page (int):       页码，从1开始
            page_size (int):  每页条数，默认5，最大10

        返回:
            dict: {
                'success': bool,
                'total': int,       # 总结果数
                'page': int,
                'pageSize': int,
                'count': int,       # 当前页结果数
                'results': [        # 案例列表
                    {
                        'title': str,
                        'url': str,
                        'caseNumber': str,
                        'publishDate': str,
                        'caseType': str,
                        'views': str
                    }
                ],
                'hasMore': bool      # 是否还有下一页
            }
        """
        page_size = max(1, min(int(page_size), 10))

        data = {
            'searchField': search_field,
            'keywords': keywords,
            'checkDatabaseID': '',
            'pageIndexNow': page,
            'pageSizeNow': page_size,
            'sortField': '',
            'sortDescAsc': '',
            'listOrabst': '',
            'classCode': '',
            'fieldName': '',
            'fieldValue': '',
            'currentSubid': 0,
            'caseTimeValue': '',
            'businessTypeName': '',
            'areaName': '',
            'Type': 0,
            'ParentDbId': '',
        }

        # 构造 Referer（需要 URL 编码）
        encoded_field = urllib.parse.quote(search_field)
        encoded_kw = urllib.parse.quote(keywords)
        referer = f'{self.BASE_URL}/LawMultiSearch?searchField={encoded_field}&keywords={encoded_kw}'

        headers = {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'Referer': referer,
        }

        resp = self.session.post(
            f'{self.BASE_URL}/LawMultiSearch/Search',
            data=data,
            headers=headers,
            timeout=15,
        )

        if resp.status_code != 200:
            return {
                'success': False,
                'error': f'HTTP {resp.status_code}',
                'total': 0,
                'results': [],
            }

        # 解析 HTML 片段
        soup = BeautifulSoup(resp.text, 'html.parser')

        # 提取总结果数 — 文本 "共找到  687  条结果"（可能有空格）
        total_match = re.search(r'共找到\s*(\d+)\s*条', resp.text)
        total = int(total_match.group(1)) if total_match else 0

        # 提取表格行
        rows = []
        tbody = soup.select_one('table tbody')
        if tbody:
            for tr in tbody.find_all('tr'):
                tds = tr.find_all('td')
                if len(tds) >= 5:
                    a_tag = tds[0].find('a')
                    title = a_tag.get_text(strip=True) if a_tag else ''
                    # 清理序号前缀（如 "1 "）
                    title = re.sub(r'^\d+\s*', '', title)
                    rows.append({
                        'title': title,
                        'url': a_tag.get('href', '') if a_tag else '',
                        'caseNumber': tds[1].get_text(strip=True),
                        'publishDate': tds[2].get_text(strip=True),
                        'caseType': tds[3].get_text(strip=True),
                        'views': tds[4].get_text(strip=True),
                    })

        return {
            'success': True,
            'total': total,
            'page': page,
            'pageSize': page_size,
            'count': len(rows),
            'results': rows,
            'hasMore': (page * page_size) < total,
        }

    def get_keyword_groups(self, keywords, search_field='案例全文'):
        """获取搜索关键词的分组统计（JSON数组）"""
        data = {
            'searchField': search_field,
            'keywords': keywords,
            'checkDatabaseID': '',
            'pageIndexNow': 1,
            'pageSizeNow': 10,
            'sortField': '',
            'sortDescAsc': '',
            'listOrabst': '',
            'classCode': '',
            'fieldName': '关键词',
            'fieldValue': '',
            'currentSubid': 0,
            'caseTimeValue': '',
            'businessTypeName': '',
            'areaName': '',
            'Type': 0,
            'ParentDbId': '',
        }
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
        }
        resp = self.session.post(
            f'{self.BASE_URL}/LawMultiSearch/SearchMultiGroupList',
            data=data,
            headers=headers,
            timeout=15,
        )
        if resp.status_code == 200:
            # 使用 resp.content 解码避免编码问题
            try:
                return json.loads(resp.content.decode('utf-8-sig'))
            except (json.JSONDecodeError, UnicodeDecodeError):
                try:
                    return resp.json()
                except (json.JSONDecodeError, ValueError):
                    return resp.text
        return None

    def get_case_types(self):
        """获取案例分类树（人民调解、律师代理等分类）"""
        resp = self.session.get(
            f'{self.BASE_URL}/Case/GetDbTreeCategroy',
            timeout=15,
        )
        if resp.status_code == 200:
            return resp.json()
        return None


# ============================================================
# 快捷函数 — 一行调用
# ============================================================
_default_api = None


def search_case(keywords: str, page: int = 1, page_size: int = 5) -> dict:
    """快速搜索案例（使用默认实例）"""
    global _default_api
    if _default_api is None:
        _default_api = Case12348API()
    return _default_api.search(keywords, page=page, page_size=page_size)


if __name__ == '__main__':
    # ===== 演示 =====
    api = Case12348API()

    # 搜索 '民间借贷'
    result = api.search('民间借贷', page=1, page_size=5)
    print(f"搜索'民间借贷': 共 {result['total']} 条结果")
    for i, case in enumerate(result['results'], 1):
        print(f"  {i}. {case['title']} | {case['publishDate']}")

    # 查看关键词分组
    groups = api.get_keyword_groups('民间借贷')
    if groups and isinstance(groups, list):
        print(f"\n关键词分组 (前3):")
        for g in groups[:3]:
            print(f"  {g['关键词']}: {g['GroupCount']}条")
