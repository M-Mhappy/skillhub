---
name: 飞猪车次、航班、酒店信息查询skill
description: 基于飞猪 (Fliggy / 阿里旅行) 出行信息查询 SKILL
---

## 概述

本 SKILL 提供了通过浏览器 DOM 提取方式查询飞猪（Fliggy / 阿里旅行）平台上三种出行信息的能力：

- **✈️ 航班搜索**（search_flights）— 按出发/到达城市、日期查询航班列表
- **🚄 火车票搜索**（search_trains）— 按出发/到达站、日期查询车次列表
- **🏨 酒店搜索**（search_hotels）— 按城市、入住/离店日期查询酒店列表

所有数据均通过飞猪公开网页（SSR 服务端渲染）的 HTML DOM 提取，**无需 API Key、无需登录、无需商家资质**。

---

## 认证方式

| 项目 | 说明 |
|------|------|
| **认证方式** | 无需 API Key / 无需登录 |
| **访问方式** | 浏览器公开访问 |
| **额外要求** | 火车票搜索有反爬机制，需处理请求频率和 Cookie 会话 |
| **数据来源** | 飞猪公开网页 SSR DOM 提取 |

---

## 工具说明

### 工具1: search_flights — 航班搜索

**功能**：查询飞猪平台上指定日期的国内航班信息。

**核心方案**：浏览器 DOM 提取（SSR 渲染）

**请求方式**：导航到飞猪机票搜索结果页，解析 `<tr class="flight-item-tr">` 中的航班数据。

**URL 模板**：
```
https://sjipiao.fliggy.com/flight_search_result.htm
  ?tripType=0           # 单程（固定）
  &depCity={城市代码}    # 出发城市 IATA 三字码
  &arrCity={城市代码}    # 到达城市 IATA 三字码
  &depDate={日期}       # 出发日期，格式 yyyy-MM-dd
  &depCityName={中文名}  # 出发城市中文名（URL编码）
  &arrCityName={中文名}  # 到达城市中文名（URL编码）
```

**输入参数**：

| 参数 | 类型 | 必填 | 说明 | 示例 |
|------|------|------|------|------|
| `depCity` | string | 是 | 出发城市 IATA 三字码 | `BJS` |
| `arrCity` | string | 是 | 到达城市 IATA 三字码 | `HGH` |
| `depDate` | string | 是 | 出发日期 (yyyy-MM-dd) | `2026-06-19` |
| `depCityName` | string | 否 | 出发城市中文名 | `北京` |
| `arrCityName` | string | 否 | 到达城市中文名 | `杭州` |

**输出格式**：

```json
[
  {
    "airline": "东航MU5193",
    "aircraft": "中型机 321",
    "departureTime": "07:30",
    "arrivalTime": "09:30",
    "departureAirport": "大兴国际机场",
    "arrivalAirport": "萧山国际机场T3",
    "duration": "约2小时",
    "ontimeRate": "100.0%",
    "price": 1321,
    "discount": "5.5折",
    "ticketsLeft": "3张"
  }
]
```

**DOM 选择器**：

| 字段 | CSS 选择器（相对 tr.flight-item-tr） |
|------|--------------------------------------|
| 航司+机型 | `td.flight-line` |
| 起飞/到达时间 | `td.flight-time` |
| 起抵机场 | `td.flight-port` |
| 准点率 | `td.flight-ontime-rate` |
| 飞行时长 | `td.flight-total-time` |
| 价格+折扣 | `td.flight-price` |
| 余票信息 | `td.flight-operate` |

**降级策略（2层）**：
1. **L1 — 直接 DOM 提取**：导航到搜索结果页 URL，使用浏览器工具解析 SSR 渲染的 `<tr class="flight-item-tr">`
2. **L2 — 首页搜索跳转**：从 `https://www.fliggy.com/` 首页的机票搜索表单提交，等待跳转后提取

---

### 工具2: search_trains — 火车票搜索

**功能**：查询飞猪平台上指定日期的国内火车票信息。

**核心方案**：浏览器 DOM 提取（需处理反爬）

**请求方式**：导航到飞猪火车票搜索结果页，解析 SSR 渲染的 DOM。

**URL 模板**：
```
https://train.trip.taobao.com/stsSearch.htm
  ?depLocation={出发站}   # GB2312 编码
  &arrLocation={到达站}   # GB2312 编码
  &depDate={日期}         # yyyy-MM-dd
```

> ⚠️ **注意**：参数 `depLocation` 和 `arrLocation` 需要使用 **GB2312 编码**（如 `北京` → `%B1%B1%BE%A9`）。

**输入参数**：

| 参数 | 类型 | 必填 | 说明 | 示例 |
|------|------|------|------|------|
| `depLocation` | string | 是 | 出发站/城市名（GB2312 编码） | `%B1%B1%BE%A9` |
| `arrLocation` | string | 是 | 到达站/城市名（GB2312 编码） | `%C9%CF%BA%A3` |
| `depDate` | string | 是 | 出发日期 (yyyy-MM-dd) | `2026-06-20` |
| `trainType` | string | 否 | 车次类型过滤（G/C/D/T/K/Z） | `G` |

**输出格式**：

```json
[
  {
    "trainNumber": "G1",
    "trainType": "高铁",
    "departureStation": "北京南",
    "arrivalStation": "上海虹桥",
    "departureTime": "07:00",
    "arrivalTime": "12:00",
    "duration": "约5小时",
    "price": "553"
  }
]
```

> 注意：火车票搜索结果页的表头字段为「车次/车型」「出发」「耗时」「到达」「参考价」。

**反爬机制说明**：
- 页面加载时可能触发反爬，显示"用户请求太快，请求被过滤"
- 需要以下应对措施：
  1. **请求间隔**：连续请求间隔至少 3-5 秒
  2. **Cookie 维持**：先访问首页获取有效 Cookie，带入搜索请求
  3. **浏览器环境**：使用完整浏览器环境（非简单的 HTTP 请求）
  4. **行为模拟**：模拟正常用户操作流程

**搜索类型选项**（在页面中可勾选）：
- 高铁 G/C
- 动车 D
- 特快 T
- 快速 K
- 直达 Z
- 其他

**降级策略（3层）**：
1. **L1 — 直接 DOM 提取 + 反爬处理**：导航到火车票搜索结果页，带有效 Cookie 和合理延迟，解析 SSR DOM
2. **L2 — 从首页搜索跳转**：从飞猪首页（`https://www.fliggy.com/`）切换到火车票 tab，填写表单提交，等待跳转后提取
3. **L3 — 完整浏览器自动化**：使用浏览器自动化模拟完整用户操作（含输入、点击搜索、等待结果、筛选种类等全部步骤）

---


### 工具3: search_hotels — 酒店搜索

**功能**：搜索飞猪平台上指定城市和入住/离店日期的酒店信息。

**核心方案**：直接构造 hotel_list3.htm 搜索结果页 URL，SSR DOM 提取。

**URL 模板**：
```
https://hotel.fliggy.com/hotel_list3.htm
  ?city={城市代码}       # 城市数字代码，如 310100
  &cityName={城市名}     # 城市名称（URL编码）
  &checkIn={入住日期}    # yyyy-MM-dd
  &checkOut={离店日期}   # yyyy-MM-dd
```

> ✅ **成功率**：直接 GET 请求即可访问，**无需特殊 Cookie、无需登录、无反爬检测**。已验证上海酒店搜索成功提取 10 条数据。

**输入参数**：

| 参数 | 类型 | 必填 | 说明 | 示例 |
|------|------|------|------|------|
| `city` | string | 是 | 城市数字代码 | `310100`（上海） |
| `cityName` | string | 是 | 城市名称（URL编码） | `上海市` |
| `checkIn` | string | 是 | 入住日期 (yyyy-MM-dd) | `2026-06-20` |
| `checkOut` | string | 是 | 离店日期 (yyyy-MM-dd) | `2026-06-21` |
| `keywords` | string | 否 | 搜索关键词 | 留空则不限 |

**酒店城市代码速查**：

| 城市 | 代码 |
|------|------|
| 上海 | `310100` |
| 北京 | `110100` |
| 广州 | `440100` |
| 深圳 | `440300` |
| 杭州 | `330100` |
| 成都 | `510100` |
| 三亚 | `460200` |

**输出格式**：

```json
[
  {
    "name": "易佰酒店上海虹桥机场国展中心店",
    "price": 91,
    "score": 4.1,
    "ratingText": "优秀",
    "commentCount": "413条",
    "address": "上海市闵行区沪清平公路285号（靠近空港六路）",
    "area": "位于虹桥机场/国家会展中心",
    "starLevel": "3-舒适型",
    "tags": ["首住特惠", "F4会员专享", "全人群运营活动"],
    "bookingInfo": "21分钟前有人预订了该酒店",
    "rank": 1,
    "imageUrl": "https://...",
    "detailUrl": "https://hotel.fliggy.com/hotel_detail2.htm?..."
  }
]
```

**DOM 选择器**（建议先用 explore_dom_tree 确认当前实际类名）：

| 字段 | 可能的选择器 |
|------|-------------|
| 容器 | `//div[contains(@class, 'hotel-item')]` |
| 酒店名 | `.hotel-name` 或 `.hotel-title` |
| 价格 | `.price` 或 `.hotel-price` |
| 评分 | `.rating` 或 `.score` |
| 评价数 | `.comment-count` |
| 地址 | `.address` 或 `.hotel-addr` |
| 区域 | `.area` |
| 星级 | `.star-level` |
| 标签 | `.tags` |

**降级策略（2层）**：

1. **L1（推荐，100% 可靠）— 直接构造 URL**：
   - 拼接 `hotel.fliggy.com/hotel_list3.htm?city={code}&cityName={name}&checkIn={in}&checkOut={out}`
   - 使用 `navigate_to_url` 访问该 URL
   - 使用 `explore_dom_tree` 确认 DOM 结构
   - 使用 `cdp_extract_data` 批量提取酒店数据
   - 清洗（价格去 ¥ 变纯数字），返回结构化列表

2. **L2（备用）— 首页表单交互搜索**：
   - 访问 `https://www.fliggy.com/?tab=hotel`
   - 城市输入框：`data-testid="search-city-dropdown"` 内 combobox
   - 城市选项：`data-testid="search-city-{城市名}"`
   - 日期选择：Ant Design RangePicker（日历 Portal 挂载到 body）
   - 搜索按钮：`data-testid="domestic-search-button"`
   - 等待 SPA 跳转到 `hotel_list3.htm`，再按 L1 方式提取

**注意事项**：
- 部分请求可能触发阿里系滑块验证码（详见下方「滑块验证码处理」章节）
- `city` 参数必须使用**数字代码**（如 `310100`），不能使用城市名
- 日期必须为未来日期，且 checkOut > checkIn
- 默认排序为飞猪推荐的排序方式
- 搜索关键词 keywords 可选，可用于限定商圈或酒店名

## 城市代码对照表（机票 IATA 三字码）

| 城市 | IATA 代码 | 中文名 |
|------|-----------|--------|
| 北京 | `BJS` | 北京 |
| 上海 | `SHA` | 上海 |
| 广州 | `CAN` | 广州 |
| 深圳 | `SZX` | 深圳 |
| 杭州 | `HGH` | 杭州 |
| 成都 | `CTU` | 成都 |
| 西安 | `XIY` | 西安 |
| 重庆 | `CKG` | 重庆 |
| 昆明 | `KMG` | 昆明 |
| 三亚 | `SYX` | 三亚 |
| 厦门 | `XMN` | 厦门 |
| 南京 | `NKG` | 南京 |
| 武汉 | `WUH` | 武汉 |
| 长沙 | `CSX` | 长沙 |
| 青岛 | `TAO` | 青岛 |
| 大连 | `DLC` | 大连 |
| 哈尔滨 | `HRB` | 哈尔滨 |
| 乌鲁木齐 | `URC` | 乌鲁木齐 |

> 飞猪机票搜索使用 IATA 三字码（部分城市使用城市代码而非机场代码，如北京用 BJS 而非 PEK/PKX）。

---

## 注意事项

### 1. 反爬机制（火车票搜索）

火车票搜索页面（`train.trip.taobao.com`）存在反爬机制：
- 连续快速请求会触发"用户请求太快，请求被过滤"的提示
- **建议请求间隔**：每次查询至少间隔 3-5 秒
- **Cookie 策略**：先访问首页获取有效 Cookie，再发起搜索请求
- 建议使用完整浏览器环境而非 HTTP 客户端直接请求

### 2. 酒店搜索（✅ 已修复）

酒店搜索已从旧版 `www.fliggy.com/hotel/search.htm`（504 超时）迁移至新路径：
- **新入口**：`https://hotel.fliggy.com/hotel_list3.htm` — SSR 服务端渲染，直接 GET 请求
- **无需 Cookie / 无需登录 / 无反爬检测**
- **已验证**：上海酒店搜索成功提取 10 条完整数据
- 城市参数使用数字代码（如 `310100`），日期格式 `yyyy-MM-dd`
- 备用方式：从 `https://www.fliggy.com/?tab=hotel` 首页表单交互搜索后跳转

### 3. 浏览器环境要求

- 本 SKILL 的所有工具均需在浏览器环境中运行
- 推荐使用 Chromium 系浏览器
- 需要启用 JavaScript
- 需要支持 Cookie 维持

### 4. 频率限制

- 建议整体请求频率控制在每分钟不超过 10 次
- 同一 IP 的火车票搜索建议每分钟不超过 3 次
- 机票搜索相对宽松，但也建议合理频率

### 5. 数据时效性

- 所有数据为实时查询结果，无缓存
- 价格、余票等信息为查询时刻的快照数据
- 建议在需要时实时查询，而非长时间依赖一次查询结果

---

## 滑块验证码处理

### 触发场景
飞猪（属于阿里系平台）会在以下场景触发滑块验证码：
- **酒店搜索**（`hotel.fliggy.com/hotel_list3.htm`）：高频请求或携带 `keywords` 参数时可能触发
- **火车票搜索**（`train.trip.taobao.com`）：反爬机制的一部分
- 机票搜索相对宽松，暂未发现触发

### 识别方式
访问搜索结果页时，如果页面内容不是正常的酒店/车次/航班列表，而是出现以下特征，说明触发了验证码：
- 页面出现滑块拼图组件
- 页面标题/内容变为「安全验证」「人机验证」等
- URL 跳转到阿里系的验证域名（如 `footprint.validate.taobao.com` 等）

### 处理流程
当检测到滑块验证码时，**Agent 应按以下流程处理**：

```
检测到验证码页面
    ↓
暂停自动操作
    ↓
向用户发送提示消息："检测到飞猪滑块验证码，请手动完成页面上的滑块拼图验证，验证成功后通知我继续。"
    ↓（用户手动完成验证）
等待用户确认已通过验证
    ↓
重新读取页面内容 → 正常提取数据
```

### 触发代码示例（Agent 应参考的逻辑）

```python
# 访问搜索页后检查是否触发了验证码
page_content = read_page_content()
if "滑块" in page_content or "安全验证" in page_content or "validate" in page_content.lower():
    # 触发验证码 → 请求用户协助
    request_user_help(
        title="飞猪滑块验证码",
        message="检测到飞猪滑块验证码，请在浏览器中手动完成滑块拼图验证。",
    )
    # 用户完成后重新读取页面
    page_content = read_page_content(refresh=True)
```

### 降低触发概率的建议
1. 请求间隔 ≥ 5 秒
2. 尽量使用 L1 直接 URL 方式（比表单交互触发概率低）
3. 避免携带 `keywords` 参数
4. 维持浏览器会话（不要频繁关闭/重建浏览器）
5. 先访问飞猪首页（`www.fliggy.com`）建立 Cookie 会话，再访问搜索页

## 覆盖能力说明

| 能力 | 状态 | 说明 |
|------|------|------|
| ✈️ 国内航班搜索 | ✅ 完整覆盖 | SSR DOM 提取，已验证 68 条数据样例 |
| ✈️ 国际航班搜索 | ❌ 未覆盖 | 未验证国际航班搜索结果页结构 |
| 🚄 国内火车票搜索 | ✅ 完整覆盖 | 入口和 DOM 已确认，需处理反爬 |
| 🚄 国际火车票搜索 | ❌ 未覆盖 | 未验证 |
| 🏨 国内酒店搜索 | ✅ 完整覆盖 | hotel_list3.htm 直接 GET 访问，已验证 10 条数据样例 |
| 🏨 国际酒店搜索 | ❌ 未覆盖 | 未验证 |
| 🚌 汽车票/船票 | ❌ 未覆盖 | 未探测 |
| 🎫 景点门票 | ❌ 未覆盖 | 未探测 |
