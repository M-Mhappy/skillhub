#!/usr/bin/env python3
"""
中国法学网 (iolaw.cssn.cn) - 法律文章搜索 Loader
通过主站导航栏搜索框检索法律文章、学术著作等资料。

接口：GET /was5/web/search
返回格式：HTML（通过 BeautifulSoup 解析）
"""

import json
import os
import re
from urllib.parse import urljoin, urlencode

import requests
from bs4 import BeautifulSoup

# ── 配置 ──
BASE_URL = "http://iolaw.cssn.cn"
SEARCH_URL = urljoin(BASE_URL, "/was5/web/search")
DEFAULT_CHANNEL_ID = "213031"
PER_PAGE = 10  # 系统默认每页10条

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Referer": BASE_URL + "/",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"
}


def search_articles(keywords: str, page: int = 1, pageSize: int = 5, **kwargs) -> dict:
    """
    在中国法学网中搜索法律文章、学术著作等资料。

    Args:
        keywords: 搜索关键词（必填）
        page: 页码，从1开始（默认：1）
        pageSize: 每页结果数（默认：5，最大：10）

    Returns:
        dict: {
            "success": bool,
            "source": "中国法学网",
            "query": { ... 请求参数 },
            "total": int,          # 总结果数
            "page": int,
            "pageSize": int,
            "count": int,          # 本次返回条数
            "results": [
                {
                    "title": "文章标题",
                    "url": "文章链接",
                    "snippet": "摘要/内容预览",
                    "date": "发布日期"
                }
            ],
            "hasMore": bool
        }
    """
    # ── 参数校验 ──
    if not keywords or not keywords.strip():
        return {
            "success": False,
            "error": "关键词不能为空",
            "recoverable": True,
            "requiredAction": "请提供搜索关键词"
        }

    if pageSize > 10:
        pageSize = 10
    if pageSize < 1:
        pageSize = 5
    if page < 1:
        page = 1

    # ── 构建请求 ──
    params = {
        "searchword": keywords.strip(),
        "channelid": DEFAULT_CHANNEL_ID,
        "page": page,
        "perpage": PER_PAGE,
        "outlinepage": PER_PAGE,
    }

    try:
        resp = requests.get(SEARCH_URL, params=params, headers=HEADERS, timeout=15)
        resp.encoding = "utf-8"
    except requests.RequestException as e:
        return {
            "success": False,
            "error": f"网络请求失败：{str(e)}",
            "recoverable": True,
            "requiredAction": "请检查网络连接或稍后重试"
        }

    if resp.status_code != 200:
        return {
            "success": False,
            "error": f"服务器返回状态码：{resp.status_code}",
            "recoverable": True,
            "requiredAction": "请稍后重试"
        }

    # ── 解析 HTML ──
    soup = BeautifulSoup(resp.text, "html.parser")

    # 提取统计信息
    total = 0
    stat_text = soup.get_text()
    stat_match = re.search(r'约有(\d+)项符合', stat_text)
    if stat_match:
        total = int(stat_match.group(1))

    # 提取结果列表
    result_divs = soup.find_all("div", class_="result")
    results = []

    for div in result_divs:
        # 标题
        title_div = div.find("div", class_="title")
        if not title_div:
            continue
        title_link = title_div.find("a", href=True)
        if not title_link:
            continue

        title = title_link.get_text(strip=True)
        article_url = title_link["href"]

        # 摘要
        snippet = ""
        sum_div = div.find("div", class_="sum1")
        if sum_div:
            snippet = sum_div.get_text(strip=True)

        # 日期（从info区域提取）
        date = ""
        info_div = div.find("div", class_="info")
        if info_div:
            info_text = info_div.get_text(strip=True)
            date_match = re.search(r'(\d{4}年\d{1,2}月\d{1,2}日)', info_text)
            if date_match:
                date = date_match.group(1)

        results.append({
            "title": title,
            "url": article_url,
            "snippet": snippet,
            "date": date
        })

    # 如果要求pageSize小于实际返回，截断
    if len(results) > pageSize:
        results = results[:pageSize]

    return {
        "success": True,
        "source": "中国法学网",
        "query": {"searchword": keywords.strip(), "page": page, "pageSize": pageSize},
        "total": total,
        "page": page,
        "pageSize": pageSize,
        "count": len(results),
        "results": results,
        "hasMore": (page * PER_PAGE) < total
    }


def main():
    """命令行入口"""
    import argparse

    parser = argparse.ArgumentParser(description="中国法学网文章搜索")
    parser.add_argument("keywords", help="搜索关键词")
    parser.add_argument("--page", type=int, default=1, help="页码")
    parser.add_argument("--pageSize", type=int, default=5, help="每页数量")

    args = parser.parse_args()
    result = search_articles(
        keywords=args.keywords,
        page=args.page,
        pageSize=args.pageSize
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
