#!/usr/bin/env python3
"""
中国法学网 (iolaw.cssn.cn) - 文章内容详情 Loader
根据搜索结果的URL直接获取文章完整内容。

接口：GET 文章URL
返回格式：HTML（通过 BeautifulSoup 解析）
"""

import json
import os
import re
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

BASE_URL = "http://iolaw.cssn.cn"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Referer": BASE_URL + "/",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"
}


def get_article_detail(url: str, **kwargs) -> dict:
    """
    获取中国法学网文章的完整内容。

    Args:
        url: 文章完整URL（必填，来自搜索结果的 url 字段）

    Returns:
        dict: {
            "success": bool,
            "source": "中国法学网",
            "query": { "url": ... },
            "article": {
                "title": str,
                "content": str,         # 文章正文HTML文本
                "contentText": str,     # 纯文本版本
                "publishDate": str,     # 发布日期
                "source": str,          # 来源
                "author": str,          # 作者
                "url": str
            }
        }
    """
    if not url or not url.strip():
        return {
            "success": False,
            "error": "文章URL不能为空",
            "recoverable": True,
            "requiredAction": "请提供文章URL（来自搜索结果的 url 字段）"
        }

    url = url.strip()
    # 如果链接是相对路径，补全
    if not url.startswith("http"):
        url = urljoin(BASE_URL, url)

    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        resp.encoding = "utf-8"
    except requests.RequestException as e:
        return {
            "success": False,
            "error": f"网络请求失败：{str(e)}",
            "recoverable": True,
            "requiredAction": "请检查网络连接或稍后重试"
        }

    if resp.status_code != 200:
        return {
            "success": False,
            "error": f"服务器返回状态码：{resp.status_code}",
            "recoverable": True,
            "requiredAction": "请稍后重试"
        }

    soup = BeautifulSoup(resp.text, "html.parser")

    # ── 提取标题 ──
    title = ""
    # 尝试多种可能的标题选择器
    for sel in ["h1", ".article-title", ".title", ".bt", "#title", "h2", ".content-title"]:
        tag = soup.select_one(sel)
        if tag:
            t = tag.get_text(strip=True)
            if t and len(t) > 3:
                title = t
                break

    # ── 提取正文内容 ──
    content = ""
    content_text = ""
    for sel in [".article-content", ".content", ".text", ".con_text", "#content",
                ".detail-content", ".TRS_Editor", ".Custom_UnionStyle", "article"]:
        tag = soup.select_one(sel)
        if tag:
            content = str(tag)
            content_text = tag.get_text(separator="\n", strip=True)
            break

    # 如果没找到，尝试获取 body 的主要内容区域
    if not content:
        body = soup.find("body")
        if body:
            content_text = body.get_text(separator="\n", strip=True)
            # 去除页眉页脚等噪音
            lines = [l.strip() for l in content_text.split("\n") if l.strip() and len(l.strip()) > 5]
            content_text = "\n".join(lines)

    # ── 提取日期 ──
    publish_date = ""
    date_patterns = [
        r'(\d{4}[-/年]\d{1,2}[-/月]\d{1,2}[日]?)',
        r'发布时间[：:]\s*(\d{4}[-/]\d{1,2}[-/]\d{1,2})',
        r'日期[：:]\s*(\d{4}[-/]\d{1,2}[-/]\d{1,2})',
    ]
    page_text = soup.get_text()
    for pattern in date_patterns:
        match = re.search(pattern, page_text)
        if match:
            publish_date = match.group(1)
            break

    # ── 提取来源和作者 ──
    source = ""
    author = ""
    source_match = re.search(r'来源[：:]\s*([^\s，。,\n]{2,30})', page_text)
    if source_match:
        source = source_match.group(1)
    author_match = re.search(r'作者[：:]\s*([^\s，。,\n]{2,20})', page_text)
    if author_match:
        author = author_match.group(1)

    return {
        "success": True,
        "source": "中国法学网",
        "query": {"url": url},
        "article": {
            "title": title,
            "contentText": content_text[:10000] if content_text else "",
            "publishDate": publish_date,
            "source": source,
            "author": author,
            "url": url
        }
    }


def main():
    import argparse
    parser = argparse.ArgumentParser(description="中国法学网文章详情")
    parser.add_argument("url", help="文章URL")
    args = parser.parse_args()
    result = get_article_detail(url=args.url)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
