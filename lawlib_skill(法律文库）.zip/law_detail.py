"""
法律文库 (http://lawdb.cncourt.org) - 法规详情 API Loader

通过 Python requests 获取法规全文及详细信息。
所有API无需登录、无需浏览器会话即可直接访问。

入口函数:
    get_law_detail(params)
    get_law_full_text(keywords, page=1, search_params=None)  - 先搜索再取第一个结果的全文
"""
import sys
import re

try:
    import requests
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests

try:
    from bs4 import BeautifulSoup
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "beautifulsoup4"])
    from bs4 import BeautifulSoup

from urllib.parse import quote

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9",
}

DETAIL_URL = "http://lawdb.cncourt.org/show.php"

# 元数据提取模式（页面使用【字段名】格式）
META_PATTERNS = {
    'issuingAuthority': r'【发布单位】\s*([^\n【]+)',
    'documentNumber': r'【发布文号】\s*([^\n【]+)',
    'publishDate': r'【发布日期】\s*(\d{4}-\d{2}-\d{2})',
    'effectiveDate': r'【生效日期】\s*(\d{4}-\d{2}-\d{2})',
    'status': r'【所属类别】\s*([^\n【]+)',
    'source': r'【文件来源】\s*([^\n【]+)',
}


def _gb2312_encode(text):
    try:
        return text.encode('gb2312')
    except UnicodeEncodeError:
        return text.encode('gb2312', errors='replace')


def _extract_detail_info(html, fid="", key=""):
    """从详情页HTML中提取结构化信息"""
    soup = BeautifulSoup(html, 'html.parser')
    body = soup.find('body')
    body_text = body.get_text('\n') if body else soup.get_text('\n')

    # 从title标签获取完整标题
    title_tag = soup.find('title')
    full_title = title_tag.get_text(strip=True) if title_tag else ""
    title_clean = re.sub(r'【[\d-]+】', '', full_title).strip()

    # 提取元数据
    metadata = {}
    for field, pattern in META_PATTERNS.items():
        match = re.search(pattern, body_text)
        if match:
            value = match.group(1).strip()
            # 跳过无效值（如 -----------）
            if value and not re.match(r'^-+$', value):
                metadata[field] = value

    # 提取正文（在免责声明之前的内容）
    disclaimer_marker = "说明:本库所有资料均来源于网络"
    disclaimer_pos = body_text.find(disclaimer_marker)
    if disclaimer_pos > 0:
        text_before_disclaimer = body_text[:disclaimer_pos]
    else:
        text_before_disclaimer = body_text

    # 清理正文文本
    lines = text_before_disclaimer.split('\n')
    clean_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped:
            clean_lines.append(stripped)

    full_text = '\n'.join(clean_lines)

    # 提取章节目录
    chapters = re.findall(r'(第[一二三四五六七八九十百零\d]+章\s*[^\n]*)', full_text)

    return {
        "title": title_clean or full_title,
        "issuingAuthority": metadata.get('issuingAuthority', ''),
        "documentNumber": metadata.get('documentNumber', ''),
        "publishDate": metadata.get('publishDate', ''),
        "effectiveDate": metadata.get('effectiveDate', ''),
        "status": metadata.get('status', ''),
        "source": metadata.get('source', ''),
        "chapters": chapters,
        "chapterCount": len(chapters),
        "fullText": full_text,
        "sourceUrl": f"http://lawdb.cncourt.org/show.php?fid={fid}&key={key}"
    }


def get_law_detail(params):
    """
    获取法规详情（含全文）

    参数:
        params (dict):
            - fid (str, 必填): 法规fid
            - key (str, 可选): 搜索关键词的GB2312编码
            - keywords (str, 可选): 备用关键词
            - maxTextLength (int, 可选): 最大全文长度（默认50000）

    返回:
        dict: {
            "success": bool,
            "source": "法律文库",
            "query": dict,
            "title": str,
            "issuingAuthority": str,
            "documentNumber": str,
            "publishDate": str,
            "effectiveDate": str,
            "status": str,
            "chapters": list,
            "chapterCount": int,
            "fullText": str (全文),
            "fullTextTruncated": bool,
            "sourceUrl": str,
            "error": str (失败时),
            "recoverable": bool (失败时),
            "requiredAction": str (失败时)
        }
    """
    try:
        fid = params.get("fid", "").strip()
        if not fid:
            return {
                "success": False, "source": "法律文库", "query": params,
                "error": "缺少fid参数", "recoverable": True,
                "requiredAction": "请提供法规fid（从搜索接口获取）"
            }

        req_params = {"fid": fid}
        key = params.get("key", "")
        if key:
            req_params["key"] = key
        else:
            gb_bytes = _gb2312_encode(params.get("keywords", "法律"))
            req_params["key"] = quote(gb_bytes)

        resp = requests.get(DETAIL_URL, params=req_params, headers=HEADERS, timeout=15)

        if resp.status_code != 200:
            return {
                "success": False, "source": "法律文库", "query": params,
                "error": f"请求失败，状态码: {resp.status_code}",
                "recoverable": True, "requiredAction": "请稍后重试"
            }

        html = resp.content.decode('gb2312', errors='replace')
        detail = _extract_detail_info(html, fid, key)

        full_text = detail.get("fullText", "")
        max_len = params.get("maxTextLength", 50000)
        truncated = False
        if len(full_text) > max_len:
            full_text = full_text[:max_len] + "\n\n...(以下内容已截断)"
            truncated = True

        return {
            "success": True,
            "source": "法律文库",
            "query": params,
            "title": detail.get("title", ""),
            "issuingAuthority": detail.get("issuingAuthority", ""),
            "documentNumber": detail.get("documentNumber", ""),
            "publishDate": detail.get("publishDate", ""),
            "effectiveDate": detail.get("effectiveDate", ""),
            "status": detail.get("status", ""),
            "source": detail.get("source", ""),
            "chapters": detail.get("chapters", []),
            "chapterCount": detail.get("chapterCount", 0),
            "fullText": full_text,
            "fullTextTruncated": truncated,
            "sourceUrl": detail.get("sourceUrl", ""),
        }

    except requests.exceptions.Timeout:
        return {
            "success": False, "source": "法律文库", "query": params,
            "error": "请求超时", "recoverable": True, "requiredAction": "请稍后重试"
        }
    except requests.exceptions.ConnectionError:
        return {
            "success": False, "source": "法律文库", "query": params,
            "error": "网络连接失败", "recoverable": True, "requiredAction": "检查网络连接"
        }
    except Exception as e:
        return {
            "success": False, "source": "法律文库", "query": params,
            "error": f"获取详情失败: {str(e)}", "recoverable": False
        }


def get_law_full_text(keywords, page=1):
    """
    一站式获取法规全文：先搜索找到匹配的第一个法规，再获取全文

    参数:
        keywords (str): 搜索关键词
        page (int): 可选，如果第一页没找到可翻页

    返回:
        dict: 包含搜索结果和详情
    """
    from law_search import search_laws_simple

    search_result = search_laws_simple(keywords, page=page)
    if not search_result.get("success"):
        return search_result

    results = search_result.get("results", [])
    if not results:
        return {
            "success": False,
            "source": "法律文库",
            "query": {"keywords": keywords},
            "error": "未找到匹配的法规",
            "recoverable": True,
            "requiredAction": "请尝试其他关键词"
        }

    first = results[0]
    return get_law_detail(first.get("detailParams", {}))
