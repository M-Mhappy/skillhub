"""
法律文库 (http://lawdb.cncourt.org) - 搜索 API Loader

通过 Python requests 直接搜索中国法律法规数据。
所有API无需登录、无需浏览器会话即可直接访问。

入口函数:
    search_laws(params)
    search_laws_simple(keywords, page=1, page_size=5)
"""
import sys
import re
import json
from urllib.parse import urlencode, quote

try:
    import requests
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests

try:
    from bs4 import BeautifulSoup
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "beautifulsoup4"])
    from bs4 import BeautifulSoup

BASE_URL = "http://lawdb.cncourt.org/index.php"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9",
}


def _gb2312_encode(text):
    """将文本编码为GB2312字节"""
    try:
        return text.encode('gb2312')
    except UnicodeEncodeError:
        return text.encode('gb2312', errors='replace')


def _build_search_url(params):
    """构建GB2312编码的搜索URL"""
    query_parts = []

    law_type = params.get("type", 1)
    query_parts.append(f"type={law_type}")

    sobj = params.get("sobj", "title")
    query_parts.append(f"sobj={sobj}")

    start_year = params.get("startYear", 1949)
    end_year = params.get("endYear", 2026)
    query_parts.append(f"start_year={start_year}")
    query_parts.append(f"end_year={end_year}")

    query_parts.append("action=search")

    page = params.get("page", 1)
    query_parts.append(f"page={page}")

    keywords = params.get("keywords", "").strip()
    if keywords:
        gb_bytes = _gb2312_encode(keywords)
        gb_quoted = quote(gb_bytes)
        query_parts.append(f"keywords={gb_quoted}")

    btn_bytes = _gb2312_encode("开始搜索")
    btn_quoted = quote(btn_bytes)
    query_parts.append(f"bt_search={btn_quoted}")

    return BASE_URL + "?" + "&".join(query_parts)


def _parse_search_results(html):
    """解析搜索结果HTML，返回结果列表"""
    soup = BeautifulSoup(html, 'html.parser')
    results = []

    # 查找class="law_list"的table
    law_table = soup.find('table', class_='law_list')
    if not law_table:
        return results, 0, 1

    # 获取td内的所有文本
    law_td = law_table.find('td')
    if not law_td:
        return results, 0, 1

    td_text = law_td.get_text()

    # 提取总数和页数
    count_match = re.search(r'符合条件纪录：\s*(\d+)条，共(\d+)页', td_text)
    total = int(count_match.group(1)) if count_match else 0
    total_pages = int(count_match.group(2)) if count_match else 1

    # 提取所有链接 (class='big')
    links = law_td.find_all('a', class_='big', href=True)

    for link in links:
        href = link.get('href', '')
        title_text = link.get_text(strip=True)

        # 从标题中提取日期【YYYY-MM-DD】
        date_match = re.search(r'【(\d{4}-\d{2}-\d{2})】', title_text)
        pub_date = date_match.group(1) if date_match else ""

        # 去除标题中的日期部分
        title_clean = re.sub(r'\s*【[\d-]+】\s*', '', title_text).strip()

        # 从href中提取fid和key
        fid_match = re.search(r'fid=(\d+)', href)
        fid = fid_match.group(1) if fid_match else ""

        key_match = re.search(r'key=([^&]*)', href)
        key = key_match.group(1) if key_match else ""

        results.append({
            "fid": fid,
            "title": title_clean,
            "publishDate": pub_date,
            "url": f"http://lawdb.cncourt.org/show.php?fid={fid}&key={key}",
            "detailParams": {"fid": fid, "key": key}
        })

    return results, total, total_pages


def search_laws(params):
    """
    搜索法律法规

    参数:
        params (dict): 搜索参数
            - keywords (str, 必填): 搜索关键词
            - type (int, 可选): 法规类型，1=国家法律法规（默认）
            - sobj (str, 可选): 搜索范围，'title'=标题（默认）, 'content'=全文
            - startYear (int, 可选): 起始年份（默认1949）
            - endYear (int, 可选): 结束年份（默认2026）
            - page (int, 可选): 页码（默认1）

    返回:
        dict: {
            "success": bool,
            "source": "法律文库",
            "query": dict,
            "total": int,
            "page": int,
            "pageSize": int,
            "count": int,
            "hasMore": bool,
            "results": list,
            "error": str (失败时),
            "recoverable": bool (失败时),
            "requiredAction": str (失败时)
        }
    """
    try:
        keywords = params.get("keywords", "").strip()
        if not keywords:
            return {
                "success": False,
                "source": "法律文库",
                "query": params,
                "error": "搜索关键词不能为空",
                "recoverable": True,
                "requiredAction": "请提供搜索关键词"
            }

        page = int(params.get("page", 1))
        url = _build_search_url(params)
        resp = requests.get(url, headers=HEADERS, timeout=15)

        if resp.status_code != 200:
            return {
                "success": False,
                "source": "法律文库",
                "query": params,
                "error": f"请求失败，状态码: {resp.status_code}",
                "recoverable": True,
                "requiredAction": "请检查网络连接"
            }

        html = resp.content.decode('gb2312', errors='replace')
        results, total, total_pages = _parse_search_results(html)

        has_more = page < total_pages

        return {
            "success": True,
            "source": "法律文库",
            "query": params,
            "total": total,
            "page": page,
            "pageSize": 30,
            "count": len(results),
            "hasMore": has_more,
            "results": results
        }

    except Exception as e:
        return {
            "success": False, "source": "法律文库", "query": params,
            "error": f"搜索失败: {str(e)}", "recoverable": False
        }


def search_laws_simple(keywords, page=1, page_size=5):
    """
    简化版搜索接口

    参数:
        keywords (str): 搜索关键词
        page (int): 页码（默认1）

    返回:
        dict: 同search_laws
    """
    return search_laws({
        "keywords": keywords,
        "page": page,
        "type": 1,
        "sobj": "title"
    })
