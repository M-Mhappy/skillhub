---
name: 法律条例检索
description:本 Skill 包封装了 **法律文库 (http://lawdb.cncourt.org)** 的搜索与详情查询能力，可用于查询中国国家法律法规、司法解释、地方法规、中外条约、政策参考等法律文件的**检索**和**全文查阅**。
---

# 法律文库 Skill 包

## 规划期入口

`skills.index.json` — 包含以下2个 Skill：

| Skill ID | 名称 | 类型 | 功能 |
|---------|------|------|------|
| `law-search` | 法律法规搜索 | python_api | 按关键词搜索法律法规，支持类型、年份、搜索范围筛选 |
| `law-detail` | 法规详情查询 | python_api | 获取指定法规的完整详情和全文 |

## 能力选择

1. **先搜索**：调用 `law-search`，传入关键词（如"公司法"），获取结果列表（含法规标题、发布日期、fid）
2. **再看详情**：从搜索结果中选择目标法规，传入其 `fid` 调用 `law-detail`，即可获取完整的法规正文

## 调用方式

### 搜索法规

```python
from law_search import search_laws
result = search_laws({
    "keywords": "公司法",      # 搜索关键词（必填）
    "type": 1,                # 1=国家法律法规（默认）
    "sobj": "title",          # title=标题搜索（默认），content=全文搜索
    "page": 1                 # 页码
})
```

简化的快捷方式：

```python
from law_search import search_laws_simple
result = search_laws_simple("公司法", page=1)
```

### 获取法规详情

```python
from law_detail import get_law_detail
detail = get_law_detail({
    "fid": "156336"           # 从搜索结果中获取的法规ID
})
```

一站式获取（搜索+取第一个结果的详情）：

```python
from law_detail import get_law_full_text
result = get_law_full_text("中华人民共和国公司法")
```

## 登录/授权规则

本 Skill **完全不需要登录**。法律文库网站对所有用户公开，无需任何认证即可搜索和查看法规全文。

## 结果数量控制

- **搜索**：网站固定每页30条结果，`page` 参数控制翻页
- **详情**：全文默认最大返回50000字符，可通过 `maxTextLength` 参数调整
- Agent 默认只请求第一页搜索结果和一次详情

## 输出结构

### 搜索输出

```json
{
    "success": true,
    "source": "法律文库",
    "total": 32,
    "page": 1,
    "count": 30,
    "hasMore": true,
    "results": [
        {
            "title": "中华人民共和国公司法",
            "publishDate": "2023-12-29",
            "fid": "156336",
            "url": "http://lawdb.cncourt.org/show.php?fid=156336&key=...",
            "detailParams": {"fid": "156336", "key": "..."}
        }
    ]
}
```

### 详情输出

```json
{
    "success": true,
    "source": "法律文库",
    "title": "中华人民共和国公司法",
    "issuingAuthority": "全国人民代表大会常务委员会",
    "publishDate": "2023-12-29",
    "effectiveDate": "2024-07-01",
    "status": "国家法律法规",
    "chapters": ["第一章 总则", "第二章 公司登记", ...],
    "chapterCount": 15,
    "fullText": "【发布单位】全国人民代表大会常务委员会\n...(完整法律条文)..."
}
```

## 文件说明

| 文件 | 说明 |
|------|------|
| `SKILL.md` | 本说明文档 |
| `skills.index.json` | Skill 索引，Agent 规划期入口 |
| `references.json` | 网站接口事实、字段映射、限制说明 |
| `law_search.py` | 搜索 API Loader（Python） |
| `law_detail.py` | 详情 API Loader（Python） |

## 编码说明

法律文库网站使用 **GB2312** 编码。`law_search.py` 中的 `_build_search_url` 函数会自动将关键词编码为GB2312并进行URL编码，调用者无需手动处理编码问题。

## 限制

- **数据来源**：网站声明"本库所有资料均来源于网络、报刊等公开媒体，本文仅供参考。如需引用，请以正式文件为准。"
- **无PDF下载**：该网站不提供PDF/DOCX格式文件下载。
- **编码限制**：部分非常用汉字可能无法编码为GB2312，遇到此情况请使用其他关键词。
