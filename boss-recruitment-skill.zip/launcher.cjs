#!/usr/bin/env node
/**
 * boss-cli 启动器 — 自动解析 SKILL 内的 boss-cli 路径。
 * AI 员工只需 `node launcher.cjs <command...>` 即可，无需关心绝对路径。
 *
 * 用法：
 *   node launcher.cjs login
 *   node launcher.cjs list --unread
 *   node launcher.cjs chat 张三
 *   node launcher.cjs send --text "您好" --request-resume
 */

const { spawn } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');

const SKILL_DIR = __dirname;
const CLI_ENTRY = path.join(SKILL_DIR, 'boss-cli', 'dist', 'cli', 'index.js');
const NODE_MODULES = path.join(SKILL_DIR, 'boss-cli', 'node_modules');

// 确保依赖已安装
if (!fs.existsSync(NODE_MODULES)) {
  console.error('[launcher] 首次使用，正在安装依赖...');
  const install = require('node:child_process').spawnSync(
    process.execPath,
    [path.join(SKILL_DIR, 'boss-cli', 'node_modules', '.bin', 'npm')],
    { cwd: path.join(SKILL_DIR, 'boss-cli'), stdio: 'inherit', shell: true }
  );
  // fallback: 直接用 npm
  if (install.error || install.status !== 0) {
    const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
    require('node:child_process').spawnSync(npm, ['install'], {
      cwd: path.join(SKILL_DIR, 'boss-cli'),
      stdio: 'inherit',
      shell: true
    });
  }
}

const args = process.argv.slice(2);

const env = {
  ...process.env,
  NODE_PATH: NODE_MODULES,
};

const proc = spawn(process.execPath, [CLI_ENTRY, ...args], {
  env,
  stdio: 'inherit',
  shell: false,
});

proc.on('exit', (code) => {
  process.exit(code ?? 0);
});
