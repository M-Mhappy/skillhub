# news-search skill adapter package
from .search_adapter import (
    search, search_news, search_relevance,
    search_toutiao, search_all,
    fetch_article, fetch_articles, deep_search,
    print_results,
    report,
)
