"""
新闻搜索适配器 v2.1 — 按关键词检索中文新闻
数据源:
  [主] news.sogou.com — 搜狗新闻（元搜索），SSR 直出，无需鉴权
  [次] so.toutiao.com — 今日头条搜索 SSR 数据提取，无需鉴权

v2.1 优化:
  1. 新增 print_results() 函数，直接在对话框按「输出示例」格式输出
  2. fetch_article 检查原始字节中 JPEG/PNG 文件头，彻底杜绝二进制乱码
  3. _is_readable_text 阈值提高至 0.85，更严格过滤不可读文本
  4. report() 函数保留但内部强校验，不生成乱码文件

用法:
    from search_adapter import search, search_all, print_results

    results = search_all("量子计算", max_results=10)
    print_results(results)       # 对话框直接输出
"""

import requests
import urllib.parse
import re
import time
from bs4 import BeautifulSoup
from datetime import datetime

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/134.0.0.0 Safari/537.36"
    ),
}

# ================================================================
#  辅助函数
# ================================================================

_IMAGE_EXTENSIONS = re.compile(r"\.(jpg|jpeg|png|gif|bmp|webp|svg|ico)(\?|$)", re.I)

# v2.1: 提高阈值至 0.85
_TEXT_READABILITY_THRESHOLD = 0.85

_UNREADABLE_CHARS = re.compile(r"[^\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff"
                                r"a-zA-Z0-9\u00c0-\u024f"
                                r"\s\.\,\!\!\?\- \:\;\"\'\(\)\[\]\{\}@#\$%&+=\/\\\\|~`<>_*]")


def _is_readable_text(text: str, min_length: int = 50) -> bool:
    """判断字符串是否为可读文本（而非二进制乱码）。"""
    if not text or len(text) < min_length:
        return False
    unreadable = len(_UNREADABLE_CHARS.findall(text))
    total = len(text)
    ratio = 1 - (unreadable / total)
    has_cjk = bool(re.search(r"[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]", text))
    return ratio >= _TEXT_READABILITY_THRESHOLD and has_cjk


def _is_image_url(url: str) -> bool:
    """判断 URL 是否指向图片文件。"""
    return bool(_IMAGE_EXTENSIONS.search(url))


def _has_binary_header(raw: bytes) -> bool:
    """检查原始字节是否包含常见二进制文件头。"""
    if len(raw) < 4:
        return False
    # JPEG: FF D8 FF, PNG: 89 50 4E 47, GIF: 47 49 46, PDF: 25 50 44 46
    magic_bytes = [
        b'\xff\xd8\xff',        # JPEG
        b'\x89PNG',             # PNG
        b'GIF8',                # GIF87a / GIF89a
        b'%PDF',                # PDF
        b'\x00\x00\x00\x1c',    # MOV/MP4 常见
        b'RIFF',                # WEBP / AVI
    ]
    for magic in magic_bytes:
        if raw[:len(magic)] == magic:
            return True
    return False


# ================================================================
#  搜索层：搜狗新闻（主数据源）
# ================================================================

def search_news(query: str, max_results: int = 15, sort_by_time: bool = True) -> list[dict]:
    sort_param = "1" if sort_by_time else "0"
    url = (
        f"https://news.sogou.com/news"
        f"?query={urllib.parse.quote(query)}&sort={sort_param}"
    )
    r = requests.get(url, headers=HEADERS, timeout=15)
    r.raise_for_status()

    if "antispider" in r.url.lower():
        retry_headers = {
            **HEADERS,
            "Referer": "https://news.sogou.com/",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        }
        time.sleep(1)
        r = requests.get(url, headers=retry_headers, timeout=15)
        if "antispider" in r.url.lower():
            return []

    soup = BeautifulSoup(r.text, "html.parser")
    results = []
    seen_urls = set()

    for tag in soup.find_all(["div", "li"]):
        a_tag = tag.find("a", href=True)
        if not a_tag:
            continue
        title = a_tag.get_text(strip=True)
        href = a_tag["href"]
        if len(title) < 8 or not href.startswith("http") or href in seen_urls:
            continue
        seen_urls.add(href)

        source_tag = tag.find(["span", "a"], class_=re.compile(r"site", re.I))
        source = source_tag.get_text(strip=True) if source_tag else ""

        time_match = re.search(
            r"(\d{4}[-/年]\d{1,2}[-/月]\d{1,2})|(\d+[小时天分钟前]+)",
            tag.get_text()
        )
        date = time_match.group(0) if time_match else ""

        snippet = ""
        for p in tag.find_all(["p", "div", "span"]):
            text = p.get_text(strip=True)
            if len(text) > 30 and text != title:
                snippet = text[:250]
                break

        results.append({
            "title": title,
            "url": href,
            "snippet": snippet,
            "source": source,
            "date": date,
            "backend": "sogou",
        })
        if len(results) >= max_results:
            break

    return results


# ================================================================
#  搜索层：今日头条（次数据源）
# ================================================================

def search_toutiao(query: str, max_results: int = 10) -> list[dict]:
    url = (
        f"https://so.toutiao.com/search"
        f"?keyword={urllib.parse.quote(query)}&pd=synthesis"
    )
    r = requests.get(url, headers=HEADERS, timeout=15)
    r.raise_for_status()

    html = r.text
    script_pattern = r'<script[^>]*data-id="([^"]*)"[^>]*>(.*?)</script>'
    scripts = re.findall(script_pattern, html, re.DOTALL)

    results = []
    seen_urls = set()

    for data_id, content in scripts:
        m_data = re.search(r'data\s*:\s*(\{.*\})\s*\}', content, re.DOTALL)
        if not m_data:
            continue
        json_str = m_data.group(1)

        m_title = re.search(r'"title"\s*:\s*"((?:\\.|[^"\\\\])*)"', json_str)
        m_host = re.search(r'"host"\s*:\s*"((?:\\.|[^"\\\\])*)"', json_str)
        m_url = re.search(r'"url"\s*:\s*"((?:\\.|[^"\\\\])*)"', json_str)
        m_type = re.search(r'"type"\s*:\s*"([^"]*)"', json_str)
        m_snippet = re.search(r'"abstract"\s*:\s*"((?:\\.|[^"\\\\])*)"', json_str)

        title = m_title.group(1) if m_title else ""
        href = m_url.group(1) if m_url else ""
        typ = m_type.group(1) if m_type else ""
        snippet = m_snippet.group(1) if m_snippet else ""

        title = title.replace("\\u003cem\\u003e", "").replace("\\u003c/em\\u003e", "")
        snippet = snippet.replace("\\u003cem\\u003e", "").replace("\\u003c/em\\u003e", "")

        if not title or len(title) < 6:
            continue
        if typ.startswith("ala"):
            continue
        if href in seen_urls:
            continue
        if _is_image_url(href):
            continue

        seen_urls.add(href)
        source = (m_host.group(1) if m_host else "") or "今日头条"

        results.append({
            "title": title[:120],
            "url": href[:300],
            "snippet": snippet[:200] if snippet else "",
            "source": source,
            "date": "",
            "backend": "toutiao",
        })
        if len(results) >= max_results:
            break

    return results


# ================================================================
#  复合搜索
# ================================================================

def search_all(query: str, max_results: int = 15) -> list[dict]:
    """双源搜索去重合并（搜狗 + 头条）"""
    results = []
    seen_urls = set()
    try:
        sogou_results = search_news(query, max_results=max_results)
        for item in sogou_results:
            url = item["url"][:300]
            if url not in seen_urls:
                seen_urls.add(url)
                results.append(item)
    except Exception:
        pass
    if len(results) >= max_results:
        return results[:max_results]
    try:
        tt_results = search_toutiao(query, max_results=max_results)
        for item in tt_results:
            url = item["url"][:300]
            if url not in seen_urls:
                seen_urls.add(url)
                results.append(item)
            if len(results) >= max_results:
                break
    except Exception:
        pass
    return results[:max_results]


# ================================================================
#  内容层：全文拉取（v2.1 加强版）
# ================================================================

def fetch_article(url: str, max_chars: int = 3000) -> str:
    """
    拉取新闻文章全文。
    v2.1: 检查原始字节中二进制文件头，彻底杜绝乱码。
    """
    try:
        domain = urllib.parse.urlparse(url).netloc
        h = {**HEADERS, "Referer": f"https://{domain}/"}
        r = requests.get(url, headers=h, timeout=10, allow_redirects=True, stream=True)
        if r.status_code != 200:
            return ""
        content_type = r.headers.get("Content-Type", "").lower()
        if "image" in content_type or "octet-stream" in content_type:
            return ""
        raw = r.content
        if len(raw) < 200:
            return ""
        # v2.1: 检查二进制文件头
        if _has_binary_header(raw):
            return ""
        text = ""
        for enc in ("utf-8", "gbk", "gb2312", "latin-1"):
            try:
                text = raw.decode(enc)
                break
            except (UnicodeDecodeError, LookupError):
                continue
        if not text:
            return ""
        if not _is_readable_text(text, min_length=100):
            return ""
        soup = BeautifulSoup(text, "html.parser")
        clean_text = soup.get_text(separator="\\n", strip=True)
        lines = [l.strip() for l in clean_text.split("\\n") if l.strip() and len(l.strip()) > 15]
        result = "\\n".join(lines)[:max_chars]
        if not _is_readable_text(result, min_length=50):
            return ""
        return result
    except Exception:
        return ""


def fetch_articles(results: list[dict], top_n: int = 5, max_chars: int = 2000) -> list[dict]:
    for i, item in enumerate(results):
        if i >= top_n:
            break
        item["full_text"] = fetch_article(item["url"], max_chars)
    return results


def deep_search(query: str, max_results: int = 10, fetch_top: int = 3) -> list[dict]:
    results = search_all(query, max_results=max_results)
    if fetch_top > 0:
        results = fetch_articles(results, top_n=fetch_top)
    return results


# ================================================================
#  ★ 新增：对话框输出函数（严格按 SKILL 输出示例格式）★
# ================================================================

def print_results(results: list[dict], max_snippet: int = 180) -> None:
    """
    将搜索结果按「输出示例」格式直接打印到对话框。

    格式:
        ## 标题
        🏷️ 来源  |  📅 时间  |  [搜狗/头条]
        🔗 链接（原文链接）
        > 摘要...
        ---

    Args:
        results: search / search_all / deep_search 返回的结果列表
        max_snippet: 摘要最大字符数，默认 180
    """
    for item in results:
        title = item['title'].replace('\\n', ' ').strip()
        src = item.get('source') or '全网'
        date = item.get('date') or '近期'
        be = '搜狗' if item.get('backend') == 'sogou' else '头条'
        url = item.get('url', '')
        snip = item['snippet'].replace('\\n', ' ').strip() if item.get('snippet') else ''

        if len(snip) > max_snippet:
            snip = snip[:max_snippet] + '...'

        print(f"## {title}")
        print(f"🏷️ {src}  |  📅 {date}  |  [{be}]")
        if url:
            print(f"🔗 {url}（原文链接）")
        if snip:
            print(f"> {snip}")
        print("---")
        print()


# ================================================================
#  报告生成（保留但强校验，不生成乱码）
# ================================================================

def report(query: str, max_results: int = 10) -> str:
    """生成 Markdown 格式报告。v2.1: 全文本强校验，杜绝乱码。"""
    results = deep_search(query, max_results=max_results, fetch_top=3)
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    sources = set(item.get("backend", "?") for item in results)
    source_str = ", ".join(sorted(sources))

    lines = [
        f"# 🔍 新闻搜索: {query}",
        f"> 搜索时间: {now}  |  数据源: {source_str}",
        f"> 共 {len(results)} 条结果",
        "",
    ]

    for i, item in enumerate(results, 1):
        lines.append(f"## {i}. {item['title']}")
        lines.append(f"- 📎 {item['url']}")
        parts = []
        if item.get("source"):
            parts.append(item["source"])
        if item.get("date"):
            parts.append(item["date"])
        if item.get("backend"):
            parts.append(f"[{item['backend']}]")
        if parts:
            lines.append(f"- {' · '.join(parts)}")
        if item.get("snippet"):
            lines.append(f"- 📝 {item['snippet'][:200]}")

        full_text = item.get("full_text", "")
        if full_text and _is_readable_text(full_text, min_length=50):
            quoted = full_text[:300].replace("\\n", "\\n> ")
            lines.append(f"\\n> {quoted}")
        lines.append("")

    return "\\n".join(lines)


# ================================================================
#  快捷函数
# ================================================================

def search(query: str, n: int = 10) -> list[dict]:
    return search_news(query, max_results=n, sort_by_time=True)

def search_relevance(query: str, n: int = 10) -> list[dict]:
    return search_news(query, max_results=n, sort_by_time=False)
