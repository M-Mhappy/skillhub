---
name: news-search
description: 中文新闻关键词搜索。双源：搜狗新闻（主，元搜索覆盖全网） + 今日头条（次，SSR 数据提取）。纯 Python，零依赖，零鉴权。
version: 2.1.0
author: news-search-skill
tags: [news, search, sogou-news, toutiao, news-search, chinese-news]
---

# news-search — 中文新闻关键词搜索

纯 Python 实现，无需 API Key、无需登录。解压后直接在 `execute_python` 中 `import` 即可。

---

## 🚀 快速上手

```python
import sys, os
sys.path.insert(0, "adapters")

from search_adapter import search, search_all, deep_search, print_results

# 1️⃣ 搜狗新闻搜索（主源，结果多，覆盖全网）
results = search("量子计算", n=10)
# → [{title, url, snippet, source, date, backend}, ...]

# 2️⃣ 双源合并去重（推荐）
results = search_all("量子计算", max_results=15)

# 3️⃣ ✅ 直接在对话框输出（推荐用法，无乱码）
results = search_all("量子计算", max_results=10)
print_results(results)

# 4️⃣ 搜索 + 自动拉取前3条全文
results = deep_search("量子计算", max_results=10, fetch_top=3)
```

---

## 📖 全部 API

### 🔍 搜索函数

| 函数 | 用途 | 数据源 | 结果数 |
|------|------|:------:|:------:|
| `search(query, n=10)` | 快速搜索（按时间） | 搜狗新闻 | 多 |
| `search_news(query, max_results=15, sort_by_time=True)` | 完整参数搜索 | 搜狗新闻 | 多 |
| `search_relevance(query, n=10)` | 按相关性排序 | 搜狗新闻 | 多 |
| `search_toutiao(query, max_results=10)` | 今日头条 SSR 搜索 | 今日头条 | 少(0~5) |
| `search_all(query, max_results=15)` | 双源合并去重 | 搜狗新闻+头条 | 最多 |

### 🖨️ 对话框输出（★ 新增推荐）

| 函数 | 用途 |
|------|------|
| `print_results(results, max_snippet=180)` | 将搜索结果按「输出示例」格式直接打印到对话框 |

### 📄 全文拉取

| 函数 | 用途 |
|------|------|
| `fetch_article(url, max_chars=3000)` | 拉取单篇文章全文（仅 SSR 站点） |
| `fetch_articles(results, top_n=5)` | 批量拉取前 N 篇全文 |
| `deep_search(query, max_results=10, fetch_top=3)` | 搜索 + 全文一步到位 |

### 📊 报告生成（保留，内部做强校验防乱码）

| 函数 | 用途 |
|------|------|
| `report(query, max_results=10)` | 生成 Markdown 格式的搜索结果报告 |

---

## 📦 返回字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `title` | str | 新闻标题 |
| `url` | str | 文章链接 |
| `snippet` | str | 搜索摘要（≤250字） |
| `source` | str | 来源站点名称 |
| `date` | str | 发布时间（仅搜狗新闻提供） |
| `backend` | str | 来源: `sogou` 或 `toutiao` |
| `full_text` | str | 全文（仅 `deep_search` / `fetch_article` 后出现） |

---

## 🎯 数据源说明

| 数据源 | 后端 | 方式 | 结果量 | 特点 |
|:------:|:----:|:----:|:------:|------|
| **搜狗新闻** 🏆 | `news.sogou.com` | HTML SSR 解析 | 10~15+ | 元搜索引擎，覆盖全中文新闻网（腾讯、搜狐、新浪、网易、凤凰等），纯 SSR 直出 |
| **今日头条** | `so.toutiao.com` | SSR 数据提取 | 0~5 | 补充不同来源，无需任何鉴权 |

---

## 💡 推荐用法（对话框直接输出）

```python
from search_adapter import search_all, print_results

results = search_all("你的关键词", max_results=15)
print_results(results)
```

**输出示例**：
```markdown
## 当AI开始"干活"
🏷️ 中国经济周刊  |  📅 16小时前  |  [搜狗]
🔗 https://example.com/article（原文链接）
> 凌晨1点，深圳南山科技园的一间写字楼里，34岁的后端工程师...（40-200字核心概要）
---
```

---

## 📊 使用场景示例

### 场景 1：用户问「高考有什么热点新闻」

```python
from search_adapter import search_all, print_results

results = search_all("2026年 高考", max_results=10)
print_results(results)
```

### 场景 2：搜索 + 全文预览

```python
from search_adapter import deep_search

results = deep_search("量子计算", max_results=10, fetch_top=3)
for i, item in enumerate(results, 1):
    print(f"{i}. [{item['backend']}] {item['title']}")
    if item.get("full_text"):
        print(f"   📄 全文预览: {item['full_text'][:100]}...")
```

### 场景 3：批量拉取全文做分析

```python
from search_adapter import search_news, fetch_articles

results = search_news("量子计算 突破", max_results=5)
results = fetch_articles(results, top_n=5, max_chars=2000)

for item in results:
    print(f"📰 {item['title']}")
    if item.get("full_text"):
        # 做 NLP 分析...
        pass
```

---

## 📁 文件结构

```
news_search_skill/
├── SKILL.md
└── adapters/
    ├── __init__.py
    └── search_adapter.py       # 双源搜索 + 全文拉取 + print_results
```

---

## 🔧 故障排查

| 症状 | 原因 | 解决 |
|------|------|------|
| 搜狗新闻返回 0 条 | ip不纯净，梯子原因 | 提示用户关闭梯子，用国内端口 |
| 今日头条返回 0 条 | SSR 数据有限或无命中 | 改用 `search()` 或 `search_all()` |
| 搜狗新闻请求被拦截 | IP 触发反爬（偶发） | 稍后重试或用浏览器先访问一次 news.sogou.com 再试 |
| 全文拉取为空 | 目标站是 JS 渲染 SPA | 跳过全文，仅用搜索结果 |
| 全部返回 0 条 | 无网络连接 | 检查外网 |
| `ImportError: no module` | 路径不对 | `sys.path.insert(0, "adapters")` 指向 adapters 目录 |
