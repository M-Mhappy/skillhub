# newsget adapters package
