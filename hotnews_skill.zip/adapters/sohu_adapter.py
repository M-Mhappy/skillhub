
"""
搜狐新闻适配器 — 通用执行专员
通过 odin.sohu.com/odin/api/blockdata 获取热榜数据。
公开 API，无需登录，无需 Cookie。
"""

import requests
import time
import json
from typing import Optional

BASE = "https://odin.sohu.com/odin/api/blockdata"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36")

_BLOCKS = {
    "daily": {  # 热门新闻-日榜
        "key": "TPLCommonSidebar_8_0_pc_1647874300216_data0",
        "productId": "1485", "productType": "13", "size": 30,
        "view": "feedMode", "innerTag": "channel",
        "label": "搜狐新闻-日榜"
    },
    "weekly": {  # 热门新闻-周榜
        "key": "TPLCommonSidebar_8_0_pc_1647874300216_data1",
        "productId": "1484", "productType": "13", "size": 30,
        "view": "feedMode", "innerTag": "channel",
        "label": "搜狐新闻-周榜"
    },
    "politics": {  # 时政榜
        "key": "TPLLayout_7_1_pc_1647873963058_data0",
        "productId": "55598", "productType": "15", "size": 10,
        "view": "feedMode", "innerTag": "news-slice", "pro": "0,1,3,4,5", "feedType": "XTOPIC_SYNTHETICAL",
        "label": "搜狐新闻-时政榜"
    },
}


def _session():
    s = requests.Session()
    s.headers.update({
        "User-Agent": UA,
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Content-Type": "application/json;charset=UTF-8",
        "Referer": "https://news.sohu.com/",
        "Origin": "https://news.sohu.com",
    })
    return s


def _build_body(blocks, size_override=None):
    ts = str(int(time.time() * 1000))
    pid = f"1781596{ts[-7:]}"
    resource_list = []
    for b in blocks:
        cfg = _BLOCKS[b].copy()
        content = {
            "productId": cfg["productId"],
            "productType": cfg["productType"],
            "size": size_override or cfg["size"],
            "pro": cfg.get("pro", ""),
            "feedType": cfg.get("feedType", ""),
            "view": cfg["view"],
            "innerTag": cfg["innerTag"],
            "spm": f"smpc.channel_258.{cfg['productId']}",
            "page": 1,
            "requestId": f"{pid}_{cfg['productId']}"
        }
        resource_list.append({
            "tplCompKey": cfg["key"],
            "isServerRender": False,
            "configSource": "mp",
            "content": content,
            "adInfo": {},
            "context": {"mkey": ""}
        })

    return {
        "pvId": f"{pid}_adapter",
        "pageId": f"{pid}_adapter",
        "mainContent": {
            "productType": "13", "productId": "1090",
            "secureScore": 50, "categoryId": "47",
            "adTags": "20000114", "authorId": 121135924
        },
        "resourceList": resource_list
    }


def _parse_items(block):
    """从 block 中提取条目列表"""
    items = []
    for item in block.get("list", []):
        items.append({
            "title": item.get("title", ""),
            "url": item.get("url", ""),
            "brief": (item.get("brief") or "")[:200],
            "id": item.get("id", ""),
        })
    return items


def hot_daily(limit: int = 15) -> list:
    """搜狐热门新闻-日榜"""
    body = _build_body(["daily"], size_override=limit)
    r = _session().post(BASE, json=body, timeout=15)
    r.raise_for_status()
    data = r.json()
    if data.get("code") != 0:
        raise RuntimeError(f"API error: {data.get('message')}")
    block = data.get("data", {}).get(_BLOCKS["daily"]["key"], {})
    return _parse_items(block)


def hot_weekly(limit: int = 15) -> list:
    """搜狐热门新闻-周榜"""
    body = _build_body(["weekly"], size_override=limit)
    r = _session().post(BASE, json=body, timeout=15)
    r.raise_for_status()
    data = r.json()
    if data.get("code") != 0:
        raise RuntimeError(f"API error: {data.get('message')}")
    block = data.get("data", {}).get(_BLOCKS["weekly"]["key"], {})
    return _parse_items(block)


def hot_politics(limit: int = 10) -> list:
    """搜狐时政榜"""
    body = _build_body(["politics"], size_override=limit)
    r = _session().post(BASE, json=body, timeout=15)
    r.raise_for_status()
    data = r.json()
    if data.get("code") != 0:
        raise RuntimeError(f"API error: {data.get('message')}")
    block = data.get("data", {}).get(_BLOCKS["politics"]["key"], {})
    return _parse_items(block)


def hot_all(limit_each: int = 10) -> dict:
    """一次拉取所有榜单"""
    body = _build_body(["daily", "weekly", "politics"],
                       size_override=limit_each)
    r = _session().post(BASE, json=body, timeout=15)
    r.raise_for_status()
    data = r.json()
    if data.get("code") != 0:
        raise RuntimeError(f"API error: {data.get('message')}")
    result = {}
    for bid, cfg in _BLOCKS.items():
        block = data.get("data", {}).get(cfg["key"], {})
        result[cfg["label"]] = _parse_items(block)
    return result


def report() -> str:
    """生成 Markdown 热榜报告"""
    all_data = hot_all(limit_each=15)
    lines = [
        "# 🔥 搜狐新闻热榜",
        f"> 更新时间: {time.strftime('%Y-%m-%d %H:%M')}",
        f"> 数据来源: news.sohu.com | odin.sohu.com",
        ""
    ]
    for label, items in all_data.items():
        emoji = {"日榜": "📅", "周榜": "📊", "时政榜": "🏛️"}.get(
            label.split("-")[-1], "📰")
        lines.append(f"## {emoji} {label}  ({len(items)}条)")
        lines.append("")
        lines.append("| # | 标题 |")
        lines.append("|---|------|")
        for i, item in enumerate(items, 1):
            title = item["title"][:55]
            lines.append(f"| {i} | {title} |")
        lines.append("")
    return "\n".join(lines)


if __name__ == "__main__":
    # 快速测试
    print("=== 日榜 ===")
    for i, item in enumerate(hot_daily(10), 1):
        print(f"  {i}. {item['title'][:60]}")
    print("\n=== 周榜 ===")
    for i, item in enumerate(hot_weekly(5), 1):
        print(f"  {i}. {item['title'][:60]}")
    print("\n=== 时政榜 ===")
    for i, item in enumerate(hot_politics(5), 1):
        print(f"  {i}. {item['title'][:60]}")
    print("\n✅ 搜狐适配器自测通过")
