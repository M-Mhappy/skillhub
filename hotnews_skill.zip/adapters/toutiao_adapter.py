"""
今日头条适配器 — 纯 Python 公开 API，无需登录。
基于浏览器抓包逆向封装。

用法:
    from toutiao_adapter import ToutiaoAdapter
    tt = ToutiaoAdapter()

    # 1. 热搜榜 (公开 API)
    hot = tt.get_hot_board(limit=20)

    # 2. 搜索热词 (公开 API)
    words = tt.get_hot_words()

    # 3. Markdown 报告
    print(tt.get_full_report(15))
"""

import requests
import time
from typing import Optional


class ToutiaoAdapter:
    """今日头条公开 API 适配器"""

    BASE = "https://www.toutiao.com"

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/134.0.0.0 Safari/537.36"
            ),
            "Referer": "https://www.toutiao.com/",
        })
        # 预取 cookie（防部分接口空返）
        try:
            self.session.get(self.BASE, timeout=10)
        except Exception:
            pass

    # ---- 内部 ----

    def _get(self, path: str, params: Optional[dict] = None) -> dict:
        url = f"{self.BASE}{path}"
        resp = self.session.get(url, params=params or {}, timeout=15)
        resp.raise_for_status()
        return resp.json()

    # ---- 公开接口 ----

    def get_hot_board(self, limit: int = 20) -> list[dict]:
        """
        获取今日头条热搜榜（公开 API，无鉴权）。

        Args:
            limit: 返回条数 (最大 50)

        Returns:
            [{title, hot_value, label, query_id, url, category, image}, ...]
        """
        data = self._get("/hot-event/hot-board/", {"origin": "toutiao_pc"})
        items = data.get("data", [])[:limit]
        return [
            {
                "title":      it.get("Title", ""),
                "hot_value":  int(it.get("HotValue", 0)),
                "label":      it.get("Label", ""),
                "query_id":   str(it.get("ClusterId", "")),
                "url":        it.get("Url", ""),
                "category":   it.get("InterestCategory", []),
                "image":      (it.get("Image") or {}).get("url", ""),
            }
            for it in items
        ]

    def get_hot_words(self) -> list[dict]:
        """
        获取搜索热词（10 条，公开 API）。

        Returns:
            [{query: 热词}, ...]
        """
        data = self._get("/search/suggest/hot_words/")
        return [
            {"query": it.get("query", "")}
            for it in data.get("data", [])
        ]

    # ---- 复合方法 ----

    def format_hot(self, limit: int = 20) -> str:
        """返回热搜榜纯文本（适合打印）。"""
        hot = self.get_hot_board(limit=limit)
        now = time.strftime("%Y-%m-%d %H:%M")
        lines = [f"{'='*60}", f"🔥 今日头条热搜 TOP {len(hot)}  |  {now}", f"{'='*60}"]
        for i, item in enumerate(hot, 1):
            prefix = {1: "🥇", 2: "🥈", 3: "🥉"}.get(i, f"{i:>2}.")
            tags = f" [{item['label']}]" if item['label'] else ""
            cat = ", ".join(item['category']) if item['category'] else "-"
            lines.append(f"{prefix} {item['title']}")
            lines.append(f"   热度:{item['hot_value']:,}{tags}  分类:{cat}")
        return "\n".join(lines)

    def get_full_report(self, top_n: int = 10) -> str:
        """
        生成完整 Markdown 报告：热搜榜 + 热词。

        Returns:
            Markdown 字符串
        """
        hot = self.get_hot_board(top_n)
        words = self.get_hot_words()

        now = time.strftime("%Y-%m-%d %H:%M")
        lines = [
            f"# 🔥 今日头条热搜 TOP {top_n}",
            f"> 更新时间: {now}  |  数据来源: toutiao.com/hot-event/hot-board",
            "",
            "| # | 词条 | 热度 | 标签 | 分类 |",
            "|---|------|------|------|------|",
        ]
        for i, item in enumerate(hot, 1):
            tags = f"`{item['label']}`" if item['label'] else ""
            cat = ", ".join(item['category'][:2]) if item['category'] else "-"
            lines.append(
                f"| {i} | {item['title']} | {item['hot_value']:,} | {tags} | {cat} |"
            )

        lines.extend([
            "",
            "---",
            "",
            "## 🔍 搜索热词",
            "",
        ])
        for i, w in enumerate(words, 1):
            lines.append(f"{i}. {w['query']}")

        lines.extend([
            "",
            "---",
            "",
            "## 📊 API 说明",
            "",
            "| API | URL | 鉴权 |",
            "|-----|-----|------|",
            "| 热搜榜 | `/hot-event/hot-board/` | ❌ 无需 |",
            "| 搜索热词 | `/search/suggest/hot_words/` | ❌ 无需 |",
            "| 文章详情 | `/api/pc/list/feed` | ⚠️ 需浏览器 msToken |",
            "",
            "> **适配器文件**: `toutiao_adapter.py`  ",
            "> **使用**: `from toutiao_adapter import ToutiaoAdapter`  ",
            "> **接口数**: 3 (2 公开 + 1 需浏览器)",
        ])

        return "\n".join(lines)


# ========== 快捷函数 ==========

def hot(limit: int = 20) -> list[dict]:
    """快速获取热搜榜"""
    return ToutiaoAdapter().get_hot_board(limit)


def words() -> list[dict]:
    """快速获取搜索热词"""
    return ToutiaoAdapter().get_hot_words()


# ========== 自测 ==========

if __name__ == "__main__":
    tt = ToutiaoAdapter()
    print(tt.format_hot(15))
    print()
    print("🔍 搜索热词:")
    for w in tt.get_hot_words():
        print(f"  · {w['query']}")
