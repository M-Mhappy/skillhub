"""
知乎适配器 — 纯 Python 公开 API，无需登录。
基于 api.zhihu.com 抓包逆向封装。

用法:
    from zhihu_adapter import ZhihuAdapter
    zh = ZhihuAdapter()

    # 热搜榜
    hot = zh.get_hot(limit=15)

    # 月榜
    month = zh.get_monthly(limit=10)

    # Markdown 报告
    print(zh.get_full_report(15))
"""

import requests
import time
from typing import Optional


class ZhihuAdapter:
    """知乎公开 API 适配器"""

    BASE = "https://api.zhihu.com"

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/134.0.0.0 Safari/537.36"
            ),
            "Referer": "https://www.zhihu.com/",
        })

    # ---- 内部 ----

    def _get(self, path: str, params: Optional[dict] = None) -> dict:
        url = f"{self.BASE}{path}"
        resp = self.session.get(url, params=params or {}, timeout=15)
        resp.raise_for_status()
        return resp.json()

    def _parse_items(self, data: dict) -> list[dict]:
        """统一解析 data 列表"""
        items = data.get("data", [])
        results = []
        for it in items:
            target = it.get("target", {})
            author = target.get("author", {})
            card_label = it.get("card_label", {})

            results.append({
                "id":              target.get("id", 0),
                "title":           target.get("title", ""),
                "url":             f"https://www.zhihu.com/question/{target.get('id', '')}",
                "excerpt":         target.get("excerpt", ""),
                "type":            target.get("type", ""),
                "heat":            it.get("detail_text", ""),
                "answer_count":    int(target.get("answer_count", 0)),
                "follower_count":  int(target.get("follower_count", 0)),
                "comment_count":   int(target.get("comment_count", 0)),
                "author":          author.get("name", ""),
                "author_headline": author.get("headline", ""),
                "author_avatar":   author.get("avatar_url", ""),
                "card_label":      card_label.get("type", ""),
                "created":         int(target.get("created", 0)),
            })
        return results

    # ---- 公开接口 ----

    def get_hot(self, limit: int = 30) -> list[dict]:
        """
        知乎热搜榜（公开 API，无鉴权）。

        Args:
            limit: 返回条数 (最大 30)

        Returns:
            [{title, heat, url, excerpt, answer_count, follower_count, author, ...}, ...]
        """
        data = self._get("/topstory/hot-lists/total", {"limit": min(limit, 50)})
        return self._parse_items(data)[:limit]

    def get_monthly(self, limit: int = 30) -> list[dict]:
        """
        知乎月榜（公开 API）。

        Args:
            limit: 返回条数
        """
        data = self._get("/topstory/hot-lists/month", {"limit": min(limit, 50)})
        return self._parse_items(data)[:limit]

    def get_recommend(self, limit: int = 12) -> list[dict]:
        """
        知乎推荐列表（公开 API，支持翻页）。

        Args:
            limit: 返回条数
        """
        all_items = []
        after_id = None
        while len(all_items) < limit:
            params = {"limit": min(limit - len(all_items), 12)}
            if after_id:
                params["after_id"] = after_id
            data = self._get("/topstory/recommend", params)
            items = self._parse_items(data)[: limit - len(all_items)]
            if not items:
                break
            all_items.extend(items)
            if not after_id:
                after_id = len(items)
            else:
                after_id += len(items)
        return all_items[:limit]

    # ---- 复合方法 ----

    def format_hot(self, limit: int = 20) -> str:
        """返回热搜榜纯文本"""
        hot = self.get_hot(limit=limit)
        now = time.strftime("%Y-%m-%d %H:%M")
        lines = [f"{'='*60}", f"🔥 知乎热搜 TOP {len(hot)}  |  {now}", f"{'='*60}"]
        for i, item in enumerate(hot, 1):
            prefix = {1: "🥇", 2: "🥈", 3: "🥉"}.get(i, f"{i:>2}.")
            lines.append(f"{prefix} {item['title']}")
            lines.append(f"   {item['heat']} | {item['answer_count']} 回答 | {item['follower_count']} 关注")
            if item['excerpt']:
                lines.append(f"   {item['excerpt'][:100]}...")
        return "\n".join(lines)

    def get_full_report(self, top_n: int = 15) -> str:
        """
        生成完整 Markdown 报告。
        """
        hot = self.get_hot(top_n)
        now = time.strftime("%Y-%m-%d %H:%M")

        lines = [
            f"# 🔥 知乎热搜 TOP {top_n}",
            f"> 更新时间: {now}  |  数据来源: api.zhihu.com/topstory/hot-lists/total",
            "",
            "| # | 问题 | 热度 | 回答 | 关注 |",
            "|---|------|------|------|------|",
        ]
        for i, item in enumerate(hot, 1):
            title = item['title'][:40] + "..." if len(item['title']) > 40 else item['title']
            lines.append(
                f"| {i} | [{title}]({item['url']}) | {item['heat']} | {item['answer_count']} | {item['follower_count']} |"
            )

        lines.extend([
            "",
            "---",
            "",
            "## 📝 详情",
            "",
        ])
        for i, item in enumerate(hot, 1):
            lines.append(f"### {i}. {item['title']}")
            lines.append(f"- 🔥 {item['heat']} · {item['answer_count']} 回答 · {item['follower_count']} 关注")
            if item['author']:
                lines.append(f"- ✍️ {item['author']}" + (f" · {item['author_headline']}" if item['author_headline'] else ""))
            if item['excerpt']:
                lines.append(f"- 📖 {item['excerpt'][:200]}")
            lines.append(f"- 🔗 {item['url']}")
            lines.append("")

        # 接口说明
        lines.extend([
            "---",
            "",
            "## 📊 API 说明",
            "",
            "| API | URL | 鉴权 |",
            "|-----|-----|:---:|",
            "| 热搜榜 | `api.zhihu.com/topstory/hot-lists/total` | ❌ 公开 |",
            "| 月榜 | `api.zhihu.com/topstory/hot-lists/month` | ❌ 公开 |",
            "| 推荐 | `api.zhihu.com/topstory/recommend` | ❌ 公开 |",
            "",
            "> **适配器文件**: `zhihu_adapter.py`  ",
            "> **使用**: `from zhihu_adapter import ZhihuAdapter`  ",
        ])
        return "\n".join(lines)


# ========== 快捷函数 ==========

def hot(limit: int = 20) -> list[dict]:
    """快速获取知乎热搜"""
    return ZhihuAdapter().get_hot(limit)


def monthly(limit: int = 20) -> list[dict]:
    """快速获取知乎月榜"""
    return ZhihuAdapter().get_monthly(limit)


if __name__ == "__main__":
    zh = ZhihuAdapter()
    print(zh.format_hot(15))
