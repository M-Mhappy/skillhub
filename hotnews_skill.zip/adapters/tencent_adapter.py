
"""
腾讯新闻热榜适配器
API: i.news.qq.com/web_feed/getHotModuleList (POST, 无需鉴权)
"""

import requests
from datetime import datetime

API_URL = "https://i.news.qq.com/web_feed/getHotModuleList"
HEADERS = {
    "Content-Type": "application/json",
    "Referer": "https://news.qq.com/",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
}

CHANNELS = {
    "top": "news_news_top",
    "hot": "news_news_hot",
    "ent": "news_news_ent",
    "sports": "news_news_sports",
    "finance": "news_news_finance",
    "tech": "news_news_tech",
    "rank": "news_news_rank",
}

CHANNEL_NAMES = {
    "top": "要闻",
    "hot": "热点精选",
    "ent": "娱乐",
    "sports": "体育",
    "finance": "财经",
    "tech": "科技",
    "rank": "排行",
}


def _fetch(channel_id: str, count: int = 20) -> list:
    """拉取指定频道热榜"""
    body = {
        "base_req": {"from": "pc"},
        "forward": "2",
        "flush_num": 1,
        "channel_id": channel_id,
        "item_count": count,
    }
    r = requests.post(API_URL, json=body, headers=HEADERS, timeout=10)
    r.raise_for_status()
    return r.json().get("data", [])


def _parse(items: list) -> list:
    """解析为统一格式"""
    result = []
    for item in items:
        media = item.get("media_info", {})
        inter = item.get("interation_info", {})
        link = item.get("link_info", {})
        result.append({
            "id": item.get("id", ""),
            "title": item.get("title", ""),
            "short_title": item.get("short_title", ""),
            "desc": item.get("desc", ""),
            "source": media.get("chl_name", ""),
            "publish_time": item.get("publish_time", ""),
            "url": link.get("url", f"https://news.qq.com/rain/a/{item.get('id', '')}"),
            "read_num": inter.get("read_num", 0),
            "like_num": inter.get("like_num", 0),
            "commet_num": inter.get("commet_num", 0),
            "share_num": inter.get("share_num", 0),
            "collect_num": inter.get("collect_num", 0),
        })
    return result


def hot_yaowen(n: int = None) -> list:
    """要闻榜（默认 20 条）"""
    items = _fetch(CHANNELS["top"])
    return _parse(items)[:n]


def hot_ent(n: int = None) -> list:
    """娱乐榜"""
    items = _fetch(CHANNELS["ent"])
    return _parse(items)[:n]


def hot_sports(n: int = None) -> list:
    """体育榜"""
    items = _fetch(CHANNELS["sports"])
    return _parse(items)[:n]


def hot_finance(n: int = None) -> list:
    """财经榜"""
    items = _fetch(CHANNELS["finance"])
    return _parse(items)[:n]


def hot_tech(n: int = None) -> list:
    """科技榜"""
    items = _fetch(CHANNELS["tech"])
    return _parse(items)[:n]


def hot_all(n: int = 10) -> dict:
    """所有频道热榜"""
    result = {}
    for key, ch_id in CHANNELS.items():
        items = _fetch(ch_id)
        result[key] = _parse(items)[:n]
    return result


def report() -> str:
    """生成 Markdown 报告"""
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [
        f"# 🔥 腾讯新闻热榜",
        f"> 更新时间: {now}",
        f"> 数据来源: news.qq.com | i.news.qq.com",
        "",
    ]

    for key in ["top", "hot", "ent", "sports", "finance", "tech"]:
        name = CHANNEL_NAMES[key]
        items = _fetch(CHANNELS[key])
        parsed = _parse(items)[:15]
        lines.append(f"## 📰 {name} (Top {len(parsed)})")
        lines.append("")
        lines.append("| # | 标题 | 来源 | 阅读 | 评论 |")
        lines.append("|---|------|------|------|------|")
        for i, item in enumerate(parsed, 1):
            rd = _fmt_num(item["read_num"])
            cm = item["commet_num"]
            lines.append(
                f"| {i} | {item['title'][:45]} | {item['source'][:10]} | {rd} | {cm} |"
            )
        lines.append("")

    return "\n".join(lines)


def _fmt_num(n: int) -> str:
    """格式化数字"""
    if n >= 1_0000_0000:
        return f"{n/1_0000_0000:.1f}亿"
    elif n >= 1_0000:
        return f"{n/1_0000:.1f}万"
    return str(n)


if __name__ == "__main__":
    # 快速测试
    items = hot_yaowen(10)
    for i, item in enumerate(items, 1):
        print(f"  {i:2}. [{item['source'][:8]:8s}] {item['title'][:50]}  "
              f"阅读:{_fmt_num(item['read_num'])} 评论:{item['commet_num']}")
