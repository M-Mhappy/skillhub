
"""
网易新闻适配器 — 通用执行专员
数据来源：news.163.com/special/cm_yaowen20200213 (JSONP)
公开 API，无需登录，无需 Cookie。
"""

import requests
import re
import json
import time
from typing import Optional

BASE_YAOWEN = "https://news.163.com/special/cm_yaowen20200213/"
BASE_CHANNEL = "https://news.163.com/special/yaowen_channel_api/"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"


def _fetch_jsonp(url, callback_name):
    """获取 JSONP 并解析为 Python 对象"""
    r = requests.get(url, params={"callback": callback_name},
                     headers={"User-Agent": UA}, timeout=15)
    r.raise_for_status()
    match = re.search(
        rf'{callback_name}\((.+)\);?\s*$', r.text, re.DOTALL)
    if not match:
        raise RuntimeError(f"JSONP parse failed for {url[:60]}")
    return json.loads(match.group(1))


def _normalize(item):
    return {
        "title": item.get("title", ""),
        "url": item.get("docurl", item.get("tlink", "")),
        "digest": (item.get("digest") or "")[:200],
        "source": item.get("source", ""),
        "label": item.get("label", ""),
        "channel": item.get("channelname", ""),
        "keywords": item.get("keywords", []) or [],
    }


def hot_yaowen(limit: int = 20) -> list:
    """网易新闻-要闻（主热榜，最多70条）"""
    data = _fetch_jsonp(BASE_YAOWEN, "data_callback")
    items = [_normalize(item) for item in data[:limit]]
    return items


def hot_channels() -> dict:
    """网易新闻-频道精选（财经/科技/体育/娱乐/汽车/房产/教育/旅游/健康）"""
    data = _fetch_jsonp(BASE_CHANNEL, "channel_callback")
    result = {}
    for ch in data:
        name = ch.get("channelname", "?")
        lst = ch.get("list", [])
        result[name] = [_normalize(item) for item in lst]
    return result


def hot_all(limit: int = 15) -> dict:
    """一次获取：要闻 + 频道精选"""
    return {
        "要闻": hot_yaowen(limit),
        "频道精选": hot_channels(),
    }


CHANNEL_NAMES = {
    "money": "财经", "tech": "科技", "sports": "体育",
    "ent": "娱乐", "auto": "汽车", "house": "房产",
    "edu": "教育", "travel": "旅游", "jiankang": "健康",
}


def report() -> str:
    """生成 Markdown 热榜报告"""
    yaowen = hot_yaowen(20)
    channels = hot_channels()

    lines = [
        "# 📰 网易新闻热榜",
        f"> 更新时间: {time.strftime('%Y-%m-%d %H:%M')}",
        f"> 数据来源: news.163.com",
        "",
        "## 🔥 要闻 TOP 20",
        "",
        "| # | 标题 | 来源 |",
        "|---|------|------|",
    ]
    for i, item in enumerate(yaowen, 1):
        title = item["title"][:50]
        src = item["source"][:10]
        lines.append(f"| {i} | {title} | {src} |")

    lines.append("")
    lines.append("## 📡 频道精选")
    lines.append("")
    
    for key, name in CHANNEL_NAMES.items():
        if key in channels and channels[key]:
            item = channels[key][0]
            lines.append(f"- **{name}**: [{item['title'][:50]}]({item['url']})")

    return "\n".join(lines)


if __name__ == "__main__":
    print("=== 要闻 TOP 10 ===")
    for i, item in enumerate(hot_yaowen(10), 1):
        print(f"  {i}. {item['title'][:60]} | {item['source']}")
    print()
    ch = hot_channels()
    for k, v in ch.items():
        if v:
            name = CHANNEL_NAMES.get(k, k)
            print(f"  [{name}] {v[0]['title'][:55]}")
