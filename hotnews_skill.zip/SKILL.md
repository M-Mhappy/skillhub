---
name: newsget
description: 五平台中文新闻热榜一键采集：腾讯新闻、知乎、搜狐新闻、今日头条、网易新闻。纯 Python，零依赖，零鉴权。
version: 1.0.0
author: newsget-skill
tags: [news, hot-search, tencent-news, zhihu, sohu, toutiao, netease]
---

# newsget — 五平台中文新闻热榜一键采集

纯 Python 实现。解压后直接在 `execute_python` 中 `import` 即可。

---

## 📋 执行流程

```
用户请求热榜 → execute_python 中 import 对应适配器 → 调用函数 → 格式化呈现
```

### 步骤 1：确认目标

| 命令 | 平台 | 榜数 | 热度 |
|------|------|:---:|:---:|
| `all` | 全部五平台 | 15 | ✅ |
| `tencent` | 腾讯新闻 | 6 | ✅ 阅读/评论/点赞/分享 |
| `zhihu` | 知乎 | 2 | ✅ 万热度 |
| `sohu` | 搜狐新闻 | 3 | ❌ |
| `toutiao` | 今日头条 | 2 | ✅ 热度数字 |
| `netease` | 网易新闻 | 2 | ❌ |

### 步骤 2：执行

**唯一方式：Python API 直接调用**

```python
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath("newsget.py")))

from adapters.tencent_adapter import hot_yaowen, hot_ent, hot_sports, hot_finance, hot_tech
from adapters.zhihu_adapter import hot as zh_hot, monthly as zh_monthly
from adapters.sohu_adapter import hot_daily, hot_weekly, hot_politics
from adapters.toutiao_adapter import hot as tt_hot, words as tt_words
from adapters.netease_adapter import hot_yaowen as ne_yaowen, hot_channels

# 各取 10 条
tencent_top = hot_yaowen(10)     # → list[dict]
zhihu_items = zh_hot(10)
sohu_daily_items = hot_daily(10)
tt_items = tt_hot(10)
ne_items = ne_yaowen(10)
```


### 步骤 3：呈现

直接遍历返回的 `list[dict]`，格式化输出：

```python
for i, item in enumerate(items, 1):
    title = item["title"]
    source = item.get("source", "")
    heat = item.get("hot_value") or item.get("read_num") or ""
    print(f"{i:2}. [{source}] {title}  🔥{heat}")
```

- 超过 20 条只展示前 15 条
- 保存完整数据到 JSON：`json.dump(items, open("result.json", "w"), ensure_ascii=False)`



## 站点索引

| 平台 | 适配器 | API | 榜 | 热度指标 |
|------|--------|-----|:---:|------|
| 腾讯新闻 | `tencent_adapter` | `i.news.qq.com` | 要闻/娱乐/体育/财经/科技/排行 | read_num, like_num, commet_num, share_num |
| 知乎 | `zhihu_adapter` | `api.zhihu.com` | 热榜/月榜 | heat（万）, answer_count, follower_count |
| 搜狐新闻 | `sohu_adapter` | `odin.sohu.com` | 日榜/周榜/时政榜 | — |
| 今日头条 | `toutiao_adapter` | `toutiao.com` | 热榜/热词 | hot_value |
| 网易新闻 | `netease_adapter` | `news.163.com` | 要闻/频道精选 | — |

---

## 适配器 API 速查

### 腾讯新闻 `tencent_adapter`

```python
hot_yaowen(n=20)   # 要闻
hot_ent(n=20)      # 娱乐
hot_sports(n=20)   # 体育
hot_finance(n=20)  # 财经
hot_tech(n=20)     # 科技

# 返回字段
# title, source, publish_time, url, read_num, like_num, commet_num, share_num
```

### 知乎 `zhihu_adapter`

```python
hot(n=30)          # 热榜（实时）
monthly(n=30)      # 月榜

# 返回字段
# title, url, excerpt, heat, answer_count, follower_count, author
```

### 搜狐新闻 `sohu_adapter`

```python
hot_daily(n=30)    # 日榜
hot_weekly(n=30)   # 周榜
hot_politics(n=10) # 时政榜

# 返回字段
# title, url, source
```

### 今日头条 `toutiao_adapter`

```python
hot(n=30)          # 热榜
words()            # 热词（固定 10 条）

# hot 字段: title, hot_value, url
# words 字段: query
```

### 网易新闻 `netease_adapter`

```python
hot_yaowen(n=70)   # 要闻
hot_channels()      # 频道精选 → dict

# 返回字段
# title, url, source, digest
```

---

## 文件结构

```
newsget_skill/
├── SKILL.md
├── newsget.py              # 命令行入口（人工用，AI 跳过）
└── adapters/
    ├── __init__.py
    ├── tencent_adapter.py
    ├── zhihu_adapter.py
    ├── sohu_adapter.py
    ├── toutiao_adapter.py
    └── netease_adapter.py
```

---

## 故障排查

| 症状 | 原因 | 解决 |
|------|------|------|
| 全部返回 0 条 | 网络不通 | 检查外网连接 |
| 搜狐 502 | 反爬 | 重试一次 |
| 知乎返回空 | API 限频 | 等待 30 秒重试 |
| 网易 404 | JSONP 接口变化 | 检查 `cm_yaowen20200213` 是否仍有效 |
| `ImportError` | 路径不对 | 确保 `sys.path.insert(0, "newsget_skill 解压目录")` |

---


