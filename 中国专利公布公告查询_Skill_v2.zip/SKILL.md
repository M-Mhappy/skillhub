# 中国专利公布公告查询 Skill

## 用途
检索**中国专利公布公告**系统（http://epub.cnipa.gov.cn）的专利信息，支持发明公布、发明授权、实用新型和外观设计四种专利类型，可查询 1985 年至今的中国专利公布公告数据。

## WAF 说明（重要）
本网站使用 **JS Challenge WAF** 保护。实际测试情况：

| 方式 | 结果 |
|------|------|
| ✅ **浏览器脚本（推荐）** | WAF 被浏览器 JS 引擎自动完成，脚本内 navigate → 直接可用 |
| ❌ Python requests 直接请求 | 被 WAF 拦截（400 状态码） |
| ❌ Python + cloudscraper | 同样被拦截（非 Cloudflare） |
| ❌ requests + 浏览器 Cookie | 仍被拦截（WAF 检测 TLS/HTTP2 指纹） |

**结论**：必须通过**浏览器工具**与网站交互。本 Skill 已内置 3 个浏览器自动化 JS 脚本，可直接调用。

## 可用脚本（Scripts）

本 skill 提供以下 **browser_js 脚本**，均保存在脚本库中：

### 1. patent_simple_search — 简单搜索

**用途**：打开首页 → 输入关键词 → 选专利类型 → 点击查询 → 提取结果到 JSON

**前置条件**：无，脚本会自动 navigate 到首页

**参数**：
| 参数 | 类型 | 必填 | 说明 | 默认值 |
|------|------|------|------|--------|
| keywords | string | ✅ | 搜索关键词（申请号/公布号/名称关键词等） | - |
| patent_types | string[] | 否 | 专利类型过滤 | ["发明公布","发明授权","实用新型","外观设计"] |
| pageSize | int | 否 | 每页条数（1-10） | 3 |
| maxPages | int | 否 | 最多翻页数 | 1（仅第一页） |
| fileName | string | 否 | 输出文件名前缀 | "patent_search_results" |

**输出**：`{fileName}.json`（JSON 数组，每项含 patent_type, title, publication_number, publication_date, application_number, application_date, applicant, inventor, address, classification, abstract）

**使用方式**：
```javascript
// 方式1：通过脚本库执行（执行 Agent）
execute_library_script({
  libraryId: "patent_simple_search",
  params: {
    keywords: "智能机器人",
    patent_types: ["发明公布", "发明授权"],
    maxPages: 2
  }
})

// 方式2：手动分步操作（AI 员工逐工具调用）
// 见下方「手动操作流程」
```

### 2. patent_advanced_search — 高级搜索

**用途**：打开高级查询页 → 填写多字段 → 点击查询 → 提取结果

**参数**：支持 title, applicant, inventor, publication_number, application_number, ipc_classification, abstract, address, agency, agent, priority, publication_date_from/to, application_date_from/to, patent_types, pageSize, fileName 等

**输出**：JSON 文件，格式同简单搜索

### 3. patent_get_detail — 专利详情查询

**用途**：通过公布（公告）号查询单件专利完整著录项目信息

**参数**：
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| publication_number | string | ✅ | 公布（公告）号，如 CN122125674A |
| fileName | string | 否 | 输出文件名 |

**输出**：JSON 文件（含 patent_type, title, publication_number, publication_date, application_number, application_date, applicant, inventor, address, classification, abstract, agency, agent, priority, claims 等）

## 手动操作流程（无脚本时可用）

如果脚本库不可用，可按以下步骤手动操作：

### 简单搜索
1. `navigate_to_url("http://epub.cnipa.gov.cn/")` — WAF 自动通过
2. `cdp_input_text({ backendNodeId: 898, text: "关键词" })` — 输入关键词
3. `cdp_click_element({ backendNodeId: checkbox })` — 设置专利类型（按需）
4. `cdp_click_element({ backendNodeId: 901 })` — 点击查询按钮
5. 等待结果页加载
6. 使用 `#result .item` 选择器通过 `cdp_extract_data` 提取

### 查看详情
1. `navigate_to_url("http://epub.cnipa.gov.cn/Dxb/Detail?pn=CN122125674A")`
2. 等待 h1.title 出现
3. 使用 `cdp_evaluate_script` 或 `cdp_extract_data` 提取字段

## 校验数据完整性

脚本执行后可通过 Python 快速校验结果质量：

```python
import json
with open('patent_search_results.json', 'r') as f:
    data = json.load(f)
print(f"共 {len(data)} 条专利")
for p in data[:3]:
    print(f"  [{p['patent_type']}] {p['title'][:30]}...")
    print(f"  公布号: {p.get('publication_number')}")
```

## 与旧版 (v1.x) 的区别

| 方面 | v1.x（旧） | v2.x（当前） |
|------|-----------|-------------|
| 核心 loader | Python (requests) | 浏览器 JS 脚本 |
| WAF 兼容性 | ❌ 被拦截 | ✅ 浏览器自动通过 |
| 数据提取 | 响应解析 + BeautifulSoup | DOM 选择器逐字段提取 |
| 翻页 | API 参数 | 浏览器点击「下页」 |
| 脚本复用 | 不适用 | 可发布到脚本库长期使用 |
