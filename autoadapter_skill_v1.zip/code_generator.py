"""
通用适配器代码生成器 — 将网站分析结果转为可直接运行的 Python 代码

生成的适配器是自包含的 .py 文件，不依赖 AutoCLI 或任何外部框架。
只需 requests 库即可运行。

核心功能：
1. 分析 API/SSR/SPA/静态 HTML 多种网站类型
2. 生成 fetch → transform → run 三步结构的 Python 代码
3. 支持字段映射、分页、错误处理、重试、限速
4. 输出的 .py 文件可直接 `python adapter.py` 运行
"""

import json
import os
import re
from datetime import datetime
from typing import Optional
from .website_analyzer import AnalysisResult

class CodeGenerator:
    """
    将网站分析结果转换为通用 Python 适配器代码。
    生成的代码是自包含、可直接运行的 Python 文件。
    """

    # 生成器版本
    GENERATOR_VERSION = "1.0.0"

    def __init__(self, output_dir: str = None):
        self.output_dir = output_dir or os.path.join(
            os.path.dirname(__file__), "adapters"
        )
        os.makedirs(self.output_dir, exist_ok=True)
        self.last_code = ""
        self.last_adapter_name = ""

    def generate(self, analysis: AnalysisResult, goal: str = "list",
                 adapter_name: str = None) -> str:
        """
        根据分析结果生成适配器 Python 代码

        Args:
            analysis: 网站分析结果
            goal: 目标（list / detail / search / download）
            adapter_name: 适配器名称（用于文件名和类名）

        Returns:
            str: 生成的 Python 代码
        """
        if not adapter_name:
            adapter_name = self._infer_adapter_name(analysis)

        self.last_adapter_name = adapter_name
        code = self._generate_adapter(analysis, adapter_name, goal)
        self.last_code = code
        return code

    def save(self, code: str = None, adapter_name: str = None) -> str:
        """
        将生成的代码保存到文件

        Args:
            code: Python 代码（不传则用 last_code）
            adapter_name: 适配器名（不传则用 last_adapter_name）

        Returns:
            str: 保存的文件路径
        """
        code = code or self.last_code
        adapter_name = adapter_name or self.last_adapter_name
        if not code or not adapter_name:
            raise ValueError("请先调用 generate() 或传入 code/adapter_name")

        filepath = os.path.join(self.output_dir, f"{adapter_name}.py")
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(code)
        return filepath

    def _infer_adapter_name(self, analysis: AnalysisResult) -> str:
        """从分析结果推断适配器名称"""
        domain = analysis.domain

        # 移除非字母数字字符，用小写和下划线
        name = re.sub(r"[^\w]", "_", domain.split(".")[0].lower())
        name = re.sub(r"_+", "_", name).strip("_")

        if not name:
            name = "data_source"

        # 如果是通用域名，用完整域名
        if name in ["www", "m", "mobile", "api", "dev"]:
            parts = domain.split(".")
            if len(parts) >= 2:
                name = parts[1]

        return name

    def _generate_adapter(self, analysis: AnalysisResult,
                          adapter_name: str, goal: str) -> str:
        """生成适配器 Python 代码的主方法"""
        lines = []

        # --- 文件头 ---
        lines.append('#!/usr/bin/env python3')
        lines.append('"""')
        lines.append(f'通用适配器 — {analysis.url}')
        lines.append(f'')
        lines.append(f'自动生成于: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        lines.append(f'目标类型: {goal}')
        lines.append(f'网站类型: {analysis.content_type}')
        if analysis.detected_framework:
            lines.append(f'前端框架: {analysis.detected_framework}')
        lines.append(f'')
        lines.append(f'使用方法:')
        lines.append('"""')

        lines.append('')
        lines.append('import json')
        lines.append('import time')
        lines.append('')
        lines.append('try:')
        lines.append('    import requests')
        lines.append('except ImportError:')
        lines.append('    print("[失败] 需要 requests 库: pip install requests")')
        lines.append('')

        # --- 配置区域 ---
        lines.append('# ============================================================')
        lines.append('# 配置区 — 可根据需要修改')
        lines.append('# ============================================================')
        lines.append(f'BASE_URL = "{analysis.url}"')
        lines.append(f'SOURCE_NAME = "{adapter_name}"')
        lines.append(f'SOURCE_DOMAIN = "{analysis.domain}"')

        # 基本请求头
        lines.append('')
        lines.append('DEFAULT_HEADERS = {')
        lines.append('    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                     'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",')
        lines.append('    "Accept": "application/json, text/html, */*",')
        lines.append('    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",')
        lines.append('}')

        # 重试配置
        lines.append('')
        lines.append('MAX_RETRIES = 3')
        lines.append('TIMEOUT = 30')
        lines.append('RETRY_DELAY = 2  # 秒')

        # 分页配置（如果有分页信息）
        lines.append('')

        # --- 核心函数 ---

        # 1. fetch 函数
        lines.append('')
        lines.append('# ============================================================')
        lines.append('# 核心函数')
        lines.append('# ============================================================')

        lines.append('')
        lines.append('')
        lines.append('def fetch(limit: int = 20, **kwargs) -> list:')
        lines.append('    """')
        lines.append(f'    从 {analysis.domain} 获取{goal}数据')

        # 根据分析结果生成参数说明
        lines.append('')
        lines.append('    Args:')
        lines.append('        limit: 返回数量限制（默认 20）')
        for ds in analysis.data_samples:
            if ds.get("key") and ds["key"] not in ["items", ""]:
                lines.append(f'        {ds["key"]}: 数据筛选参数')
        lines.append('')
        lines.append('    Returns:')
        lines.append('        list: 原始数据列表')
        lines.append('    """')

        # 根据网站类型生成不同的 fetch 实现
        if analysis.content_type == "api":
            self._gen_api_fetch(lines, analysis, goal)
        elif analysis.content_type in ["ssr", "spa"] and analysis.ssr_data:
            self._gen_ssr_fetch(lines, analysis)
        elif analysis.content_type == "ssr":
            self._gen_html_fetch(lines, analysis, "ssr")
        else:
            self._gen_html_fetch(lines, analysis, "static")

        # 2. transform 函数
        lines.append('')
        lines.append('')
        lines.append('def transform(data: list) -> list:')
        lines.append('    """')
        lines.append('    将原始数据转换为统一格式')
        lines.append('')
        lines.append('    Args:')
        lines.append('        data: 原始数据列表')
        lines.append('')
        lines.append('    Returns:')
        lines.append('        list: 转换后的数据（每个元素为 dict）')
        lines.append('    """')

        # 生成字段映射
        fields = self._infer_fields(analysis)
        if fields:
            lines.append('    result = []')
            lines.append('    for item in data:')
            lines.append('        if not isinstance(item, dict):')
            lines.append('            continue')
            lines.append('        try:')
            lines.append('            result.append({')
            for i, (field_name, field_expr) in enumerate(fields.items()):
                suffix = ',' if i < len(fields) - 1 else ','
                lines.append(f'                "{field_name}": item.get("{field_expr}", ""),')
            lines.append('            })')
            lines.append('        except (KeyError, TypeError, AttributeError):')
            lines.append('            continue')
            lines.append('    return result')
        else:
            lines.append('    # 无自动识别的字段，返回原始数据')
            lines.append('    # 提示：可根据实际数据格式修改此函数')
            lines.append('    return data')

        # 3. run 函数（整合流程）
        lines.append('')
        lines.append('')
        lines.append('def run(limit: int = 20, **kwargs) -> list:')
        lines.append('    """')
        lines.append(f'    完整流程：获取 → 转换 → 返回')
        lines.append('    """')
        lines.append('    # 1. 获取数据')
        lines.append('    raw_data = fetch(limit=limit, **kwargs)')
        lines.append('    if not raw_data:')
        lines.append('        print("[警告]  未获取到数据")')
        lines.append('        return []')
        lines.append('')
        lines.append('    # 2. 转换数据')
        lines.append('    result = transform(raw_data)')
        lines.append('')
        lines.append('    # 3. 限制数量')
        lines.append('    if len(result) > limit:')
        lines.append('        result = result[:limit]')
        lines.append('')
        lines.append('    return result')

        return "\n".join(lines)

    def _gen_api_fetch(self, lines: list, analysis: AnalysisResult, goal: str):
        """为 API 类型网站生成 fetch 函数"""
        # 添加重试逻辑
        lines.append('    """通过 API 获取数据（支持重试）"""')
        lines.append('    params = {"_limit": limit}')

        # 根据 goal 添加不同参数
        if goal == "search":
            lines.append('    if kwargs.get("keyword"):')
            lines.append('        params["q"] = kwargs["keyword"]')

        lines.append('')
        lines.append('    for attempt in range(MAX_RETRIES):')
        lines.append('        try:')
        lines.append('            resp = requests.get(')
        lines.append('                BASE_URL,')
        lines.append('                params=params,')
        lines.append('                headers=DEFAULT_HEADERS,')
        lines.append('                timeout=TIMEOUT,')
        lines.append('            )')
        lines.append('            resp.raise_for_status()')
        lines.append('')
        lines.append('            # 解析 JSON 响应')
        lines.append('            data = resp.json()')
        lines.append('')
        lines.append('            # 处理可能的嵌套结构')

        # 如果分析到数据在嵌套路径中，添加选择逻辑
        data_path = self._find_data_path(analysis)
        if data_path and data_path not in ["$", ".[]"]:
            # 有特定的数据路径
            path_parts = data_path.strip(".").split(".")
            indent = "            "
            for i, part in enumerate(path_parts):
                lines.append(f'{indent}if isinstance(data, dict) and "{part}" in data:')
                indent += "    "
            lines.append(f'{indent}data = data{data_path}')

        lines.append('')
        lines.append('            # 确保返回列表')
        lines.append('            if isinstance(data, list):')
        lines.append('                return data')
        lines.append('            elif isinstance(data, dict):')
        lines.append('                # 尝试从字典中找到列表')
        lines.append('                for v in data.values():')
        lines.append('                    if isinstance(v, list):')
        lines.append('                        return v')
        lines.append('                return [data]')
        lines.append('            else:')
        lines.append('                return []')
        lines.append('')
        lines.append('        except requests.exceptions.RequestException as e:')
        lines.append('            if attempt < MAX_RETRIES - 1:')
        lines.append('                wait = RETRY_DELAY * (attempt + 1)')
        lines.append(f'                print(f"[警告]  请求失败，{{wait}}秒后重试: {{e}}")')
        lines.append('                time.sleep(wait)')
        lines.append('            else:')
        lines.append('                print(f"[失败] 请求失败（已重试{MAX_RETRIES}次）: {e}")')
        lines.append('                return []')
        lines.append('')
        lines.append('    return []')

    def _gen_ssr_fetch(self, lines: list, analysis: AnalysisResult):
        """为 SSR 数据（页面内嵌 JSON）生成 fetch 函数"""
        lines.append('    """从页面内嵌数据中提取（SSR）"""')
        lines.append('    for attempt in range(MAX_RETRIES):')
        lines.append('        try:')
        lines.append('            resp = requests.get(')
        lines.append('                BASE_URL,')
        lines.append('                headers=DEFAULT_HEADERS,')
        lines.append('                timeout=TIMEOUT,')
        lines.append('            )')
        lines.append('            resp.raise_for_status()')
        lines.append('')

        # 根据框架提取 SSR 数据
        framework = analysis.detected_framework
        if framework == "nextjs":
            lines.append('            # Next.js: __NEXT_DATA__')
            lines.append('            import re')
            lines.append('            match = re.search(')
            lines.append("                r'<script id=\"__NEXT_DATA__\"[^>]*>(.*?)</script>',")
            lines.append('                resp.text, re.DOTALL')
            lines.append('            )')
            lines.append('            if match:')
            lines.append('                import json')
            lines.append('                return json.loads(match.group(1))')
        elif framework in ["nuxt", "vue"]:
            lines.append('            # Nuxt/Vue: window.__NUXT__')
            lines.append('            import re')
            lines.append("            match = re.search(r'window\\.__NUXT__\\s*=\\s*(\\{.*?\\});',")
            lines.append('                resp.text, re.DOTALL')
            lines.append('            )')
            lines.append('            if match:')
            lines.append('                import json')
            lines.append('                return json.loads(match.group(1))')
        else:
            lines.append('            # 通用 SSR 数据提取')
            lines.append('            import re')
            lines.append('            for pattern in [')
            lines.append("                r'window\\.__INITIAL_STATE__\\s*=\\s*({.*?});',")
            lines.append("                r'window\\.__DATA__\\s*=\\s*({.*?});',")
            lines.append("                r'<script id=\"__NEXT_DATA__\"[^>]*>(.*?)</script>',")
            lines.append('            ]:')
            lines.append('                match = re.search(pattern, resp.text, re.DOTALL)')
            lines.append('                if match:')
            lines.append('                    import json')
            lines.append('                    try:')
            lines.append('                        return json.loads(match.group(1))')
            lines.append('                    except json.JSONDecodeError:')
            lines.append('                        continue')

        lines.append('')
        lines.append('            # SSR 数据提取失败，返回空')
        lines.append('            return []')
        lines.append('')
        lines.append('        except requests.exceptions.RequestException as e:')
        lines.append('            if attempt < MAX_RETRIES - 1:')
        lines.append('                time.sleep(RETRY_DELAY * (attempt + 1))')
        lines.append('            else:')
        lines.append(f'                print(f"[失败] 请求失败: {{e}}")')
        lines.append('                return []')
        lines.append('')
        lines.append('    return []')

    def _gen_html_fetch(self, lines: list, analysis: AnalysisResult,
                        page_type: str):
        """为 HTML 静态页面生成 fetch 函数"""
        lines.append('    """从 HTML 页面解析数据"""')
        lines.append('    try:')
        lines.append('        from bs4 import BeautifulSoup')
        lines.append('    except ImportError:')
        lines.append('        print("[失败] 需要 BeautifulSoup: pip install beautifulsoup4")')
        lines.append('        return []')
        lines.append('')
        lines.append('    for attempt in range(MAX_RETRIES):')
        lines.append('        try:')
        lines.append('            resp = requests.get(')
        lines.append('                BASE_URL,')
        lines.append('                headers=DEFAULT_HEADERS,')
        lines.append('                timeout=TIMEOUT,')
        lines.append('            )')
        lines.append('            resp.raise_for_status()')
        lines.append('')
        lines.append('            soup = BeautifulSoup(resp.text, "html.parser")')
        lines.append('            items = []')

        # 使用分析结果中的容器选择器
        containers = analysis.html_structure.get("containers", [])
        list_containers = [c for c in containers
                           if c.get("type") in ["list", "card", "item", "feed"]]

        if list_containers:
            selector = list_containers[0].get("class", "").split()[0]
            tag = list_containers[0].get("tag", "div")
            lines.append(f'')
            lines.append(f'            # 使用分析到的容器选择器')
            lines.append(f'            for el in soup.select("{{tag}}[class*=\\"{selector}\\"]"):')
            lines.append(f'                items.append({{')
            lines.append(f'                    "text": el.get_text(strip=True),')
            lines.append(f'                    "html": str(el)[:500],')
            lines.append(f'                }})')
        else:
            lines.append('')
            lines.append('            # 通用提取：寻找列表结构')
            lines.append('            for tag in ["article", "li", "tr", "div.item", "div.post"]:')
            lines.append('                found = soup.select(tag)')
            lines.append('                if len(found) > 1:')
            lines.append('                    for el in found[:limit]:')
            lines.append('                        items.append({')
            lines.append('                            "text": el.get_text(strip=True),')
            lines.append('                            "html": str(el)[:500],')
            lines.append('                        })')
            lines.append('                    if items:')
            lines.append('                        break')

        lines.append('')
        lines.append('            return items[:limit]')
        lines.append('')
        lines.append('        except requests.exceptions.RequestException as e:')
        lines.append('            if attempt < MAX_RETRIES - 1:')
        lines.append('                time.sleep(RETRY_DELAY * (attempt + 1))')
        lines.append('            else:')
        lines.append(f'                print(f"[失败] 请求失败: {{e}}")')
        lines.append('                return []')
        lines.append('')
        lines.append('    return []')

    def _find_data_path(self, analysis: AnalysisResult) -> str:
        """查找数据路径"""
        if analysis.data_samples:
            path = analysis.data_samples[0].get("path", "")
            return path.replace("/", ".")
        for cmd in analysis.possible_commands:
            if cmd.get("data_key"):
                return cmd["data_key"]
        return ""

    def _infer_fields(self, analysis: AnalysisResult) -> dict:
        """从数据样本推断字段映射"""
        fields = {}

        if not analysis.data_samples:
            return {}

        sample = analysis.data_samples[0].get("sample", [])
        if not sample:
            return {}

        first_item = sample[0] if isinstance(sample, list) else sample
        if not isinstance(first_item, dict):
            return {"content": "."}

        # 常见字段映射
        field_mapping = {
            "id": ["id", "uuid", "sid", "article_id", "post_id", "item_id", "nid", "pk"],
            "title": ["title", "name", "subject", "heading", "headline", "article_title", "question"],
            "description": ["description", "desc", "summary", "abstract", "intro", "excerpt", "body", "content"],
            "url": ["url", "link", "href", "permalink", "page_url", "web_url", "share_url"],
            "author": ["author", "creator", "user", "username", "nickname", "owner_name", "by"],
            "date": ["date", "time", "created_at", "createdAt", "publish_time",
                     "publishedAt", "timestamp", "pubDate", "updated_at"],
            "image": ["image", "img", "thumbnail", "cover", "picture", "avatar", "pic", "photo"],
            "views": ["views", "view_count", "read_count", "play_count", "pageviews"],
            "likes": ["likes", "like_count", "favorites", "stars", "upvote_count", "vote_count", "digg_count"],
            "comments": ["comments", "comment_count", "reply_count", "replies", "comment_num"],
            "category": ["category", "tag", "tags", "type", "section", "channel", "topic"],
        }

        # 匹配
        used_fields = set()
        for field_name, possible_names in field_mapping.items():
            for data_key in first_item.keys():
                dk_lower = data_key.lower().strip()
                if dk_lower in possible_names and field_name not in used_fields:
                    fields[field_name] = data_key
                    used_fields.add(field_name)
                    break

        # 如果匹配到的字段太少，补充一些未匹配的字段
        if len(fields) < 3 and first_item:
            for k in first_item.keys():
                if k not in fields.values() and len(fields) < 6:
                    safe_name = re.sub(r"[^a-zA-Z0-9_]", "_", k.lower()).strip("_")
                    if safe_name and safe_name not in fields:
                        fields[safe_name] = k

        return fields
