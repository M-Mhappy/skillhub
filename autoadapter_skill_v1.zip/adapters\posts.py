#!/usr/bin/env python3
"""
通用适配器 — https://jsonplaceholder.typicode.com/posts

自动生成于: 2026-06-17 14:15:02
目标类型: list
网站类型: api

使用方法:
"""

import json
import time

try:
    import requests
except ImportError:
    print("[失败] 需要 requests 库: pip install requests")

# ============================================================
# 配置区 — 可根据需要修改
# ============================================================
BASE_URL = "https://jsonplaceholder.typicode.com/posts"
SOURCE_NAME = "posts"
SOURCE_DOMAIN = "jsonplaceholder.typicode.com"

DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json, text/html, */*",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
}

MAX_RETRIES = 3
TIMEOUT = 30
RETRY_DELAY = 2  # 秒


# ============================================================
# 核心函数
# ============================================================


def fetch(limit: int = 20, **kwargs) -> list:
    """
    从 jsonplaceholder.typicode.com 获取list数据

    Args:
        limit: 返回数量限制（默认 20）

    Returns:
        list: 原始数据列表
    """
    """通过 API 获取数据（支持重试）"""
    params = {"_limit": limit}

    for attempt in range(MAX_RETRIES):
        try:
            resp = requests.get(
                BASE_URL,
                params=params,
                headers=DEFAULT_HEADERS,
                timeout=TIMEOUT,
            )
            resp.raise_for_status()

            # 解析 JSON 响应
            data = resp.json()

            # 处理可能的嵌套结构

            # 确保返回列表
            if isinstance(data, list):
                return data
            elif isinstance(data, dict):
                # 尝试从字典中找到列表
                for v in data.values():
                    if isinstance(v, list):
                        return v
                return [data]
            else:
                return []

        except requests.exceptions.RequestException as e:
            if attempt < MAX_RETRIES - 1:
                wait = RETRY_DELAY * (attempt + 1)
                print(f"[警告]  请求失败，{wait}秒后重试: {e}")
                time.sleep(wait)
            else:
                print(f"[失败] 请求失败（已重试{MAX_RETRIES}次）: {e}")
                return []

    return []


def transform(data: list) -> list:
    """
    将原始数据转换为统一格式

    Args:
        data: 原始数据列表

    Returns:
        list: 转换后的数据（每个元素为 dict）
    """
    result = []
    for item in data:
        if not isinstance(item, dict):
            continue
        try:
            result.append({
                "id": item.get("id", ""),
                "title": item.get("title", ""),
                "description": item.get("body", ""),
            })
        except (KeyError, TypeError, AttributeError):
            continue
    return result


def run(limit: int = 20, **kwargs) -> list:
    """
    完整流程：获取 → 转换 → 返回
    """
    # 1. 获取数据
    raw_data = fetch(limit=limit, **kwargs)
    if not raw_data:
        print("[警告]  未获取到数据")
        return []

    # 2. 转换数据
    result = transform(raw_data)

    # 3. 限制数量
    if len(result) > limit:
        result = result[:limit]

    return result