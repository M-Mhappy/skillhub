"""
AutoAdapter — AI 驱动的通用网页适配器生成器

分析任意网站的结构，自动生成可直接运行的 Python 适配器代码。
不依赖 AutoCLI 或任何外部框架。生成的 .py 文件可直接运行。

核心模块:
    - WebsiteAnalyzer: 网站分析（API/SSR/SPA/静态）
    - CodeGenerator: 通用 Python 代码生成
    - AutoAdapterGenerator: AI 增强的一站式适配器生成

使用示例:
    >>> from autoadapter_skill import AutoAdapterGenerator
    >>> gen = AutoAdapterGenerator()
    >>> code = gen.generate("https://api.example.com/posts")
    >>> gen.save("adapters/my_adapter.py")
    >>> # 然后: python adapters/my_adapter.py --limit 20
"""

__version__ = "2.0.0"
__author__ = "AutoAdapter Team"

from .adapter_generator import AutoAdapterGenerator
from .website_analyzer import WebsiteAnalyzer
from .code_generator import CodeGenerator

__all__ = ["AutoAdapterGenerator", "WebsiteAnalyzer", "CodeGenerator"]
