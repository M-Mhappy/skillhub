"""
AutoAdapter 通用适配器生成器
—— AI 驱动的网站适配器自动生成

整合网站分析 + AI 智能推理 + 代码生成，一键生成通用 Python 适配器。
生成的适配器是自包含的 .py 文件，可直接 `python adapter.py` 运行。

使用流程:
    1. analyze(url)     → 分析网站结构
    2. generate(url)    → 分析 + AI 增强 + 生成适配器代码
    3. save(path)       → 保存为 .py 文件
    4. run()            → 在 CLI 中测试运行
"""

import json
import os
import re
import sys
from datetime import datetime
from typing import Optional
from .website_analyzer import WebsiteAnalyzer, AnalysisResult
from .code_generator import CodeGenerator


class AutoAdapterGenerator:
    """
    AI 驱动的通用适配器自动生成器。
    不依赖 AutoCLI，生成可直接运行的 Python 代码。
    """

    def __init__(self, llm_available: bool = True, output_dir: str = None):
        """
        初始化生成器

        Args:
            llm_available: 是否可用 LLM（AI 增强模式）
            output_dir: 适配器输出目录
        """
        self.analyzer = WebsiteAnalyzer()
        self.codegen = CodeGenerator(output_dir=output_dir)
        self.llm_available = llm_available
        self.output_dir = output_dir or os.path.join(
            os.path.dirname(__file__), "adapters"
        )
        self.last_analysis = None
        self.last_adapter_code = ""
        self.last_adapter_name = ""

    def analyze(self, url: str, html_content: str = None) -> AnalysisResult:
        """分析网站结构"""
        result = self.analyzer.analyze(url, html_content)
        self.last_analysis = result
        return result

    def generate(self, url: str, goal: str = "list",
                 adapter_name: str = None,
                 html_content: str = None) -> str:
        """
        核心生成方法：分析网站 → AI 增强（可选）→ 生成 Python 适配器代码

        Args:
            url: 目标网站 URL
            goal: 目标类型（list / detail / search / download）
            adapter_name: 适配器名称（用于文件名和类名）
            html_content: 可选的预获取 HTML

        Returns:
            str: 生成的 Python 代码
        """
        # 1. 分析网站
        analysis = self.analyze(url, html_content)
        self.last_analysis = analysis

        # 2. AI 增强分析（如果可用）
        if self.llm_available:
            ai_enhancements = self._ai_enhance(analysis, goal)
            if ai_enhancements:
                self._apply_ai_enhancements(analysis, ai_enhancements)

        # 3. 生成适配器名称
        if not adapter_name:
            adapter_name = self.codegen._infer_adapter_name(analysis)

        # 4. 生成 Python 代码
        code = self.codegen.generate(analysis, goal, adapter_name)
        self.last_adapter_code = code
        self.last_adapter_name = adapter_name

        # 5. AI 优化代码（如果可用）
        if self.llm_available:
            optimized = self._ai_optimize_code(code, analysis, goal)
            if optimized:
                self.last_adapter_code = optimized
                self.codegen.last_code = optimized

        return self.last_adapter_code

    def save(self, filepath: str = None) -> str:
        """
        保存生成的适配器代码到文件

        Args:
            filepath: 保存路径（不传则自动生成）

        Returns:
            str: 保存的文件路径
        """
        if not self.last_adapter_code:
            raise ValueError("请先调用 generate() 生成适配器代码")

        if filepath:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(self.last_adapter_code)
            return filepath
        else:
            return self.codegen.save(
                self.last_adapter_code,
                self.last_adapter_name
            )

    def generate_full(self, url: str, goal: str = "list",
                      adapter_name: str = None,
                      save: bool = True) -> dict:
        """
        一键生成适配器的完整流程

        Returns:
            dict: {
                "url": str,
                "analysis": dict,
                "code": str,
                "filepath": Optional[str],
                "timestamp": str
            }
        """
        # 生成适配器
        code = self.generate(url, goal, adapter_name)

        # 分析摘要
        analysis_summary = self.analyzer.summarize() if hasattr(self.analyzer, 'summarize') else {}

        result = {
            "url": url,
            "analysis": analysis_summary,
            "code": code,
            "filepath": None,
            "timestamp": datetime.now().isoformat(),
        }

        # 保存
        if save:
            path = self.save()
            result["filepath"] = path

        return result

    def _ai_enhance(self, analysis: AnalysisResult, goal: str) -> dict:
        """
        使用 LLM 增强网站分析结果
        """
        try:
            from lovana_llm import ask

            analysis_summary = {
                "url": analysis.url,
                "domain": analysis.domain,
                "title": analysis.page_title,
                "type": analysis.content_type,
                "framework": analysis.detected_framework,
                "endpoints": analysis.api_endpoints[:5],
                "data_samples_preview": self._truncate_for_llm(
                    analysis.data_samples[:2] if analysis.data_samples else []
                ),
                "ssr_data_keys": list(analysis.ssr_data.keys())[:10] if analysis.ssr_data else [],
                "possible_commands": analysis.possible_commands[:3],
                "goal": goal,
            }

            prompt = f"""你是一个专业的网页数据提取专家。分析以下网站，给出 Python 适配器生成的建议。

## 网站分析结果
```json
{json.dumps(analysis_summary, ensure_ascii=False, indent=2)}
```

## 你需要回答（仅输出 JSON，不要其他文字）
```json
{{
  "api_url": "最可能的 API 数据 URL（从 endpoints 中选或推断，空字符串则无）",
  "data_path": "JSON extract path（如 data.list, data.items, 空字符串则无）",
  "fields": {{
    "field_name": "从数据样本中推断的字段映射",
    ...
  }},
  "fetch_strategy": "api | ssr | html",
  "auth_required": false,
  "pagination_type": "none | page | cursor | offset",
  "notes": "针对 API 调用的专业建议（请求头、参数、限速等）"
}}
```

如果 endpoints 中包含明显的数据 API，请优先使用。
如果数据样本中有示例数据，请仔细分析字段含义并给出最适合用户使用的字段映射。"""

            response = ask(prompt)
            result = self._extract_json_from_llm(response)
            if result:
                return result

        except ImportError:
            print("[INFO] lovana_llm 不可用，跳过 AI 增强")
        except Exception as e:
            print(f"[WARN] AI 增强失败: {e}")

        return {}

    def _ai_optimize_code(self, code: str, analysis: AnalysisResult,
                           goal: str) -> Optional[str]:
        """
        使用 AI 优化生成的适配器代码
        """
        try:
            from lovana_llm import ask

            code_preview = code[:2000]
            analysis_info = {
                "url": analysis.url,
                "title": analysis.page_title,
                "type": analysis.content_type,
                "framework": analysis.detected_framework,
            }

            prompt = f"""你是一个 Python 代码审查专家。审查以下适配器代码，检查是否有 bug 并优化。

## 网站信息
```json
{json.dumps(analysis_info, ensure_ascii=False)}
```

## 当前代码（前 2000 字符）
```python
{code_preview}
```

## 优化要求
- 修复可能的 bug
- 改进错误处理
- 确保代码可直接运行
- 保持简洁，不要添加不必要的依赖
- 保持原有的函数签名（fetch, transform, run, main）
- **只修改 fetch 函数**，transform 和 run 保持通用

## 输出格式
只输出优化后的完整 Python 代码，用 ```python ... ``` 包裹。
如果不需要修改，输出 "NO_CHANGE"。"""

            response = ask(prompt)
            if response and "NO_CHANGE" not in response.upper():
                extracted = self._extract_python_code(response)
                if extracted:
                    return extracted

        except ImportError:
            pass
        except Exception as e:
            print(f"[WARN] AI 代码优化失败: {e}")

        return None

    def _apply_ai_enhancements(self, analysis: AnalysisResult,
                                enhancements: dict):
        """将 AI 增强结果应用到分析对象"""
        # 增强 API URL
        if enhancements.get("api_url") and not analysis.api_endpoints:
            analysis.api_endpoints.append(enhancements["api_url"])

        # 增强数据路径
        if enhancements.get("data_path"):
            # 更新现有样本的路径
            for sample in analysis.data_samples:
                sample["path"] = enhancements["data_path"]

        # 如果有 AI 提供的字段映射，添加为数据样本信息
        if enhancements.get("fields"):
            if analysis.data_samples:
                sample = analysis.data_samples[0]
                if sample.get("sample"):
                    first = sample["sample"][0]
                    if isinstance(first, dict):
                        # 添加 AI 建议的字段说明
                        sample["_ai_field_mapping"] = enhancements["fields"]

    def _extract_json_from_llm(self, text: str) -> Optional[dict]:
        """从 AI 响应中提取 JSON"""
        # 尝试直接解析
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass

        # 尝试从 ```json 代码块中提取
        match = re.search(r'```(?:json)?\s*\n?(.*?)\n?```', text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                pass

        # 尝试提取第一个 JSON 对象
        match = re.search(r'({.*})', text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                pass

        return None

    def _extract_python_code(self, text: str) -> Optional[str]:
        """从 AI 响应中提取 Python 代码"""
        match = re.search(r'```python\s*\n?(.*?)\n?```', text, re.DOTALL)
        if match:
            return match.group(1)
        return None

    def _truncate_for_llm(self, data: any, max_len: int = 1000) -> any:
        """截断数据以适应 LLM 上下文窗口"""
        text = json.dumps(data, ensure_ascii=False)
        if len(text) > max_len:
            return json.loads(text[:max_len] + '"}')
        return data

    def _infer_adapter_name(self, url: str) -> str:
        """从 URL 推断适配器名称"""
        from urllib.parse import urlparse
        domain = urlparse(url).netloc
        name = re.sub(r"[^\w]", "_", domain.split(".")[0].lower())
        name = re.sub(r"_+", "_", name).strip("_")
        if name in ["www", "m", "mobile", "api", "dev"]:
            parts = domain.split(".")
            if len(parts) >= 2:
                name = parts[1]
        return name or "data_source"


# ========== CLI 入口 ==========
def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="AutoAdapter — AI 驱动的通用网页适配器生成器",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 分析网站
  python adapter_generator.py analyze https://www.bilibili.com

  # 生成适配器（含 AI 增强）
  python adapter_generator.py generate https://api.bilibili.com/x/web-interface/popular --goal hot

  # 不保存，只输出代码
  python adapter_generator.py generate https://example.com --print-only

  # 运行生成的适配器
  python adapters/posts.py
  python adapters/posts.py --limit 50 --output result.json --pretty
        """
    )

    subparsers = parser.add_subparsers(dest="action", help="操作")

    # analyze 子命令
    analyze_parser = subparsers.add_parser("analyze", help="分析网站结构")
    analyze_parser.add_argument("url", help="目标 URL")
    analyze_parser.add_argument("--json", action="store_true", help="输出 JSON")

    # generate 子命令
    gen_parser = subparsers.add_parser("generate", help="生成适配器")
    gen_parser.add_argument("url", help="目标 URL")
    gen_parser.add_argument("--goal", default="list",
                            choices=["list", "hot", "search", "detail", "download"],
                            help="数据目标（默认: list）")
    gen_parser.add_argument("--name", "-n", help="适配器名称（默认自动推断）")
    gen_parser.add_argument("--no-ai", action="store_true", help="禁用 AI 增强")
    gen_parser.add_argument("--print-only", "-p", action="store_true",
                            help="仅打印代码，不保存文件")
    gen_parser.add_argument("--output", "-o", help="输出目录")

    args = parser.parse_args()

    if not args.action:
        parser.print_help()
        return

    generator = AutoAdapterGenerator(
        llm_available=not getattr(args, 'no_ai', False),
        output_dir=getattr(args, 'output', None),
    )

    if args.action == "analyze":
        result = generator.analyze(args.url)
        print(f"\n{'='*60}")
        print(f"📊 网站分析报告: {args.url}")
        print(f"{'='*60}")
        print(f"  域名:      {result.domain}")
        print(f"  标题:      {result.page_title or '无'}")
        print(f"  类型:      {result.content_type}")
        print(f"  框架:      {result.detected_framework or '未知'}")
        print(f"  API端点:   {len(result.api_endpoints)} 个")
        print(f"  数据样本:  {len(result.data_samples)} 个")
        print(f"  SSR数据:   {'✅ 可用' if result.ssr_data else '❌ 未发现'}")
        print()

    elif args.action == "generate":
        result = generator.generate_full(
            url=args.url,
            goal=args.goal,
            adapter_name=args.name,
            save=not args.print_only,
        )

        print(f"\n{'='*60}")
        print(f"✅ 适配器生成完成")
        print(f"{'='*60}")
        print(f"  目标:      {result['url']}")
        print(f"  名称:      {generator.last_adapter_name}")
        if result.get('filepath'):
            print(f"  保存路径:  {result['filepath']}")
        print(f"\n{'─'*60}")
        print("📄 适配器代码预览（前 30 行）:")
        print(f"{'─'*60}")
        code_lines = result['code'].split('\n')
        for line in code_lines[:30]:
            print(f"  {line}")
        if len(code_lines) > 30:
            print(f"  ... (共 {len(code_lines)} 行)")


if __name__ == "__main__":
    main()
