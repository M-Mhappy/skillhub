---
name: autoadapter
description: AI 驱动的网站适配器自动生成工具。分析任意网站的结构，自动生成可直接运行的 Python 适配器代码。支持 API / SSR / SPA / 静态 HTML 四种网站类型。
version: 1.0.0
author: autoadapter-skill
tags: [adapter, website-analyzer, code-generator, auto-adapter, web-scraping, api-adapter]
---

# AutoAdapter — 通用网页适配器生成器

> AI 驱动的网站适配器自动生成工具。分析任意网站的结构，自动生成**可直接运行的 Python 代码**。
> 生成的 .py 文件自包含，只需 requests 即可运行。

---

## 🚀 快速上手

```python
from autoadapter_skill import AutoAdapterGenerator

gen = AutoAdapterGenerator()

# 一行生成并保存适配器
code = gen.generate("https://jsonplaceholder.typicode.com/posts")
path = gen.save()  # 保存到 adapters/posts.py
print(f"✅ 已保存到: {path}")

# 运行生成的适配器
# python adapters/posts.py --limit 20 --pretty
```

---

## 📖 全部 API

### 🔧 生成器

| 方法 | 用途 |
|------|------|
| `AutoAdapterGenerator()` | 创建适配器生成器实例 |
| `gen.analyze(url, **kwargs)` | 分析网站结构，返回分析结果 |
| `gen.generate(url, goal="list", adapter_name=None, ...)` | 分析 → AI 增强 → 代码生成，一步到位 |
| `gen.save(filepath=None)` | 保存生成的适配器到文件 |

### 🏗️ 分析器

| 方法 | 用途 |
|------|------|
| `WebsiteAnalyzer()` | 创建网站分析器实例 |
| `analyzer.analyze(url)` | 检测内容类型 (API/SSR/SPA/HTML)，提取 JSON 样本，发现内嵌 SSR 数据 |

### 🔄 生成的适配器（自包含 .py）

| 函数 | 用途 |
|------|------|
| `fetch(limit=20, **kwargs)` | 获取原始数据（含重试和错误处理） |
| `transform(data: list) -> list` | 转换为统一格式（字段映射） |
| `run(limit=20, **kwargs) -> list` | 完整流程：fetch → transform |
| `main()` | CLI 入口: `--limit`, `--output`, `--pretty` |

### 🎯 数据目标 (goal)

| 目标 | 说明 |
|:----:|------|
| `list` | 列表型数据（默认），如文章列表、商品列表 |
| `detail` | 单条详情数据，如商品详情、文章内容 |
| `search` | 搜索式数据，需用户提供关键词 |
| `download` | 文件/资源下载类 |

### ⚙️ 配置选项

| 环境变量 | 说明 | 默认值 |
|---------|------|--------|
| `ADAPTER_OUTPUT_DIR` | 适配器输出目录 | `./adapters` |
| `MAX_RETRIES` | 最大重试次数 | 3 |
| `REQUEST_TIMEOUT` | 请求超时（秒） | 30 |
| `RETRY_DELAY` | 重试间隔（秒） | 2 |

---

## 🎯 网站类型检测

| 类型 | 检测方式 | 数据获取方式 |
|:----:|----------|-------------|
| **API** 🏆 | 响应 Content-Type 含 `json` | 直接 requests.get，速度快 |
| **SSR** | 服务端渲染，HTML 内嵌 JSON | requests + HTML 解析提取 `__NUXT__` / `__NEXT_DATA__` / `window.__INITIAL_STATE__` |
| **SPA** | 客户端渲染，需浏览器 | 提示用户改用浏览器工具先获取数据 |
| **静态 HTML** | 纯 HTML 页面 | requests + BeautifulSoup 解析 |

---

## 💡 推荐用法

### Python API（AI 员工使用）

```python
from autoadapter_skill import AutoAdapterGenerator

gen = AutoAdapterGenerator()

# 分析 + 生成 + 保存
code = gen.generate("https://jsonplaceholder.typicode.com/posts", goal="list", adapter_name="posts")
path = gen.save()
print(f"✅ 适配器已保存: {path}")

# 分步使用
analysis = gen.analyze("https://api.example.com/data")
print(f"类型: {analysis.content_type}, 样本: {len(analysis.data_samples)} 个")
```

### 运行生成的适配器

```python
# 方法1：直接用 python 执行
# python adapters/posts.py --limit 20 --pretty

# 方法2：在代码中 import 使用
import sys, json
sys.path.insert(0, "adapters")
from posts import run

data = run(limit=10)
print(json.dumps(data, ensure_ascii=False, indent=2))
```

---

## 📊 使用场景示例

### 场景 1：快速从 API 生成适配器

```python
from autoadapter_skill import AutoAdapterGenerator

gen = AutoAdapterGenerator()
code = gen.generate("https://jsonplaceholder.typicode.com/posts",
                    goal="list", adapter_name="posts")
path = gen.save()
print(f"✅ 适配器已保存到: {path}")
```

### 场景 2：分步分析，确认后再生成

```python
from autoadapter_skill import AutoAdapterGenerator

gen = AutoAdapterGenerator()

# 1. 先分析
analysis = gen.analyze("https://api.example.com/data")
print(f"类型: {analysis.content_type}")
print(f"数据样本: {len(analysis.data_samples)} 个")
print(f"检测到的字段: {list(analysis.data_samples[0].keys()) if analysis.data_samples else '无'}")

# 2. 确认后再生成
code = gen.generate("https://api.example.com/data", goal="list", adapter_name="my_adapter")
path = gen.save("adapters/my_adapter.py")
```

### 场景 3：批量生成多个适配器

```python
from autoadapter_skill import AutoAdapterGenerator

gen = AutoAdapterGenerator()
sites = [
    ("https://jsonplaceholder.typicode.com/posts", "posts"),
    ("https://jsonplaceholder.typicode.com/comments", "comments"),
    ("https://jsonplaceholder.typicode.com/users", "users"),
]

for url, name in sites:
    code = gen.generate(url, goal="list", adapter_name=name)
    path = gen.save()
    print(f"✅ {name} -> {path}")
```

---

## 📁 文件结构

```
autoadapter_skill/
├── SKILL.md                    # 本文件
├── __init__.py                 # 包入口
├── website_analyzer.py         # ⭐ 网站分析器
│   - 检测内容类型 (API/SSR/SPA/HTML)
│   - 提取 JSON 数据结构和样本
│   - 发现内嵌 SSR 数据
│   - 检测前端框架
│   - 发现 API 端点
│
├── code_generator.py           # ⭐ 代码生成器
│   - 从分析结果生成 Python 代码
│   - 支持重试、超时、错误处理
│   - 自动字段映射
│
├── adapter_generator.py        # 一站式生成器
│   - 整合分析 + AI 增强 + 代码生成
│
├── requirements.txt
└── adapters/                   # 生成的适配器
    ├── posts.py                # ✅ 示例：可直接运行
    └── ...
```

---

## 🔧 故障排查

| 症状 | 原因 | 解决 |
|------|------|------|
| 分析结果为 "SPA" 类型 | 网站是客户端渲染 | 先用浏览器工具获取数据，或用 `navigate_to_url` 打开后分析网络请求 |
| AI 增强失败 | 未安装 `lovana_llm` | `pip install lovana_llm`，或在 `generate()` 传 `use_ai=False` 跳过 |
| 生成的适配器请求失败 | URL 需要认证/参数 | 分析网站的认证方式，手动修改适配器的 headers/cookies |
| 字段映射不准确 | AI 推断可能与实际不符 | 检查站点实际返回字段，手动修改 `transform()` 函数 |
| `fetch()` 返回空列表 | 网络问题或站点结构变化 | 检查网络，确认站点 URL 是否仍有效 |
| `ImportError: no module named 'autoadapter_skill'` | 模块不在路径中 | `cd autoadapter_skill && python -c "from autoadapter_skill import ..."` |
