"""
网站分析器 — 获取并分析目标网站的结构、API 端点、数据格式
"""

import re
import json
from urllib.parse import urlparse, urljoin
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class AnalysisResult:
    """网站分析结果"""
    url: str
    domain: str
    page_title: str = ""
    content_type: str = "unknown"  # api / ssr / spa / static
    api_endpoints: list = field(default_factory=list)
    data_samples: list = field(default_factory=list)
    detected_framework: str = ""
    ssr_data: dict = field(default_factory=dict)
    html_structure: dict = field(default_factory=dict)
    possible_commands: list = field(default_factory=list)


class WebsiteAnalyzer:
    """
    分析目标网站，提取 API 端点、数据结构、页面框架等信息。
    用于为后续的 AI 适配器生成提供依据。
    """

    COMMON_API_PATTERNS = [
        r'/api/',
        r'/v\d+/',
        r'/graphql',
        r'/rest/',
        r'/json/',
        r'\.json',
        r'__INITIAL_STATE__',
        r'window\.__NUXT__',
        r'window\.__DATA__',
        r'window\.__INITIAL_',
        r'window\.__APOLLO_',
        r'window\.__RELAY_',
        r'<script id="__NEXT_DATA__"',
        r'<script id="__SWR_DATA__"',
    ]

    FRAMEWORK_SIGNATURES = {
        "react": ["__NEXT_DATA__", "react", "React.", "createRoot"],
        "vue": ["__NUXT__", "vue", "Vue.", "createApp"],
        "angular": ["ng-version", "Angular", "ng-app"],
        "svelte": ["svelte", "__SVELTE_"],
        "nuxt": ["__NUXT__", "nuxt"],
        "nextjs": ["__NEXT_DATA__", "next"],
    }

    def __init__(self, session=None):
        self.session = session
        self.result = None

    def analyze(self, url: str, html_content: str = None, headers: dict = None) -> AnalysisResult:
        """
        分析网站的主入口
        
        Args:
            url: 目标网站 URL
            html_content: 可选的 HTML 内容（如果已提前获取）
            headers: 可选的请求头
            
        Returns:
            AnalysisResult: 分析结果
        """
        parsed = urlparse(url)
        result = AnalysisResult(
            url=url,
            domain=parsed.netloc,
        )

        if not html_content:
            html_content = self._fetch_page(url, headers)
            if not html_content:
                return result

        # 检测内容类型和框架
        result.content_type = self._detect_content_type(url, html_content)
        result.detected_framework = self._detect_framework(html_content)
        result.page_title = self._extract_title(html_content)

        # 提取嵌入式 SSR 数据
        result.ssr_data = self._extract_ssr_data(html_content, result.detected_framework)

        # 发现 API 端点
        result.api_endpoints = self._discover_endpoints(url, html_content)

        # 提取数据样本
        if result.ssr_data:
            result.data_samples = self._extract_data_samples(result.ssr_data)

        # 推断可能的命令
        result.possible_commands = self._infer_commands(result)

        # 提取 HTML 结构信息
        result.html_structure = self._extract_html_structure(html_content)

        # 如果 JSON 响应中有数据，提取数据样本
        if hasattr(self, '_last_json_response') and self._last_json_response is not None:
            json_data = self._last_json_response
            # 如果顶层是列表，直接作为数据样本
            if isinstance(json_data, list) and len(json_data) > 0:
                sample_items = json_data[:5]
                result.data_samples = [{
                    "key": "items",
                    "count": len(json_data),
                    "sample": sample_items[:3] if isinstance(sample_items[0], dict) else sample_items,
                    "path": ".[]",
                }]
                if not result.possible_commands:
                    result.possible_commands.append({
                        "name": "list",
                        "description": f"获取 {result.domain} 的数据列表",
                        "data_key": ".[]",
                    })
            # 如果顶层是字典，找其中的数组
            elif isinstance(json_data, dict):
                for key, value in json_data.items():
                    if isinstance(value, list) and len(value) > 0 and len(value) < 100:
                        sample = value[:3]
                        result.data_samples.append({
                            "key": key,
                            "count": len(value),
                            "sample": sample[:3] if isinstance(sample[0], dict) else sample,
                            "path": f".{key}",
                        })
                        if not result.possible_commands:
                            result.possible_commands.append({
                                "name": key.lower(),
                                "description": f"获取 {key} 数据",
                                "data_key": f".{key}",
                            })
                        break  # 只取第一个数组
        
        self.result = result
        return result

    def _fetch_page(self, url: str, headers: dict = None) -> Optional[str]:
        """获取页面内容"""
        try:
            import requests
            hdrs = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                              "AppleWebKit/537.36 (KHTML, like Gecko) "
                              "Chrome/120.0.0.0 Safari/537.36",
                "Accept": "text/html,application/json,*/*",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            }
            if headers:
                hdrs.update(headers)

            resp = requests.get(url, headers=hdrs, timeout=15, allow_redirects=True)
            
            # 检测内容类型
            ct = resp.headers.get("Content-Type", "")
            text = resp.text
            
            # 尝试解析 JSON（即使是 text/plain 也可能是 JSON）
            try:
                parsed = resp.json()
                # 标记为 JSON 以便后续处理
                self._last_json_response = parsed
                return json.dumps(parsed, ensure_ascii=False)
            except (json.JSONDecodeError, ValueError):
                self._last_json_response = None
                
            if "json" in ct:
                return text
            return text
        except Exception as e:
            print(f"[WARN] 获取页面失败: {e}")
            return None

    def _detect_content_type(self, url: str, html: str) -> str:
        """检测内容类型"""
        # 是否是 API URL（包含 .json 等所有模式）
        if any(re.search(p, url, re.I) for p in self.COMMON_API_PATTERNS[:6]):
            try:
                json.loads(html)
                return "api"
            except (json.JSONDecodeError, TypeError):
                pass

        # 检测是否是 JSON API 响应
        try:
            json.loads(html)
            return "api"
        except (json.JSONDecodeError, TypeError):
            pass

        # 检测 SPA
        if html and ('<div id="root">' in html or '<div id="app">' in html):
            if self._detect_framework(html):
                return "spa"
            return "spa"

        # SSR
        if html and any(p in html for p in [
            "__NEXT_DATA__", "__NUXT__", "__INITIAL_STATE__",
            "server-rendered", "data-server-rendered"
        ]):
            return "ssr"

        return "static"

    def _detect_framework(self, html: str) -> str:
        """检测前端框架"""
        if not html:
            return ""
        for framework, signatures in self.FRAMEWORK_SIGNATURES.items():
            if any(sig in html for sig in signatures):
                return framework
        return ""

    def _extract_title(self, html: str) -> str:
        """提取页面标题"""
        if not html:
            return ""
        m = re.search(r'<title[^>]*>([^<]+)</title>', html, re.I | re.S)
        return m.group(1).strip() if m else ""

    def _extract_ssr_data(self, html: str, framework: str) -> dict:
        """提取嵌入式 SSR 数据"""
        if not html:
            return {}

        data = {}

        # Next.js __NEXT_DATA__
        m = re.search(
            r'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>',
            html, re.I | re.S
        )
        if m:
            try:
                data["__NEXT_DATA__"] = json.loads(m.group(1))
            except json.JSONDecodeError:
                pass

        # Nuxt __NUXT__
        m = re.search(
            r'window\.__NUXT__\s*=\s*({.*?});',
            html, re.I | re.S
        )
        if m:
            try:
                data["__NUXT__"] = json.loads(m.group(1))
            except json.JSONDecodeError:
                pass

        # __INITIAL_STATE__
        m = re.search(
            r'window\.__INITIAL_STATE__\s*=\s*({.*?});',
            html, re.I | re.S
        )
        if m:
            try:
                data["__INITIAL_STATE__"] = json.loads(m.group(1))
            except json.JSONDecodeError:
                pass

        # __APOLLO_STATE__
        m = re.search(
            r'window\.__APOLLO_STATE__\s*=\s*({.*?});',
            html, re.I | re.S
        )
        if m:
            try:
                data["__APOLLO_STATE__"] = json.loads(m.group(1))
            except json.JSONDecodeError:
                pass

        # 通用 SSR data 模式
        for pattern in [r'window\.__DATA__\s*=\s*({.*?});',
                        r'window\.__INITIAL_[\w]+__\s*=\s*({.*?});']:
            m = re.search(pattern, html, re.I | re.S)
            if m:
                try:
                    data["__SSR_DATA__"] = json.loads(m.group(1))
                except json.JSONDecodeError:
                    pass

        return data

    def _discover_endpoints(self, url: str, html: str) -> list:
        """发现 API 端点"""
        endpoints = []

        if not html:
            return endpoints

        # 从 SSR 数据中发现的端点
        for key, data in self._extract_ssr_data(html, "").items():
            found = self._find_urls_in_data(data, url)
            endpoints.extend(found)

        # 从页面中提取 API URL 模式
        patterns = [
            r'fetch\([\'"]([^\'"]+)[\'"]\)',
            r'axios\([\'"]([^\'"]+)[\'"]\)',
            r'\$\.get\([\'"]([^\'"]+)[\'"]\)',
            r'\$\.post\([\'"]([^\'"]+)[\'"]\)',
            r'url:\s*[\'"]([^\'"]+)[\'"]',
            r'"url"\s*:\s*"([^"]+)"',
            r"url':\s*'([^']+)'",
        ]

        for pattern in patterns:
            for m in re.finditer(pattern, html, re.I):
                endpoint = m.group(1)
                if any(ep in endpoint for ep in ["/api/", "/graphql", ".json", "/v1/", "/v2/"]):
                    full_url = urljoin(url, endpoint)
                    if full_url not in endpoints:
                        endpoints.append(full_url)

        return list(set(endpoints))

    def _find_urls_in_data(self, obj, base_url, depth=0, max_depth=3):
        """递归在数据对象中查找 URL"""
        urls = []
        if depth > max_depth:
            return urls

        if isinstance(obj, dict):
            for k, v in obj.items():
                if isinstance(v, str) and ('/api/' in v or '.json' in v or '/graphql' in v):
                    if v.startswith('http'):
                        urls.append(v)
                    elif v.startswith('/'):
                        urls.append(urljoin(base_url, v))
                elif isinstance(v, (dict, list)):
                    urls.extend(self._find_urls_in_data(v, base_url, depth + 1, max_depth))
        elif isinstance(obj, list):
            for item in obj:
                urls.extend(self._find_urls_in_data(item, base_url, depth + 1, max_depth))

        return urls

    def _extract_html_structure(self, html: str) -> dict:
        """提取 HTML 结构摘要"""
        if not html:
            return {}

        structure = {}

        # 提取主要列表/卡片容器
        list_patterns = [
            (r'class="([^"]*list[^"]*)"', "list"),
            (r'class="([^"]*card[^"]*)"', "card"),
            (r'class="([^"]*item[^"]*)"', "item"),
            (r'class="([^"]*feed[^"]*)"', "feed"),
            (r'class="([^"]*grid[^"]*)"', "grid"),
        ]

        containers = []
        for pattern, ctype in list_patterns:
            for m in re.finditer(pattern, html, re.I):
                containers.append({"type": ctype, "class": m.group(1)})

        structure["containers"] = containers[:10]

        # 提取主要的 data-* 属性
        data_attrs = set()
        for m in re.finditer(r'(data-[\w-]+)=["\']([^"\']*)["\']', html, re.I):
            if len(data_attrs) < 20:
                data_attrs.add(f"{m.group(1)}={m.group(2)}")
        structure["data_attributes"] = list(data_attrs)

        # 提取页面中主要的文本模式（标题、价格、日期等）
        text_patterns = {
            "titles": re.findall(r'<h[1-3][^>]*>([^<]+)</h[1-3]>', html)[:5],
            "links": re.findall(r'<a[^>]*href=["\']([^"\']+)["\'][^>]*>([^<]+)</a>', html)[:10],
        }
        structure["text_patterns"] = text_patterns

        return structure

    def _extract_data_samples(self, ssr_data: dict) -> list:
        """从 SSR 数据中提取数据样本"""
        samples = []

        def _find_lists(data, depth=0, max_depth=4):
            """递归查找数组数据"""
            found = []
            if depth > max_depth:
                return found

            if isinstance(data, dict):
                for k, v in data.items():
                    if isinstance(v, list) and len(v) > 0 and len(v) < 50:
                        if isinstance(v[0], (dict, list)):
                            found.append({
                                "key": k,
                                "count": len(v),
                                "sample": v[:3],
                                "path": f".{k}"
                            })
                    elif isinstance(v, (dict, list)):
                        found.extend(_find_lists(v, depth + 1, max_depth))
            elif isinstance(data, list):
                for i, item in enumerate(data[:3]):
                    if isinstance(item, (dict, list)):
                        found.extend(_find_lists(item, depth + 1, max_depth))

            return found

        samples = _find_lists(ssr_data)
        return samples[:10]

    def _infer_commands(self, result: AnalysisResult) -> list:
        """根据分析结果推断可能的命令"""
        commands = []
        domain = result.domain

        # 根据域名猜测站点名
        site_name = domain.split('.')[0]

        # 分析数据样本推断命令
        if result.data_samples:
            for sample in result.data_samples:
                key = sample.get("key", "data")
                cmd_name = key.replace("_", "-").replace(" ", "-").lower()
                if cmd_name in ["list", "items", "data"]:
                    cmd_name = "list"
                commands.append({
                    "name": cmd_name,
                    "description": f"获取 {result.page_title or domain} 的 {key} 数据",
                    "data_key": sample.get("path", ""),
                    "sample_count": sample.get("count", 0),
                })

        # 如果 SSR 数据中有具体分类
        if result.ssr_data:
            data = result.ssr_data
            if isinstance(data, dict):
                for key in data:
                    if key in ["__NEXT_DATA__", "__NUXT__", "__INITIAL_STATE__"]:
                        inner = data[key]
                        if isinstance(inner, dict):
                            # 尝试找 props > pageProps
                            for sub_key in inner:
                                if isinstance(inner[sub_key], (dict, list)):
                                    if not any(c["name"] == sub_key.lower() for c in commands):
                                        commands.append({
                                            "name": sub_key.lower().replace("_", "-"),
                                            "description": f"获取 {sub_key} 数据",
                                            "data_key": f".{key}.{sub_key}",
                                        })

        if not commands:
            commands.append({
                "name": "list",
                "description": f"获取 {domain} 的数据列表",
                "data_key": "",
            })

        return commands


    def summarize(self, result: AnalysisResult = None) -> dict:
        """生成可读的分析摘要"""
        r = result or self.result
        if not r:
            return {"error": "No analysis result"}

        summary = {
            "url": r.url,
            "domain": r.domain,
            "title": r.page_title,
            "type": r.content_type,
            "framework": r.detected_framework,
            "commands_found": len(r.possible_commands),
            "api_endpoints_found": len(r.api_endpoints),
            "data_samples_found": len(r.data_samples),
            "ssr_data_available": bool(r.ssr_data),
            "recommended_commands": [
                {
                    "name": f"{r.domain.split('.')[0]} {c['name']}",
                    "description": c["description"],
                    "mode": "public" if r.content_type == "api" else "browser",
                }
                for c in r.possible_commands
            ],
            "raw": {
                "api_endpoints": r.api_endpoints,
                "data_samples": r.data_samples[:3] if r.data_samples else [],
                "possible_commands": r.possible_commands,
            }
        }
        return summary


# CLI 入口
if __name__ == "__main__":
    import sys
    url = sys.argv[1] if len(sys.argv) > 1 else "https://example.com"
    analyzer = WebsiteAnalyzer()
    result = analyzer.analyze(url)
    summary = analyzer.summarize(result)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
