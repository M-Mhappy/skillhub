"""Install the bundled pyweixin wheel into the active Python environment."""

from __future__ import annotations

import argparse
import importlib.metadata
import importlib.util
import subprocess
import sys
from pathlib import Path


WHEEL_NAME = "pyweixin-1.9.8-py3-none-any.whl"
REQUIRED_MODULES = [
    "pywinauto",
    "pyautogui",
    "psutil",
    "win32api",
    "win32gui",
    "win32con",
    "win32clipboard",
    "packaging",
    "emoji",
    "comtypes",
    "pycaw",
    "sounddevice",
    "soundfile",
]


def skill_dir() -> Path:
    return Path(__file__).resolve().parents[1]


def missing_runtime_modules() -> list[str]:
    return [name for name in REQUIRED_MODULES if importlib.util.find_spec(name) is None]


def print_ui_error_notice() -> None:
    print("UI troubleshooting: if pywinauto cannot locate session/contact/list controls, retry with is_maximize=True first.")
    print("If the method has no is_maximize parameter, call Navigator.open_weixin(is_maximize=True) before retrying.")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-deps", action="store_true", help="Install pyweixin without resolving dependencies.")
    parser.add_argument("--dry-run", action="store_true", help="Print the pip command without running it.")
    args = parser.parse_args()

    wheel = skill_dir() / "references" / WHEEL_NAME
    if not wheel.is_file():
        raise SystemExit(f"Bundled wheel not found: {wheel}")

    cmd = [sys.executable, "-m", "pip", "install", "--force-reinstall"]
    if args.no_deps:
        cmd.append("--no-deps")
    cmd.append(str(wheel))

    print("Python:", sys.executable)
    print("Wheel:", wheel)
    print("Command:", " ".join(f'"{part}"' if " " in part else part for part in cmd))

    if args.no_deps:
        missing = missing_runtime_modules()
        if missing:
            print("Warning: --no-deps was requested, but these runtime modules are not importable:")
            for name in missing:
                print(f"- {name}")

    if args.dry_run:
        return 0

    result = subprocess.run(cmd)
    if result.returncode != 0:
        return result.returncode

    try:
        version = importlib.metadata.version("pyweixin")
    except importlib.metadata.PackageNotFoundError:
        raise SystemExit("pip completed, but pyweixin metadata was not found")

    print(f"Installed pyweixin {version}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
