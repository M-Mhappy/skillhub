---
name: pyweixin-wechat-automation
description: Use bundled pyweixin wheel and embedded README/manual to automate Windows PC WeChat. Use when Codex needs to install pyweixin from this skill and operate WeChat for sending messages or files, exporting chat history or media, monitoring chats, auto-replying, inspecting contacts, using Moments, Collections, Calls, Navigator, Tools, friend settings, WeChat settings, or Windows clipboard/listening helpers.
---

# Pyweixin WeChat Automation

此技能用于让 agent 在具备对应 Python 环境后，安装 `references/pyweixin-1.9.8-py3-none-any.whl`，然后严格根据本 `SKILL.md` 内嵌的 README 和 `pyweixin操作手册.md` 内容操作 Windows PC 微信。

## 执行顺序

1. 定位本技能目录。
2. 安装 bundled whl 到当前 Python 环境：

```powershell
python -m pip install --force-reinstall "<skill_dir>\references\pyweixin-1.9.8-py3-none-any.whl"
```

3. 若当前环境没有 `python` 命令，使用当前 agent 可用的 Python 解释器执行同等 `-m pip install` 命令。
4. 默认让 pip 解析依赖；只有确认运行依赖已经存在时，才允许加 `--no-deps`。
5. 安装受限或缺少依赖时，先报告缺失依赖和阻塞原因，不要假装已经操作微信。
6. 根据用户请求和本文件下方手册内容选择 `pyweixin` 类、方法和参数执行微信操作。

## 权限和副作用规则

- 操作前确认 Windows PC 微信已安装、已登录、窗口可见。
- 如 UI 元素不可见，先按手册说明尝试 Windows 讲述人模式后再重试。
- 使用绝对路径传入文件、图片、音频、导出目录。
- 不要用多个线程同时操作同一个微信 UI；多任务按单线程顺序执行。
- 多个连续任务默认设置 `GlobalConfig.close_weixin = False`，避免反复关闭/重启微信。
- 当用户明确提出发送消息或文件，并提供收件人、内容或文件路径时，视为已经授权执行；不要再二次询问权限。若收件人、内容或文件路径不完整，先向用户补齐必要信息。
- 其他强副作用操作仍需用户明确提出具体动作后执行：添加/删除好友、清空聊天记录、拉黑、修改隐私或微信设置、退出登录、发布/点赞/评论朋友圈、接受群邀请、抢红包。
- `pyweixin` 中发送、设置、好友权限等无显式返回值的方法成功执行后返回 `None` 是正常现象；只要没有抛异常或出现明确 UI 错误，无需因为返回值为 `None` 二次尝试。
- 微信退出登录是微信官方对于个人账号的保护机制，属于正常现象；无需因此担心封号风险。
- 执行后向用户报告实际调用的方法、关键参数和结果或错误。

## 错误处理优先措施

- 遇到 pywinauto 定位不到会话列表、通讯录列表或各种列表控件时，先优先将相关方法的 `is_maximize=True` 显式传入，把微信窗口撑到全屏后重试。
- 这是列表类 UI 控件折叠、被隐藏或窗口过小导致定位失败时的第一处理方法，应在尝试讲述人模式或其他 UI 可见性方案之前先执行。
- 常见需要重试的方法包括 `Navigator.open_dialog_window`、`Navigator.find_friend_in_SessionList`、`Navigator.open_contacts`、`Contacts.get_friends_name`、`Contacts.get_groupMembers_info`、`Messages.dump_sessions` 等依赖会话/联系人/列表控件的调用。
- 若一个方法没有 `is_maximize` 参数，先用 `Navigator.open_weixin(is_maximize=True)` 打开或激活主窗口，再运行原操作。

## 常用导入

```python
from pyweixin import Navigator, Messages, Files, Contacts, Moments, Monitor, AutoReply, Tools, GlobalConfig
```

```python
GlobalConfig.close_weixin = False
GlobalConfig.load_delay = 3.5
GlobalConfig.search_pages = 5
```

## 低风险检查

```python
from pyweixin import Tools, Contacts, Messages

print(Tools.about_weixin())
print(Contacts.get_friends_name(close_weixin=False))
print(Messages.dump_sessions(chat_only=True, close_weixin=False))
```

## Wheel Source Signature Priority

- The bundled whl source signature is the authority for execution.
- If the embedded README/manual conflicts with this section, use this section and the whl source.
- Do not call obsolete manual names. Use `FriendSettings.block_friend`, not `add_friend_to_blacklist` or `add_to_blacklist`.
- The source method for clearing chat history is spelled `clear_chat_histpry`; call it exactly that way.
- Parameter names are case-sensitive. Use `is_maximize`, not `Is_maximize`.

## Source Signature Correction Index

### Messages

- `Messages.send_messages_to_friend(friend, messages, at_members=[], at_all=False, search_pages=None, clear=None, send_delay=None, is_maximize=None, close_weixin=None)`
- `Messages.dump_recent_sessions(recent='Today', chat_only=False, is_maximize=None, close_weixin=None)`
- `Messages.dump_sessions(chat_only=False, is_maximize=None, close_weixin=None)`
- `Messages.dump_chat_history(friend, number, search_content=None, is_json=False, save_detail=False, target_folder=None, search_pages=None, is_maximize=None, close_weixin=None)`
- `Messages.search_chat_history(keyword, number=None, is_maximize=None, close_weixin=None)`

### Files

- `Files.send_files_to_friend(friend, files, with_messages=False, messages=[str], messages_first=False, send_delay=None, clear=None, is_maximize=None, close_weixin=None)`
- `Files.send_files_to_friends(friends, files_list, with_messages=False, messages_list=[], messages_first=False, clear=None, send_delay=None, is_maximize=None, close_weixin=None)`

### Contacts

- `Contacts.get_groupMembers_info(group, is_maximize=None, search_pages=None, close_weixin=None)`
- `Contacts.get_serAcc_detail(is_maximize=None, close_weixin=None, is_json=False)`
- `Contacts.get_offAcc_detail(is_maximize=None, close_weixin=None, is_json=False)`

### FriendSettings

- `FriendSettings.block_friend(friend, state=0, search_pages=None, is_maximize=None, close_weixin=None)`
- `FriendSettings.clear_chat_histpry(friend, search_pages=None, is_maximize=None, close_weixin=None)`
- `FriendSettings.mute_notification(friend, mute=0, fold_chat=0, search_pages=None, is_maximize=None, close_weixin=None)`
- `FriendSettings.delete_friend(friend, clear_chat_history=1, search_pages=None, is_maximize=None, close_weixin=None)`
- `FriendSettings.change_remark(friend, remark, description=None, phoneNum=None, clear_phoneNum=False, search_pages=None, is_maximize=None, close_weixin=None)`

### AutoReply / Monitor

- `AutoReply.auto_reply_to_friend(dialog_window, duration, callback, contexts=[], save_file=False, save_media=False, target_folder=None, close_dialog_window=True)`
- `Monitor.listen_on_chat(dialog_window, duration, groupMembers=[], save_file=False, save_media=False, target_folder=None, close_dialog_window=True)`

### Collections

- `Collections.cardLink_to_url(number, delete=False, delay=0.5, is_maximize=None, close_weixin=None)`

### Call

- `Call.voice_call(friend, wait=False, is_maximize=None, close_weixin=None)`
- `Call.video_call(friend, wait=False, is_maximize=None, close_weixin=None)`

### Moments

- `Moments.post_moments(text='', medias=[], is_maximize=None, close_weixin=None)`
- `Moments.post_notes(content=None, text=None, files=[], is_maximize=None, close_weixin=None)`
- `Moments.dump_recent_posts(recent='Today', number=None, with_name=False, save_detail=False, target_folder=None, is_maximize=None, close_weixin=None)`
- `Moments.dump_friend_posts(friend, number, save_detail=False, target_folder=None, search_pages=None, is_maximize=None, close_weixin=None)`
- `Moments.like_posts(recent='Today', with_name=False, number=None, callback=None, is_maximize=None, close_weixin=None)`
- `Moments.like_friend_posts(friend, number, callback=None, is_maximize=None, close_weixin=None)`

### Navigator / Tools

- `Navigator.open_weixin(is_maximize=None, window_size=None)`
- `Navigator.open_dialog_window(friend, select=False, is_maximize=None, search_pages=None)`
- `Navigator.open_seperate_dialog_window(friend, select=False, is_maximize=None, window_minimize=False, close_weixin=None)`
- `Navigator.open_chat_history(friend, TabItem=None, search_pages=None, is_maximize=None, close_weixin=None)`
- `Navigator.open_chatinfo(friend, is_maximize=None, search_pages=None)`
- `Navigator.open_friend_profile(friend, is_maximize=None, search_pages=None)`
- `Navigator.open_chat_search_window(keyword, window_maximize=None, is_maximize=None, close_weixin=None)`
- `Navigator.search_official_account(name, load_delay=None, subscribe=False, is_maximize=None, close_weixin=None)`
- `Tools.about_weixin()`

### Obsolete Manual Name Mapping

- `add_friend_to_blacklist` / `add_to_blacklist` -> `FriendSettings.block_friend`
- `clear_chat_history` -> `FriendSettings.clear_chat_histpry` (source spelling)
- `mute_notifications` -> `FriendSettings.mute_notification`
- `Moments.post_moments(text=...)` -> `Moments.post_moments(text=...)`
- `close_weixin` -> `close_weixin`
- `Tools.about_weixin(open_folder=...)` -> `Tools.about_weixin()`
- `Moments.like_friend_posts` has no `use_green_send` parameter; remove that option

# README.md

### 获取方法（4.1+微信）

```bash
git clone https://github.com/Hello-Mr-Crab/pywechat.git
```

</br>

### 获取方法（3.9+微信）

#### 最新版本:1.9.7

```bash
pip install pywechat127==1.9.7
```

</br>

```bash
pip install --upgrade pywechat127
```

</br>

```bash
git clone https://github.com/Hello-Mr-Crab/pywechat.git
```

</br>

### pyweixin模块介绍(适用于4.1+微信)

pyweixin内所有方法需要先导入模块下的类然后调用内部方法🗺️🗺️

```python
from pyweixin import xx(class)
xx(class).yy(method)
```

#### WechatTools🌪️🌪️

##### class包括

- `Tools`:关于PC微信的一些工具,微信路径,运行状态,以及内部一些UI相关的判别方法。
- `Navigator`:打开微信内部一切可以打开的界面。

#### WechatAuto🛏️🛏️

##### class(类) 包括

- `AutoReply`:自动回复操作
- `Call`: 给某个好友打视频或语音电话。
- `Contacts`: 获取通讯录内各分区(联系人,企业微信联系人,公众号,服务号)好友的信息,获取共同群聊名称,获取好友个人简介
- `Files`: 文件发送，聊天文件从本地导出等。
- `FriendSettings`: PC微信针对某个好友的一些相关设置。
- `Messages`: 消息发送,聊天记录获取,聊天会话导出等条。
- `Moments`:针对微信朋友圈的一些方法,包括朋友圈界面内容获取，发布朋友圈
- `Monitor`:打开聊天窗口进行监听消息

#### WinSettings🔹🔹

##### class(类)包括

- `SystemSettings`:该模块中提供了一些修改windows系统设置的方法(在自动化过程中)。

#### utils🍬🍬

##### 内部的一些函数主要用来二次开发,大部分传入的参数是main_window,pywinauto实例化的对象(使用Navigator.open_weixin打开)

##### class 包括

- `Regex_Patterns`:自动化过程中用到的正则pattern。
- `Special_Label`:微信内一些特殊的标签,比如:“消息已置顶”，这些标签随着微信的语言会变化。

##### func包括

- `At`:在群聊中At指定的一些好友
- `At_all`:在群聊中At所有人
- `auto_reply_to_friend_decorator`:自动回复好友装饰器
- `get_new_message_num`：获取新消息总数,微信按钮上的红色数字
- `scan_for_newMessages`：会话列表遍历一遍有新消息提示的对象,返回好友名称与数量
- `open_red_packet`: 点击打开好友发送的红包
- `language_detector`:微信当前使用语言检测(不能禁用WeChatAppex.exe(涉及到公众号,微信内置浏览器,视频号等功能),原理是查询WeChatAppex.exe命令行参数)

</br>

### pyweixin使用示例

所有自动化操作只需两行代码即可实现，即:

```python
from pyweixin import xxx
xxx.yy
```

#### 发送语音消息给好友

```python
'''
微信版本>=4.1.9,且配置过虚拟驱动,并且安装sounddevice与soundfile库,具体可见
https://mrcrab.blog.csdn.net/article/details/160481307?fromshare=blogdetail&sharetype=blogdetail&sharerId=160481307&sharerefer=PC&sharesource=weixin_73953650&sharefrom=from_link
''''
from pyweixin import Messages
Messages.send_audios_to_friend(friend='小号测试',audios=[r"E:\Desktop\录音.wav",r"E:\Desktop\音乐.mp3",r"E:\Desktop\音乐.ogg"])
```

#### 关于微信的基本信息输出

```python
from pyweixin import Tools
print(Tools.about_weixin())
```

#### 多线性监听多个聊天窗口消息

```python
from concurrent.futures import ThreadPoolExecutor
from pyweixin import Navigator,Monitor
#先打开所有好友的独立窗口
dialog_windows=[]
friends=['Hello,Mr Crab','Pywechat测试群']
durations=['1min']*len(friends)
for friend in friends:
    dialog_window=Navigator.open_seperate_dialog_window(friend=friend,window_minimize=True,close_weixin=True)
    dialog_windows.append(dialog_window)
with ThreadPoolExecutor() as pool:
    results=pool.map(lambda args: Monitor.listen_on_chat(*args),list(zip(dialog_windows,durations)))
for friend,result in zip(friends,results):
    print(friend,result)
#返回值 {'新消息总数':x,'文本数量':x,'文件数量':x,'图片数量':x,'视频数量':x,'链接数量':x,'文本内容':x,'消息发送人':x}
```

![image](https://github.com/Hello-Mr-Crab/pywechat/blob/main/pics/listen_on_chat多线程.png)
</br>

#### 多线程监听消息并自动回复

```python
from pyweixin import Navigator
from concurrent.futures import ThreadPoolExecutor
from pyweixin import Navigator,AutoReply
#自动回复函数传入参数是字符串和字符串列表(消息列表内所有可见的文本,可作为上下文),返回值须为字符串类型
def reply_func1(newMessage:str,contexts:list[str]):
    if '你好' in newMessage:
        return '你好,有什么可以帮您的吗[呲牙]?'
    if '在吗' in message:
        return '在的[旺柴]'
    return '自动回复[微信机器人]:您好,我当前不在,请您稍后再试'

def reply_func2(newMessage:str,contexts:list[str]):
    return '自动回复[微信机器人]:您好,我当前不在,请您稍后再试'

#先打开所有好友的独立窗口
dialog_windows=[]
friends=['abcdefghijklmnopqrstuvwxyz123456','Pywechat测试群']
for friend in friends:
    dialog_window=Navigator.open_seperate_dialog_window(friend=friend,window_minimize=True,close_weixin=True)
    dialog_windows.append(dialog_window)
durations=['1min','1min']
callbacks=[reply_func1,reply_func2]
with ThreadPoolExecutor() as pool:
    results=pool.map(lambda args: AutoReply.auto_reply_to_friend(*args),list(zip(dialog_windows,durations,callbacks)))
for friend,result in zip(friends,results):
    print(friend,result)
```

![image](https://github.com/Hello-Mr-Crab/pywechat/blob/main/pics/自动回复.png)
</br>

#### 朋友圈内容导出

```python
from pyweixin import Moments
#获取并导出今日前20个好友发布的朋友圈的具体内容
posts=Moments.dump_recent_posts(recent='Today',save_detail=True,number=10)
for dic in posts:
    print(dic)
```

![image](https://github.com/Hello-Mr-Crab/pywechat/blob/main/pics/朋友圈内容导出.png)
</br>

#### 发布朋友圈

```python
from pyweixin import Moments
Moments.post_moments(text='''发布朋友圈测试[旺柴]''',medias=[r"E:\Desktop\test0.png",r"E:\Desktop\test1.png"])
```

![image](https://github.com/Hello-Mr-Crab/pywechat/blob/main/pics/发朋友圈.png)
</br>

#### 好友朋友圈内容导出

```python
from pyweixin import Moments
Moments.dump_friend_posts(friend='xxx',number=3,save_detail=True,target_folder=r"E:\Desktop\好友朋友圈内容导出")
```

![image](https://github.com/Hello-Mr-Crab/pywechat/blob/main/pics/好友朋友圈内容导出.png)
![image](https://github.com/Hello-Mr-Crab/pywechat/blob/main/pics/好友朋友圈内容.png)
</br>

#### 好友朋友圈自定义评论

```python
from pyweixin import Moments
def comment_func(content):
    if 'xxx' in content:
        return 'yyy'
    return 'zzz'
Moments.like_friend_posts(friend='xxx',number=20,callback=comment_func)
```

#### 公众号文章url获取

```python
from pyweixin import Collections
Collections.collect_offAcc_articles(name='新华社',number=10)
urls=Collections.cardLink_to_url(number=10)
for url,text in urls.items():
    print(f'{text}\n{url}')
```

![image](https://github.com/Hello-Mr-Crab/pywechat/blob/main/pics/公众号文章url获取.png)
</br>

#### 此外pyweixin内所有方法及函数的一些位置参数支持全局设定,be like

```python
from pyweixin import Navigator,GlobalConfig
GlobalConfig.load_delay=2.5
GlobalConfig.is_maximize=True
GlobalConfig.close_weixin=False
Navigator.search_channels(search_content='微信4.0')
Navigator.search_miniprogram(name='问卷星')
Navigator.search_official_account(name='微信')
```

#### 其他类内method使用方法可见代码中详细的文档注释以及pyweixin操作手册.docx

> Note: this Pywechat historical README section is background only. For this skill, execute bundled pyweixin with the wheel source signatures above.

### Pywechat(3.9+微信)

#### WechatTools🌪️

##### 类包括

- Tools:关于PC微信的一些工具,包括打开PC微信内各个界面的open系列方法

- API:打开指定微信小程序，指定公众号,打开视频号的功能，若有其他开发者想自动化操作上述程序可调用此API

函数:该模块内所有函数与方法一致

#### WechatAuto🛏️

##### class

- `Messages`: 5种类型的发送消息方法，包括:单人单条,单人多条,多人单条,多人多条,转发消息:多人同一条。
- `Files`: 5种类型的发送文件方法，包括:单人单个,单人多个,多人单个,多人多个,转发文件:多人同一个。发送多个文件时，你只需将所有文件放入文件夹内，将文件夹路径传入即可。
- `FriendSettings`: 涵盖了PC微信针对某个好友的全部操作的方法。
- `GroupSettings`: 涵盖了PC微信针对某个群聊的全部操作的方法。
- `Contacts`: 获取3种类型通讯录好友的备注与昵称包括:微信好友,企业号微信,群聊名称与人数，数据返回格式为json。
- `Call`: 给某个好友打视频或语音电话。
- `AutoReply`:自动接听微信视频或语音电话,自动回复指定好友消息,自动回复所有好友消息。
- `Moments`:针对微信朋友圈的一些方法,包括数据获取，图片视频导出

##### 该模块内所有函数与方法一致

#### WinSettings🔹

##### 类

- Systemsettings:该模块中提供了一些修改windows系统设置的方法

##### 函数：该模块内所有函数与类内方法一致

### pywechat使用示例

#### 所有自动化操作只需两行代码即可实现

```python
from pywechat import xxx
xxx.yy

from pyweixin import xxx
xxx,yy
```

</br>

#### 在某个群聊自动回复(使用装饰器自定义回复内容)

```python
from pywechat.utils import auto_reply_to_group_decorator
@auto_reply_to_group_decorator(duration='2min',group_name='Pywechat测试群',at_only=True,at_other=True)
def reply_func(newMessage):
    if '你好' in newMessage:
        return '你好,请问有什么可以帮您的吗?'
    if '在吗' in newMessage:
        return '在的,请问有什么可以帮您的吗?'
    if '售后' in newMessage:
        return '''您好，您可以点击下方链接申请售后:
        https://github.com/Hello-Mr-Crab/pywechat'''
    if '算了' in newMessage or '不需要了' in newMessage:
        return '不好意思.未能为您提供满意的服务,欢迎下次光临'
    return '不好意思，未能理解您的需求'#最后总是要返回一个值，不要出现newMessage不在列举的情况,返回None
reply_func()
```

![image](https://github.com/Hello-Mr-Crab/pywechat/blob/main/pics/decorator.png)
</br>

#### 监听某个群聊或好友的窗口(自动保存聊天文件与图片和视频)

```python
from pywechat import listen_on_chat
filesave_folder=r"E:\Desktop\保存文件"
mediasave_folder=r"E:\Desktop\聊天图片与视频保存"
contents,senders,types=listen_on_chat(friend='测试群',duration='10min',save_file=True,file_folder=filesave_folder,save_media=True,media_folder=mediasave_folder)
print(contents,senders,types)
```

#### 朋友圈数据获取

```python
from pywechat import dump_recent_moments
moments=dump_recent_moments(recent='Today',number=20,save_detail=True)
for dict in moments:
    print(dict)
```

![image](https://github.com/Hello-Mr-Crab/pywechat/blob/main/pics/朋友圈数据获取.png)

注意，导出的结果为list[dict],每一条朋友圈对应一个dict,dict具体内容

{'好友备注':'','发布时间':'','文本内容':'','点赞者':'','评论内容':'','图片数量':'','视频数量':'','卡片链接':'','卡片链接内容':'','视频号':'','公众号链接内容':''}

</br>

#### 监听整个会话列表内所有好友的新消息(自动保存聊天文件)

```python
from pywechat import check_new_message
filesave_folder=r"E:\Desktop\文件保存"
newMessages=check_new_message(duration='5min',save_file=True,target_folder=filesave_folder)
#newMessages是[{'好友名称':'路人甲','好友类型':'群聊,好友或公众号','新消息条数':xx,'消息内容':[],'消息类型':[]}]
#格式的list[dict]
```

#### 转发与某个好友的一定数量文件给其他好友

```python
 #注意:微信转发消息单次上线为9,pywechat内转发消息,文件,链接,小程序等支持多个好友按9个为一组分批发送
 from pywechat import forward_files
 others=['路人甲','路人乙','路人丙','路人丁']
 forward_files(friend='测试群',others=others,number=20)
```

#### 保存指定数量聊天文件到本地

```python
from pywechat import save_files
folder_path=r'E:\Desktop\新建文件夹'
save_files(friend='测试群',number=20,folder_path=folder_path)
```

#### 群聊内自动回复(被@时触发)

```python
from pywechat import auto_reply_to_group
auto_reply_to_group(group_name='测试群',duration='20min',content='我被@了',at_only=True,at_others=True)
```

![image](https://github.com/Hello-Mr-Crab/pywechat/blob/main/pics/auto_reply_to_group.png)
</br>

#### 给某个好友发送多条信息

```python
from pywechat.WechatAuto import Messages
Messages.send_messages_to_friend(friend="文件传输助手",messages=['你好','我正在使用pywechat操控微信给你发消息','收到请回复'])
```

### 多任务使用示例

注意,微信不支持多线程，只支持单线程多任务轮流执行，pywechat也支持单线程多任务轮流执行，在运行多个实例时尽量请将所有函数与方法内的close_weixin参数设为False(默认为True)

这样只需要打开一次微信，多个任务便可以共享资源,更加高效，否则，每个实例在运行时都会重启一次微信，较为低效

多个线程同时操作一个微信界面,必然产生死锁,会导致界面卡死

```python
from pywechat.WechatAuto import Messages,Files
Messages.send_messages_to_friend(friend='好友1',messages=['在测试','ok'],close_weixin=False)
Files.send_files_to_friend(friend='文件传输助手',files=[r"E:\OneDrive\Desktop\测试专用"],with_messages=True,messages_first=True,messages=['在测试文件消息一起发，你应该先看到这条消息，后看到文件'],close_weixin=True)
```

![Alt text](https://github.com/Hello-Mr-Crab/pywechat/blob/main/pics/Ai接入实例.png)
</br>

### 检查新消息示例

```python
from pywechat import check_new_message
print(check_new_message())
```

![Alt text](https://github.com/Hello-Mr-Crab/pywechat/blob/main/pics/check_new_message.gif)

若你开启了语音自动转消息功能后,新消息中含有语音消息的话,可以将其转换结果一并记录。（1.9.7版本支持此功能）

</br>



# pyweixin操作手册

> 

## 说明

pyweixin的__init__.py

由于__init__.py的导入更改(为了接口统一,结构清晰)，所有的方法在使用时只能:

from pyweixin import xx(class)

xx(class).yy(method)

### UI可见方式

讲述人模式先于微信登录前运行，持续一段时间后(5min以上)关闭讲述人(可选)。 有大佬反应，开启讲述人模式后微信的UI便可以一览无余，经过测试发现的确如此，但要保证讲述人模式先于微信登录前运行，然后持续一段时间(5min以上)再关闭讲述人，就可以进行正常的自动化了。 同时，在实际使用时发现,使用次数若比较频繁(经常在微信登录前打开讲述人2~3次以上)，那么后续微信的UI屏蔽将不在存在，可以直接看到内部UI结构，且此状态会一直持续。

### 原理

Windows的可访问性API（UI Automation）在设计上必须向屏幕阅读器暴露所有UI元素的信息（包括隐藏、禁用元素） 这是为了确保视障用户能够通过讲述人完整了解界面结构，若应用程序直接阻止这种底层访问，会违反无障碍设计原则。

### 特例

该方法对隔壁的企业微信无用，意味着企业微信相较于微信对UI自动化的限制更严格，也意味着微信可能会采取同样的策略(目前还没发现) 但再整体考虑到微信与企业微信的受众群众来说，微信可能短时间内还不会采取这种极端策略。当然，这也与企业微信要推广自己家的API有关。

## 声明

1.在使用pyweixin进行微信自动化操作时，若操作过于频繁，微信会自动退出登录，此为微信正常检测机制，只要不违反微信使用协议(高频率大量发送非法信息,高频率添加好友,高频率拉好友进)，不会造成封号。此类情况无法避免，自行注意操作频率,对此，可以将一些函数内的delay参数设置为合适的数值。

2. pyweixin不得用于任何非法商业用途与活动，否则后果自负。

3.使用pyweixin前，请确保你已经了解并遵守微信的相关规定和政策。

总之，在适度合理的范围内使用UI自动化完成一些重复性的、机械性的工作，是值得提倡的。但过度依赖自动化工具，甚至试图通过自动化工具进行大规模的数据抓取、恶意营销等行为，则可能会触犯法律，同时也违背了微信的使用条款。因此，在使用时，一定要确保使用行为始终在合法合规的范围内。

## 获取方式

git获取最新版本

git clone https://github.com/Hello-Mr-Crab/pywechat.git

直接下载zip

## 模块导入

Pyweixin可以用来自动化微信的模块只有WeChatTools WeChatAuto，因此在使用文档中我们主要介绍这两个模块。

直接从pyweixin导入模块内的各个类

from pyweixin import Messages

Messages.send_messages_to_friend(friend='Hello,Mr Crab',messages=['你好'])

导入模块内的类

from pyweixin.WeChatAuto import Messages

Messages.send_messages_to_friend(friend='Hello,Mr Crab',messages=['你好'])

## WechatAuto

WechatAuto是pyweixin自动化操作微信的主模块,其内部共计包含10个类用来实现微信内置的一些功能。

### 1 Messages类

#### 1.1给单个好友发送消息 send_messages_to_friend()

Source signature (whl): `Messages.send_messages_to_friend(friend, messages, at_members=[], at_all=False, search_pages=None, clear=None, send_delay=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `messages` | Message list. |
| `at_members` | Members to mention in a group chat. |
| `at_all` | Whether to mention all members in a group chat. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `clear` | Whether to clear existing input before sending. |
| `send_delay` | Delay in seconds for send operations. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Messages

Messages.send_messages_to_friend(friend='Hello,Mr Crab',messages=['你好','发消息测试'])

或者

from pyweixin.WeChatAuto import Messages

Messages.send_messages_to_friend(friend='Hello,Mr Crab',messages=['你好','发消息测试'])

#### 1.2 给多个好友分别发送消息send_messages_to_friends()

Source signature (whl): `Messages.send_messages_to_friends(friends, messages, clear=None, send_delay=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friends` | List of friend, group, or chat names. |
| `messages` | Message list. |
| `clear` | Whether to clear existing input before sending. |
| `send_delay` | Delay in seconds for send operations. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Messages

Messages.send_messages_to_friends(friends=['文件传输助手','Hello,Mr Crab'],messages=[['你好','发消息测试'],['你好','发消息测试']])

或者

from pyweixin.WeChatAuto import Messages

Messages.send_messages_to_friends(friends=['文件传输助手','Hello,Mr Crab'],messages=[['你好','发消息测试'],['你好','发消息测试']])

#### 1.3 检查新消息check_new_messages()

Source signature (whl): `Messages.check_new_messages(is_maximize=None, search_pages=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Messages

Messages.check_new_messages(search_pages=0)

或者

from pyweixin.WeChatAuto import Messages

Messages.check_new_messages(search_pages=0)

说明:运行该方法时会在微信会话列表中查找所有带有新消息提示的好友并逐个打开对话窗口按照指定数量获取消息文本内容。

#### 1.4 导出最近聊天对象名称dump_recent_sessions()

Source signature (whl): `Messages.dump_recent_sessions(recent='Today', chat_only=False, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `recent` | Time filter such as Today, Yesterday, Week, or Month. |
| `chat_only` | Whether to return chat sessions only. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Messages

Messages.dump_recent_sessions(recent='Week')

或者

from pyweixin.WeChatAuto import Messages

Messages.dump_recent_sessions(recent='Week')

#### 1.5 导出聊天对象名称dump_sessions()

Source signature (whl): `Messages.dump_sessions(chat_only=False, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `chat_only` | Whether to return chat sessions only. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Messages

Messages.dump_sessions()

或者

from pyweixin.WeChatAuto import Messages

Messages.dump_sessions()

#### 1.6 导出聊天记录dump_chat_history()

Source signature (whl): `Messages.dump_chat_history(friend, number, search_content=None, is_json=False, save_detail=False, target_folder=None, search_pages=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `number` | Number of items to process or return. |
| `search_content` | Keyword used before traversing chat history. |
| `is_json` | Whether to return JSON text. |
| `save_detail` | Whether to save detailed exported content. |
| `target_folder` | Absolute output folder. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Messages

Messages.dump_chat_history(friend='文件传输助手',number=20)

或者

from pyweixin.WeChatAuto import Messages

Messages.dump_chat_history(friend='文件传输助手',number=20)

#### 1.7 关键字搜索聊天记录search_chat_history()

Source signature (whl): `Messages.search_chat_history(keyword, number=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `keyword` | Search keyword. |
| `number` | Number of items to process or return. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Messages

chat_history_detail=Messages.search_chat_history(keyword='你好')

print(chat_history_detail)

或者

from pyweixin.WeChatAuto import Messages

chat_history_detail=Messages.search_chat_history(keyword='你好')

print(chat_history_detail)

### 2 Files类

#### 2.1 给单个好友发送文件send_files_to_friend()

Source signature (whl): `Files.send_files_to_friend(friend, files, with_messages=False, messages=[str], messages_first=False, send_delay=None, clear=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `files` | List of absolute file paths. |
| `with_messages` | Whether to send messages with files. |
| `messages` | Message list. |
| `messages_first` | Whether to send messages before files. |
| `send_delay` | Delay in seconds for send operations. |
| `clear` | Whether to clear existing input before sending. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Files

Files.send_files_to_friend(friend='文件传输助手',files=[r"E:\Desktop\背景1.png",r"E:\Desktop\android.py"])

或者

from pyweixin.WeChatAuto import Files

Files.send_files_to_friend(friend='文件传输助手',files=[r"E:\Desktop\背景1.png",r"E:\Desktop\android.py"])

#### 2.2 给多个好友发送文件send_files_to_friends()

Source signature (whl): `Files.send_files_to_friends(friends, files_list, with_messages=False, messages_list=[], messages_first=False, clear=None, send_delay=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friends` | List of friend, group, or chat names. |
| `files_list` | File path lists aligned with friends. |
| `with_messages` | Whether to send messages with files. |
| `messages_list` | Message lists aligned with friends. |
| `messages_first` | Whether to send messages before files. |
| `clear` | Whether to clear existing input before sending. |
| `send_delay` | Delay in seconds for send operations. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Files

Files.send_files_to_friends(friends=['文件传输助手','Hello,Mr Crab'],files_list=[[r"E:\Desktop\背景1.png",r"E:\Desktop\android.py"],[r"E:\Desktop\背景1.png",r"E:\Desktop\android.py"]])

或者

from pyweixin.WeChatAuto import Files

Files.send_files_to_friends(friends=['文件传输助手','Hello,Mr Crab'],files_list=[[r"E:\Desktop\背景1.png",r"E:\Desktop\android.py"],[r"E:\Desktop\背景1.png",r"E:\Desktop\android.py"]])

#### 2.3获取文件夹内文件路径的两个demo

Import os

def find_files(folder_path):

'''获取给定文件夹内第一级目录下所有文件'''

files=[os.path.join(folder_path,file) for file in os.listdir(folder_path)]

return files

import os

def find_files_recursive(folder_path):

'''递归获取给定文件夹内所有的文件(系统盘可能涉及权限问题)'''

files=[]

with os.scandir(folder_path) as entries:

try:

for entry in entries:

if os.path.isfile(entry.path):

files.append(entry.path)

if os.path.isdir(entry.path):

files.extend(find_files_recursive(entry.path))

except PermissionError as e:

print(f'无权访问！{e}')

return files

#### 2.4 保存与好友的聊天文件 save_chatfiles()

Source signature (whl): `Files.save_chatfiles(friend, number, target_folder=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `number` | Number of items to process or return. |
| `target_folder` | Absolute output folder. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Files

Files.save_chatfiles(friend='文件传输助手')

或者

from pyweixin.WeChatAuto import Files

Files.save_chatfiles(friend='文件传输助手')

#### 2.5 导出微信聊天文件export_wxfiles()

Source signature (whl): `Files.export_wxfiles(year=time.strftime('%Y'), month=None, target_folder=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `year` | Use the whl source signature above; default value is shown there. |
| `month` | Use the whl source signature above; default value is shown there. |
| `target_folder` | Absolute output folder. |

示例

from pyweixin import Files

Files.export_wxfiles(year='2024',month='10')

或者

from pyweixin.WeChatAuto import Files

Files.export_wxfiles(year='2024',month='10')

#### 2.6 导出微信聊天视频export_videos()

Source signature (whl): `Files.export_videos(year=time.strftime('%Y'), month=None, target_folder=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `year` | Use the whl source signature above; default value is shown there. |
| `month` | Use the whl source signature above; default value is shown there. |
| `target_folder` | Absolute output folder. |

示例

from pyweixin import Files

Files.export_videos(year='2024',month='10')

或者

from pyweixin.WeChatAuto import Files

Files.export_videos(year='2024',month='10')

#### 2.6 导出最近使用聊天文件export_recent_files()

Source signature (whl): `Files.export_recent_files(target_folder=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `target_folder` | Absolute output folder. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Files

Files.export_recent_files()

或者

from pyweixin.WeChatAuto import Files

Files.export_recent_files()

### 3 Contacts类

#### 3.1获取所有好友详细信息get_friends_detail()

Source signature (whl): `Contacts.get_friends_detail(is_maximize=None, close_weixin=None, is_json=False)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |
| `is_json` | Whether to return JSON text. |

示例

from pyweixin import Contacts

print(Contacts.get_friends_detail())

或者

from pyweixin.WeChatAuto import Contacts

print(Contacts.get_friends_detail())

#### 3.2获取所有群聊信息(本人加入的)get_groups_info()

Source signature (whl): `Contacts.get_groups_info(is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Contacts

print(Contacts.get_groups_info())

或者

from pyweixin.WeChatAuto import Contacts

print(Contacts.get_groups_info())

#### 3.3 获取所有企业微信好友信息get_wecom_friends_detail()

Source signature (whl): `Contacts.get_wecom_friends_detail(is_maximize=None, close_weixin=None, is_json=False)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |
| `is_json` | Whether to return JSON text. |

示例

from pyweixin import Contacts

Contacts.get_wecom_friends_detail()

或者

from pyweixin import Contacts

Contacts.get_wecom_friends_detail()

#### 3.4 获取共同群聊名称get_common_groups()

Source signature (whl): `Contacts.get_common_groups(friend, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Contacts

Contacts.get_common_groups(friend='Hello,Mr Crab')

或者

from pyweixin.WeChatAuto import Contacts

Contacts.get_common_groups(friend='Hello,Mr Crab')

#### 3.5 获取所有服务号信息get_serAcc_detail()

Source signature (whl): `Contacts.get_serAcc_detail(is_maximize=None, close_weixin=None, is_json=False)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |
| `is_json` | Whether to return JSON text. |

示例

from pyweixin import Contacts

Contacts.get_serAcc_detail()

或者

from pyweixin.WeChatAuto import Contacts

Contacts.get_serAcc_detail()

#### 3.6 获取所有公众号信息get_offAcc_detail()

Source signature (whl): `Contacts.get_offAcc_detail(is_maximize=None, close_weixin=None, is_json=False)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |
| `is_json` | Whether to return JSON text. |

示例

from pyweixin import Contacts

Contacts.get_offAcc_detail()

或者

from pyweixin.WeChatAuto import Contacts

Contacts.get_offAcc_detail()

#### 3.7 获取好友个人简介get_friend_profile()

Source signature (whl): `Contacts.get_friend_profile(friend, search_pages=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Contacts

Contacts.get_friend_profile(friend='Hello,Mr Crab')

或者

from pyweixin.WeChatAuto import Contacts

Contacts.get_friend_profile(friend='Hello,Mr Crab')

#### 3.8 获取最近群聊信息get_recent_groups()

Source signature (whl): `Contacts.get_recent_groups(is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Contacts

print(Contacts.get_recent_groups())

或者

from pyweixin.WeChatAuto import Contacts

print(Contacts.get_recent_groups())

#### 3.9 获取群成员信息get_groupMembers_info()

Source signature (whl): `Contacts.get_groupMembers_info(group, is_maximize=None, search_pages=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `group` | Group chat name. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Contacts

print(Contacts.get_groupMembers_info())

或者

from pyweixin.WeChatAuto import Contacts

print(Contacts.get_groupMembes_info())

#### 3.10 快速获取所有好友备注get_friends_name()

Source signature (whl): `Contacts.get_friends_name(is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Contacts

print(Contacts.get_friends_name())

或者

from pyweixin.WeChatAuto import Contacts

print(Contacts.get_friendss_name())

### 4 FriendSettings类

#### 4.1 添加新朋友 add_new_friend()

Source signature (whl): `FriendSettings.add_new_friend(number, greetings=None, remark=None, chat_only=False, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `number` | Number of items to process or return. |
| `greetings` | Use the whl source signature above; default value is shown there. |
| `remark` | Use the whl source signature above; default value is shown there. |
| `chat_only` | Whether to return chat sessions only. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import FriendSettings

FriendSettings.add_new_friend(number='10086',greetings='你好,我是xxx',remark='新朋友')

或者

from pyweixin.WeChatAuto import FriendSettings

FriendSettings.add_new_friend(number='10086',greetings='你好,我是xxx',remark='新朋友')

#### 4.2 添加好友至黑名单 block_friend()

Source signature (whl): `FriendSettings.block_friend(friend, state=0, search_pages=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `state` | Toggle state, usually 0 off/remove and 1 on/add. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import FriendSettings

FriendSettings.block_friend(friend='好友备注',state=1)

或者

from pyweixin.WeChatAuto import FriendSettings

FriendSettings.block_friend(friend='好友备注',state=1)

#### 4.3 好友置顶 pin_chat()

Source signature (whl): `FriendSettings.pin_chat(friend, state=0, search_pages=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `state` | Toggle state, usually 0 off/remove and 1 on/add. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin.WechatAuto import FriendSettings

FriendSettings.pin_chat(friend='测试ing')

或者

from pyweixin import FriendSettings

FriendSettings.pin_chat(friend='测试ing')

#### 4.4 将好友设置为星标朋友 star_friend()

Source signature (whl): `FriendSettings.star_friend(friend, state=1, search_pages=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `state` | Toggle state, usually 0 off/remove and 1 on/add. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import FriendSettings

FriendSettings.star_friend(friend='测试ing')

或者

from pyweixin.WechatAuto import FriendSettings

FriendSettings.star_friend(friend='测试ing')

#### 4.5 删除好友 delete_friend()

Source signature (whl): `FriendSettings.delete_friend(friend, clear_chat_history=1, search_pages=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `clear_chat_history` | Whether delete_friend also clears chat history. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import FriendSettings

FriendSettings.delete_friend(friend='测试ing')

或者

from pyweixin.WechatAuto import FriendSettings

FriendSettings.delete_friend(friend='测试ing')

#### 4.6 清空好友聊天记录 clear_chat_histpry()

Source signature (whl): `FriendSettings.clear_chat_histpry(friend, search_pages=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import FriendSettings

FriendSettings.clear_chat_histpry(friend='测试ing')

或者

from pyweixin.WechatAuto import FriendSettings

FriendSettings.clear_chat_histpry(friend='测试ing')

#### 4.7 好友消息免打扰 mute_notification()

Source signature (whl): `FriendSettings.mute_notification(friend, mute=0, fold_chat=0, search_pages=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `mute` | Mute notification toggle: 0 off, 1 on. |
| `fold_chat` | Fold chat toggle: 0 off, 1 on. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import FriendSettings

FriendSettings.mute_notification(friend='测试ing')

或者

from pyweixin.WechatAuto import FriendSettings

FriendSettings.mute_notification(friend='测试ing')

#### 4.8 修改好友备注和标签 change_remark()

Source signature (whl): `FriendSettings.change_remark(friend, remark, description=None, phoneNum=None, clear_phoneNum=False, search_pages=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `remark` | Use the whl source signature above; default value is shown there. |
| `description` | Use the whl source signature above; default value is shown there. |
| `phoneNum` | Use the whl source signature above; default value is shown there. |
| `clear_phoneNum` | Whether to clear phone numbers when changing remark. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import FriendSettings

FriendSettings.change_remark(friend='测试ing',remark='起个破名想半天了')

或者

from pyweixin.WechatAuto import FriendSettings

FriendSettings.change_remark(friend='测试ing',remark='起个破名想半天了')

#### 4.9 修改好友权限change_privacy()

Source signature (whl): `FriendSettings.change_privacy(friend, chat_privacy=1, sns_privacy=0, search_pages=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `chat_privacy` | Use the whl source signature above; default value is shown there. |
| `sns_privacy` | Use the whl source signature above; default value is shown there. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import FriendSettings

FriendSettings.change_privacy(friend='测试ing',chat_privacy=1,sns_privacy=0)

或者

from pyweixin.WeChatAuto import FriendSettings

FriendSettings.change_privacy(friend='测试ing',chat_privacy=1,sns_privacy=0)

### 5 AutoReply类

#### 5.1自动回复指定好友消息 auto_reply_to_friend()

Source signature (whl): `AutoReply.auto_reply_to_friend(dialog_window, duration, callback, contexts=[], save_file=False, save_media=False, target_folder=None, close_dialog_window=True)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `dialog_window` | Dialog window object opened by Navigator. |
| `duration` | Listening duration such as 20s, 1min, or 1h. |
| `callback` | Callback function required by the method. |
| `contexts` | Context message list for auto reply. |
| `save_file` | Whether to save files during listening/auto reply. |
| `save_media` | Whether to save images/videos during listening/auto reply. |
| `target_folder` | Absolute output folder. |
| `close_dialog_window` | Whether to close the dialog window after listening. |

示例

from pyweixin import AutoReply,Navigator

def reply_func(newMessage):

if '你好' in newMessage:

return '你好'

if '在吗' in newMessage:

return '你好,在的'

return newMessage

dialog_window=Navigator.open_seperate_dialog_window(friend='测试ing')

AutoReply.auto_reply_to_friend(dialog_window=dialog_window,duration='1min',callback=reply_func)

或者

from pyweixin.WeChatAuto import AutoReply

from pyweixin.WeChatTools import Navigator

def reply_func(newMessage):

if '你好' in newMessage:

return '你好'

if '在吗' in newMessage:

return '你好,在的'

return newMessage

dialog_window=Navigator.open_seperate_dialog_window(friend='测试ing')

AutoReply.auto_reply_to_friend(dialog_window=dialog_window,callback=reply_func,duration='1min')

### 6 Monitor类

#### 6.1监听聊天窗口消息 listen_on_chat()

Source signature (whl): `Monitor.listen_on_chat(dialog_window, duration, groupMembers=[], save_file=False, save_media=False, target_folder=None, close_dialog_window=True)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `dialog_window` | Dialog window object opened by Navigator. |
| `duration` | Listening duration such as 20s, 1min, or 1h. |
| `groupMembers` | Group member names for sender detection. |
| `save_file` | Whether to save files during listening/auto reply. |
| `save_media` | Whether to save images/videos during listening/auto reply. |
| `target_folder` | Absolute output folder. |
| `close_dialog_window` | Whether to close the dialog window after listening. |

示例

#多线程打开多个好友窗口进行消息监听

from concurrent.futures import ThreadPoolExecutor

from pyweixin import Navigator,Monitor

#先打开所有好友的独立窗口

dialog_windows=[]

friends=['Hello,Mr Crab','Pywechat测试群','一家人']

durations=['1min']*len(friends)

#不添加其他参数,比如save_photos,这些操作涉及键鼠,无法多线程

for friend in friends:

dialog_window=Navigator.open_seperate_dialog_window(friend=friend,window_minimize=True,close_weixin=True)

dialog_windows.append(dialog_window)

with ThreadPoolExecutor(max_workers=len(friends)) as pool:

results=pool.map(lambda args: Monitor.listen_on_chat(*args),list(zip(dialog_windows,durations)))

for friend,result in zip(friends,results):

print(friend,result)

### 7 Collections类

#### 7.1收藏内卡片链接转url cardLink_to_url()

Source signature (whl): `Collections.cardLink_to_url(number, delete=False, delay=0.5, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `number` | Number of items to process or return. |
| `delete` | Whether to delete converted collection items. |
| `delay` | Operation delay in seconds. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Collections

results=Collections.cardLink_to_url(number=10)

print(results)

或者

from pyweixin.WeChatAuto import Collections

results=Collections.cardLink_to_url(number=10)

print(results)

#### 7.2 收藏公众号文章collect_offAcc_articles()

Source signature (whl): `Collections.collect_offAcc_articles(name, number, delay=0.3, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `name` | Use the whl source signature above; default value is shown there. |
| `number` | Number of items to process or return. |
| `delay` | Operation delay in seconds. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Collections

collected_num=Collections.collect_offAcc_articles(name='新华社',number=10)

print(collected_num)

或者

from pyweixin.WeChatAuto import Collections

collected_num=Collections.collect_offAcc_articles(name='新华社',number=10)

print(collected_num)

### 8 Call类

#### 8.1与好友语音通话voice_call()

Source signature (whl): `Call.voice_call(friend, wait=False, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `wait` | Whether to wait after starting the call. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Call

VoipCall_window=Call.voice_call(friend='测试ing',wait=True)

或者

from pyweixin.WechatAuto import Call

VoipCall_window=Call.voice_call(friend='测试ing',wait=True)

#### 8.2 与好友视频通话video_call()

Source signature (whl): `Call.video_call(friend, wait=False, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `wait` | Whether to wait after starting the call. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Call

Call.video_call(friend='测试ing')

或者

from pyweixin.WechatAuto import Call

Call.video_call(friend='测试ing')

### 9 Moments类

#### 9.1 导出最近朋友圈 dump_recent_posts()

Source signature (whl): `Moments.dump_recent_posts(recent='Today', number=None, with_name=False, save_detail=False, target_folder=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `recent` | Time filter such as Today, Yesterday, Week, or Month. |
| `number` | Number of items to process or return. |
| `with_name` | Whether returned data includes friend names. |
| `save_detail` | Whether to save detailed exported content. |
| `target_folder` | Absolute output folder. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Moments

print(Moments.dump_recent_posts(recent='Today',save_detail=True,number=10))

或者

from pyweixin.WeChatAuto import Moments

print(Moments.dump_recent_posts(recent='Today',save_detail=True,number=10))

#### 9.2 导出好友朋友圈内容 dump_friend_posts()

Source signature (whl): `Moments.dump_friend_posts(friend, number, save_detail=False, target_folder=None, search_pages=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `number` | Number of items to process or return. |
| `save_detail` | Whether to save detailed exported content. |
| `target_folder` | Absolute output folder. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Moments

Moments.dump_friend_posts(friend='测试ing',number=20,save_detail=True)

或者

from pyweixin.WeChatAuto import Moments

Moments.dump_friend_posts(friend='测试ing',number=20,save_detail=True)

#### 9.3 发布朋友圈 post_moments()

Source signature (whl): `Moments.post_moments(text='', medias=[], is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `text` | Moments text content. |
| `medias` | List of absolute image/video paths. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin.WeChatAuto import Moments

Moments.post_moments(text='发布朋友圈测试',medias=[r"E:\Desktop\test0.png"])

或者

from pyweixin import Moments

Moments.post_moments(text='发布朋友圈测试',medias=[r"E:\Desktop\test0.png"])

#### 9.4 发布笔记至朋友圈 post_notes()

Source signature (whl): `Moments.post_notes(content=None, text=None, files=[], is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `content` | Note content. |
| `text` | Moments text content. |
| `files` | List of absolute file paths. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin.WeChatAuto import Moments

Moments.post_notes(content='笔记发布朋友圈测试',files=[r"E:\Desktop\test0.png"])

或者

from pyweixin import Moments

Moments.post_notes(content='笔记发布朋友圈测试',files=[r"E:\Desktop\test0.png"])

#### 9.4 朋友圈点赞 like_posts()

Source signature (whl): `Moments.like_posts(recent='Today', with_name=False, number=None, callback=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `recent` | Time filter such as Today, Yesterday, Week, or Month. |
| `with_name` | Whether returned data includes friend names. |
| `number` | Number of items to process or return. |
| `callback` | Callback function required by the method. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Moments

Moments.like_posts(recent='Today',number=20)

或者

from pyweixin.WeChatAuto import Moments

Moments.like_posts(recent='Today',number=20)

#### 9.5 好友朋友圈点赞 like_friend_posts()

Source signature (whl): `Moments.like_friend_posts(friend, number, callback=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `number` | Number of items to process or return. |
| `callback` | Callback function required by the method. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin.WeChatAuto import Moments

def comment_func(content):

if 'xxx' in content:

return 'yyy'

return 'zzz'

Moments.like_friend_posts(friend='测试ing',number=20,callback=comment_func)

或者

from pyweixin import Moments

def comment_func(content):

if 'xxx' in content:

return 'yyy'

return 'zzz'

Moments.like_friend_posts(friend='测试ing',number=20,callback=comment_func)

### 10 Settings类

#### 10.1 修改微信主题change_style()

Source signature (whl): `Settings.change_style(style, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `style` | Use the whl source signature above; default value is shown there. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Settings

Settings.change_style(0)

或者

from pyweixin.WeChatAuto import Settings

Settings.change_style(0)

#### 10.2 修改微信语言change_language()

Source signature (whl): `Settings.change_language(language, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `language` | Use the whl source signature above; default value is shown there. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Settings

Settings.change_language(1)

或者

from pyweixin.WeChatAuto import Settings

Settings.change_language(1)

#### 10.3 修改微信字体大小change_fontsize()

Source signature (whl): `Settings.change_fontsize(value=2, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `value` | Use the whl source signature above; default value is shown there. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Settings

Settings.change_fontsize(value=2)

或者

from pyweixin.WeChatAuto import Settings

Settings.change_fontsize(value=2)

#### 10.4 修改微信自动下载文件大小auto_download_size()

Source signature (whl): `Settings.auto_download_size(size=1024, state=True, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `size` | Use the whl source signature above; default value is shown there. |
| `state` | Toggle state, usually 0 off/remove and 1 on/add. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Settings

Settings.auto_download_size(size=500)

或者

from pyweixin.WeChatAuto import Settings

Settings.auto_download_size(size=500)

#### 10.5 修改微信设置中的通知或声音标记notification_alert()

Source signature (whl): `Settings.notification_alert(alert_map={'newMessage': True, 'Call': True, 'Moments': True, 'Game': True, 'Interaction_only': True}, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `alert_map` | Use the whl source signature above; default value is shown there. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Settings

Settings.notification_alert(alert_map={'newMessage':True,'Call':True,

'Moments':True,'Game':False,'Interaction_only':False})

或者

from pyweixin.WeChatAuto import Settings

Settings.notification_alert(alert_map={'newMessage':True,'Call':True,

'Moments':True,'Game':False,'Interaction_only':False})

## WechatTools

WeChatTools是用来辅助WeChatAuto模块进行自动化操作的工具,内置了Tools与Navigator两个类。

### 1. Navigator类

#### 1.1 打开微信open_weixin()

Source signature (whl): `Navigator.open_weixin(is_maximize=None, window_size=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `window_size` | Main WeChat window size tuple. |

示例

from pyweixin import Navigator

Navigator.open_weixin()

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_weixin()

#### 1.2 打开微信设置界面open_settings()

Source signature (whl): `Navigator.open_settings(is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Navigator

Navigator.open_settings()

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_settings()

#### 1.3 打开通讯录open_contacts()

Source signature (whl): `Navigator.open_contacts(is_maximize=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |

示例

from pyweixin import Navigator

Navigator.open_contacts()

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_contacts()

#### 1.4 打开通讯录管理界面open_contacts_manage()

Source signature (whl): `Navigator.open_contacts_manage(is_maximize=None, window_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `window_maximize` | Whether to maximize a child/independent window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Navigator

Navigator.open_contacts_manage()

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_contacts_manage()

#### 1.5 打开收藏界面open_collections()

Source signature (whl): `Navigator.open_collections(is_maximize=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |

示例

from pyweixin import Navigator

Navigator.open_collections()

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_collections()

#### 1.6 打开朋友圈界面open_moments()

Source signature (whl): `Navigator.open_moments(is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Navigator

Naviogator.open_moments()

或者

from pyweixin.WechatTools import Navigator

Naviogator.open_moments()

#### 1.7 打开聊天文件界面open_chatfiles()

Source signature (whl): `Navigator.open_chatfiles(is_maximize=None, window_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `window_maximize` | Whether to maximize a child/independent window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Navigator

Navigator.open_chatfiles()

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_chatfiles()

#### 1.8 打开搜一搜界面open_search()

Source signature (whl): `Navigator.open_search(is_maximize=None, window_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `window_maximize` | Whether to maximize a child/independent window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Navigator

Navigator.open_search()

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_search()

#### 1.9 打开视频号界面open_channels()

Source signature (whl): `Navigator.open_channels(is_maximize=None, window_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `window_maximize` | Whether to maximize a child/independent window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Naviagator

Navigator.open_channels()

或者

from pyweixin.WeChatTools import Naviagator

Navigator.open_channels()

#### 1.10 打开小程序面板open_miniprogram_pane()

Source signature (whl): `Navigator.open_miniprogram_pane(is_maximize=None, window_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `window_maximize` | Whether to maximize a child/independent window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Navigator

Navigator.open_miniprogram_pane()

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_miniprogram_pane()

#### 1.11 打开与好友或群聊的聊天界面open_dialog_window()

Source signature (whl): `Navigator.open_dialog_window(friend, select=False, is_maximize=None, search_pages=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `select` | Whether to select the latest message when opening chat. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `search_pages` | Pages to scan; 0 usually means use top search. |

示例

from pyweixin import Navigator

Navigator.open_dialog_window(friend='文件传输助手')

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_dialog_window(friend='文件传输助手')

#### 1.12 打开与好友或群聊的独立聊天界面open_seperate_dialog_window()

Source signature (whl): `Navigator.open_seperate_dialog_window(friend, select=False, is_maximize=None, window_minimize=False, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `select` | Whether to select the latest message when opening chat. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `window_minimize` | Use the whl source signature above; default value is shown there. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Navigator

Navigator.open_seperate_dialog_window(friend='文件传输助手')

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_seperate_dialog_window(friend='文件传输助手')

#### 1.13 打开与好友或群聊的聊天记录界面open_chat_history()

Source signature (whl): `Navigator.open_chat_history(friend, TabItem=None, search_pages=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `TabItem` | Chat history tab name. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Navigator

Navigator.open_dialog_window(friend='文件传输助手')

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_dialog_window(friend='文件传输助手')

#### 1.14 打开好友聊天信息界面open_chatinfo()

Source signature (whl): `Navigator.open_chatinfo(friend, is_maximize=None, search_pages=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `search_pages` | Pages to scan; 0 usually means use top search. |

示例

from pyweixin import Navigator

Navigator.open_chatinfo(friend='测试ing')

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_chatinfo(friend='测试ing')

#### 1.15 打开好友个人简介面板open_friend_profile()

Source signature (whl): `Navigator.open_friend_profile(friend, is_maximize=None, search_pages=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `search_pages` | Pages to scan; 0 usually means use top search. |

示例

from pyweixin import Navigator

Navigator.open_friend_profile(friend='测试ing')

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_friend_profile(friend='测试ing')

#### 1.16 打开好友朋友圈open_friend_moments()

Source signature (whl): `Navigator.open_friend_moments(friend, search_pages=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `friend` | Friend, group, or chat remark/name. |
| `search_pages` | Pages to scan; 0 usually means use top search. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin.WeChatTools import Navigator

Navigator.open_friend_moments(friend='测试ing')

或者

from pyweixin import Navigator

Navigator.open_friend_moments(friend='测试ing')

#### 1.17 打开聊天记录搜索窗口open_chat_search_window()

Source signature (whl): `Navigator.open_chat_search_window(keyword, window_maximize=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `keyword` | Search keyword. |
| `window_maximize` | Whether to maximize a child/independent window. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Navigator

chat_history_window,main_window=Navigator.open_chat_search_window(keyword='你好')

print(chat_search.dump_tree())

或者

from pyweixin.WeChatTools import Navigator

chat_history_window,main_window=Navigator.open_chat_search_window(keyword='你好')

print(chat_search.dump_tree())

#### 1.18 打开添加好友界面open_add_friend_pane

| is_maximize | 微信主界面是否全屏 | bool 默认值:True |
| --- | --- | --- |
| 返回值 | WindowSpecification | addfriendWindow(添加好友窗口) |

示例

from pyweixin.WeChatTools import Navigator

Navigator.open_add_friend_panel()

或者

from pyweixin.WeChatTools import Navigator

Navigator.open_add_friend_panel()

#### 1.19 搜索打开小程序search_miniprogram()

Source signature (whl): `Navigator.search_miniprogram(name, load_delay=None, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `name` | Use the whl source signature above; default value is shown there. |
| `load_delay` | Load wait time in seconds. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Navigator

Navigator.search_miniprogram(name='跳一跳')

或者

from pyweixin.WeChatTools import Navigator

Navigator.search_miniprogram(name='跳一跳')

#### 1.20 搜索打开视频号search_channels()

Source signature (whl): `Navigator.search_channels(search_content, load_delay=None, is_maximize=None, window_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `search_content` | Keyword used before traversing chat history. |
| `load_delay` | Load wait time in seconds. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `window_maximize` | Whether to maximize a child/independent window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Navigator

Navigator.search_channels(search_content='微信4.0')

或者

from pyweixin.WeChatTools import Navigator

Navigator.search_channels(search_content='微信4.0')

#### 1.21 搜索打开公众号search_official_account()

Source signature (whl): `Navigator.search_official_account(name, load_delay=None, subscribe=False, is_maximize=None, close_weixin=None)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `name` | Use the whl source signature above; default value is shown there. |
| `load_delay` | Load wait time in seconds. |
| `subscribe` | Whether to subscribe when searching official accounts. |
| `is_maximize` | Whether to maximize the main WeChat window. |
| `close_weixin` | Whether to close WeChat after the task. |

示例

from pyweixin import Navigator

Navigator.search_official_account(name='微信团队')

或者

from pyweixin.WeChatTools import Navigator

Navigator.search_official_account(name='微信团队)

#### 1.22 保存登录二维码capture_Login_QRCode()

Source signature (whl): `Navigator.capture_Login_QRCode(img_path)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `img_path` | Output path for login QR code. |

示例

from pyweixin import Navigator

Navigator.capture_Login_QRCode(img_path='test.png')

或者

from pyweixin.WeChatTools import Navigator

Navigator.capture_Login_QRCode(img_path='test.png')

### Tools类

#### 2.1 获取微信.exe路径

示例

from pyweixin import Tools

path=Tools.where_weixin()

print(path)

#### 2.2 获取微信msg文件夹路径where_msg_folder()

Source signature (whl): `Tools.where_msg_folder(open_folder=False)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `open_folder` | Use the whl source signature above; default value is shown there. |

示例

from pyweixin import Tools

path=Tools.where_msg_folder(open_folder=True)

print(path)

#### 2.3 获取微信wxid文件夹路径where_wxid_folder()

Source signature (whl): `Tools.where_wxid_folder(open_folder=False)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `open_folder` | Use the whl source signature above; default value is shown there. |

示例

from pyweixin import Tools

path=Tools.where_wxid_folder()

print(path)

#### 2.4 获取微信聊天文件文件夹路径where_chatfile_folder()

Source signature (whl): `Tools.where_chatfile_folder(open_folder=False)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `open_folder` | Use the whl source signature above; default value is shown there. |

示例

from pyweixin import Tools

path=Tools.where_chatfile_folder()

print(path)

#### 2.5 获取微信视频文件文件夹路径where_video_folder()

Source signature (whl): `Tools.where_video_folder(open_folder=False)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `open_folder` | Use the whl source signature above; default value is shown there. |

示例

from pyweixin import Tools

path=Tools.where_video_folder()

print(path)

#### 2.6 获取微信数据库文件夹路径where_db_folder()

Source signature (whl): `Tools.where_db_folder(open_folder=False)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `open_folder` | Use the whl source signature above; default value is shown there. |

示例

from pyweixin import Tools

path=Tools.where_db_folder()

print(path)

#### 2.7 获取微信用户目录路径where_userlib_folder()

Source signature (whl): `Tools.where_userlib_folder(open_folder=False)`

| Parameter | Source-aligned meaning |
| --- | --- |
| `open_folder` | Use the whl source signature above; default value is shown there. |

示例

from pyweixin import Tools

path=Tools.where_userlib_folder()

print(path)

#### 2.8 获取关于微信的基本信息about_weixin()

Source signature (whl): `Tools.about_weixin()`

| Parameter | Source-aligned meaning |
| --- | --- |

示例

from pyweixin import Tools

path=Tools.about_weixin()

print(path)
