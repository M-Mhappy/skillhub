---

name: boss直聘自动化招聘
description: Boss直聘全自动化招聘工具——基于 boss-cli（Puppeteer/CDP 驱动本机 Chrome，含多层反检测守卫），支持候选人列表、批量发送消息、索要简历、自动打招呼、深度搜索、职位管理、在线简历预览等全流程自动化。用户仅需扫码登录一次，后续全部操作由 AI 员工执行。

---

# boss直聘自动化招聘

Boss直聘全自动化招聘 SKILL：基于 boss-cli（Puppeteer/CDP 驱动本机 Chrome），含反检测守卫，支持候选人列表、批量发消息、索要简历、自动打招呼、深度搜索、职位管理、在线简历预览等完整招聘工作流。

## 前置条件

- **Node.js ≥ 18**（必需）
- **本机 Chrome / Edge / Chromium**（自动探测，也可通过 `CHROME_PATH` 环境变量指定）
- 运行 `npm install` 安装依赖（`puppeteer-core` + `dotenv`）

## 快速开始

```bash
# 1. 进入 skill 目录，安装依赖
cd boss-cli && npm install

# 2. 启动登录（会打开 Chrome 窗口，扫码/验证码登录 Boss 直聘）
node dist/cli/index.js login

# 3. 登录成功后即可使用全部命令
node dist/cli/index.js list --unread
```

## 完整命令参考

| 命令 | 说明 |
|------|------|
| `boss login` | 打开登录页，用户扫码/验证码登录后 Cookie 持久化 |
| `boss list [--unread]` | 读取沟通列表候选人；`--unread` 仅显示有未读角标的 |
| `boss chat <姓名> [--strict]` | 打开候选人会话；默认模糊匹配，`--strict` 精确匹配 |
| `boss send --text <内容> [--request-resume]` | 发送文本消息；`--request-resume` 发送后自动索要简历 |
| `boss action <操作> [--remark <备注>]` | 执行聊天操作：`resume` / `not-fit` / `remark` / `agree-resume` / `request-attachment-resume` / `history` / `wechat` |
| `boss positions` | 读取职位列表（含开放/待开放/已关闭状态） |
| `boss jd <name>` | 抓取指定职位详情并缓存为 `.md` 文件 |
| `boss recommend [岗位关键字]` | 进入推荐页读取推荐列表 |
| `boss preview <姓名> [--job <岗位关键字>]` | 在线简历预览（⚠️ 每日次数有限，谨慎使用） |
| `boss greet <姓名> [--job <岗位关键字>]` | 对推荐列表候选人"打招呼"（⚠️ 消耗打招呼次数，成本高） |
| `boss multi "<子命令1>" "<子命令2>" ...` | **批量模式**：同一会话内依次执行多个子命令，浏览器保持打开不重启 ⭐ |
| `boss deep-search [岗位关键字]` | 深度搜索匹配候选人（别名 `deepsearch`） |
| `boss help` | 显示完整帮助 |
| `boss version` | 版本信息与更新检查 |

## AI 员工调用方式

AI 员工通过命令行工具执行 boss-cli 命令。本 SKILL 提供 `launcher.cjs` 自动处理路径。

### 方式一：使用 launcher.cjs（推荐）

```bash
# 通用（Windows/macOS/Linux 均适用）
node launcher.cjs <command...>
```

### 方式二：直接调用

**Windows（PowerShell）：**
```powershell
$env:NODE_PATH = "<skill目录>/boss-cli/node_modules"
node "<skill目录>/boss-cli/dist/cli/index.js" list --unread
```

**macOS / Linux（Bash）：**
```bash
NODE_PATH="<skill目录>/boss-cli/node_modules" \
  node "<skill目录>/boss-cli/dist/cli/index.js" list --unread
```

### 关键路径

| 路径 | 说明 |
|------|------|
| CLI 入口 | `<skill目录>/boss-cli/dist/cli/index.js` |
| 启动器 | `<skill目录>/launcher.cjs` |
| 依赖目录 | `<skill目录>/boss-cli/node_modules` |
| Chrome user-data-dir | `~/.boss-cli/.cache/browser-data`（Cookie 持久化） |
| JD 缓存 | `~/.boss-cli/jd/` |
| 简历截图 | `~/.boss-cli/.cache/resume-screenshots/` |

## 典型工作流

### 工作流 1：批量查看未读候选人并索要简历（推荐：multi 批量模式）

```
# 第一步：获取未读候选人列表
boss list --unread

# 第二步：根据名单，一次性批量 chat + send（浏览器不重启，效率最高）
boss multi "chat 张三" "send --text 您好..." "chat 李四" "send --text 您好..."
```

> ⭐ **推荐使用 `multi`**：将多个 `chat` + `send` 合并为一条命令，浏览器整个过程中保持打开，
> 不会出现"发完一个就关浏览器再开"的问题。某子命令失败（如候选人不在列表）不影响后续执行。

### 工作流 1b：分步执行（不推荐，仅调试或单个候选人时使用）

```
1. boss list --unread                              → 获取未读候选人列表
2. boss chat <候选人姓名>                           → 打开会话
3. boss send --text "您好..." --request-resume      → 发消息 + 自动索要简历
4. 对下一位候选人重复步骤 2-3
```

### 工作流 2：推荐页批量打招呼

```
1. boss recommend <岗位关键字>                      → 进入推荐页
2. boss greet <候选人姓名> --job <岗位关键字>        → 逐个打招呼
```

### 工作流 3：深度搜索 + 批量沟通

```
1. boss deep-search <岗位关键字>                    → 深度搜索匹配
2. boss chat <候选人姓名>                           → 打开会话
3. boss send --text "您好..."                       → 发送消息
```

### 工作流 4：索要附件简历（需双方各至少发过一条消息）

```
1. boss chat <候选人姓名>
2. boss action request-attachment-resume            → 工具栏"求简历"
```

## 登录流程（首次使用）

1. AI 员工执行 `node launcher.cjs login`（或 `node dist/cli/index.js login`）
2. boss-cli 启动 Chrome 窗口并打开 Boss 直聘登录页
3. **用户手动扫码或验证码登录**（AI 员工不会代填密码，也不应绕过认证，必须拉起浏览器等待用户登录，确认登录后才能进行下一步）
4. 登录成功后 Cookie 自动保存到 `~/.boss-cli/.cache/browser-data`
5. 后续命令自动复用登录态，无需重复登录

> ⚠️ **登录后不要关闭**该 Chrome 窗口，否则 Cookie 可能丢失。
> 可用 `BOSS_BROWSER_HEADLESS=true` 环境变量开启无头模式（首次登录必须有头）。

## 反检测能力（核心）

boss-cli 内置多层反检测守卫，确保 Boss 直聘不触发风控：

- **navigator 伪装**：`webdriver` → undefined，模拟 Chrome 插件列表、语言偏好
- **window.chrome mock**：注入完整 `chrome` 对象
- **CDP 请求拦截**：阻断安全检测脚本（aegis_bg.wasm、risk-detection.js、browser-check SDK）
- **风控跳转拦截**：拦截 `/web/passport/*` 等风控重定向
- **页面防御**：阻止 `beforeunload`/`unload`、拦截 `history.back()`、锁 `console.clear()`
- **独立 user-data-dir**：与日常 Chrome 隔离，避免 Cookie 冲突

## 技术架构

```
boss-cli/
├── dist/                          # 编译后的 JS（可直接执行）
│   ├── cli/index.js               # CLI 入口
│   ├── browser/
│   │   ├── cdp_browser.ts         # Chrome spawn + CDP connect
│   │   ├── browser_session.ts     # 浏览器会话生命周期
│   │   └── ...
│   ├── common/
│   │   ├── boss_page_guards.ts    # 反检测守卫（核心）
│   │   ├── boss_session_page.ts   # Boss 页面壳
│   │   └── ...
│   └── toolset/                   # 各子命令实现
│       ├── list.ts                # 候选人列表
│       ├── chat.ts                # 会话管理
│       ├── send.ts                # 消息发送
│       ├── action.ts              # 操作（简历/微信/不合适等）
│       ├── recommend.ts           # 推荐页
│       ├── greet.ts               # 打招呼
│       ├── deep-search.ts         # 深度搜索
│       ├── jd.ts                  # 职位详情
│       ├── login.ts               # 登录
│       └── preview.ts             # 简历预览
├── src/                           # TypeScript 源码（参考）
├── docs/                          # 技术文档
└── package.json
```

**连接模型**：`spawn` + `puppeteer.connect()`，非 `puppeteer.launch()`。

好处：
- Node 退出时 Chrome 不被 kill（`proc.unref()`）
- 跨命令复用同一 Chrome 实例（固定端口 53470）
- 同一 user-data-dir 共享登录态

## 环境变量（可选）

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `CHROME_PATH` | Chrome 可执行文件路径 | 自动探测 Chrome / Edge / Chromium |
| `BOSS_BROWSER_HEADLESS` | `true` 启用无头模式 | `false`（有头） |
| `BOSS_BROWSER_USER_DATA_DIR` | 浏览器用户数据目录 | `~/.boss-cli/.cache/browser-data` |
| `BOSS_BROWSER_REMOTE_DEBUGGING_PORT` | CDP 调试端口 | `53470` |
| `BOSS_BROWSER_VIEWPORT_WIDTH` | 视口宽度 | `1280` |
| `BOSS_BROWSER_VIEWPORT_HEIGHT` | 视口高度 | `1200` |
| `BOSS_BROWSER_ALLOW_ALL_CORS` | 调试用，放宽 CORS | `false` |
| `BOSS_BROWSER_DISABLE_GPU` | 禁用 GPU | `false` |

## 注意事项

1. **登录只能人工完成**：Boss 直聘需要扫码或短信验证码，AI 员工不会代填密码
2. **Cookie 有时效**：长期不用可能过期，届时重新 `boss login` 即可
3. **操作有成本**：打招呼消耗平台配额，求简历、查看在线简历也有每日限制
4. **风控变化**：Boss 直聘风控策略可能更新，如遇异常先 `boss version` 检查更新
5. **单实例约束**：同一 user-data-dir 下的 Chrome 单例锁会冲突，不要同时跑多个 boss-cli
6. **命令可能超时**：网络或页面加载慢时部分命令可能超过默认超时（~17s），建议设置较长超时或分步执行

## 故障排查

| 症状 | 原因 | 解决 |
|------|------|------|
| `未找到本机 Chrome` | 自动探测失败 | 设置 `CHROME_PATH` 环境变量指向 Chrome 路径 |
| `浏览器进程立即退出` | user-data-dir 被占用 | 关闭所有 Chrome 窗口后重试 |
| `聊天面板未加载` | 页面渲染延迟 | 重试命令，或先 `boss list` 预热 |
| `登录态失效` | Cookie 过期 | `boss login` 重新登录 |
| `操作无响应 / 报错` | 风控拦截或版本过旧 | 检查是否最新版，避免短时间大量操作 |
| `selected=false` | 候选人姓名匹配不精确 | 使用 `--strict` 精确匹配，或从 `boss list` 复制全名 |
| `未读数始终为 0` | 角标渲染延迟 | 已内置角标轮询（列表稳定后额外等待 8s），若仍为 0 说明确实无未读 |
| `浏览器反复重启` | 逐条执行 chat+send | 改用 `boss multi` 批量命令，所有操作共享同一浏览器会话 |
